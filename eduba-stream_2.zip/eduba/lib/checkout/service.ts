import "server-only";
import { and, eq, inArray } from "drizzle-orm";
import { getDb, schema } from "@/lib/db";
import type { Customer, Order } from "@/lib/db/schema";
import { env } from "@/lib/env";
import { normalizePhone } from "@/lib/phone";
import { getProduct, streamProductIdFor, type SiteProduct } from "@/lib/products";
import { stream, StreamApiError } from "@/lib/stream/client";
import { findOrCreateConsumer } from "@/lib/stream/consumers";
import type { Invoice } from "@/lib/stream/types";
import { attachReferralToOrder, resolveReferrer, rewardReferralForOrder } from "@/lib/referrals/service";
import type { AppliedCoupon, Price } from "@/lib/api/contracts";
import {
  attachOrderToRedemption,
  CouponRejectedError,
  findActiveRedemption,
  markCouponRedeemed,
  releaseCouponForOrder,
  releaseRedemption,
  resolveCoupon,
  tryReserve,
  type ResolvedCoupon,
} from "@/lib/coupons/service";
import { basePrice, roundMoney } from "@/lib/coupons/pricing";
import type { CouponRedemption } from "@/lib/db/schema";
import { buildPaymentLinkPayload, withCheckoutLanguage } from "./payment-link";
import { evaluateInvoice, subscriptionSnapshot, type InvoiceVerdict } from "./verify";

export class CheckoutError extends Error {
  constructor(
    message: string,
    public readonly code:
      | "invalid_input"
      | "unknown_product"
      | "stream_error"
      | "not_configured"
      | "auth_required"
      | "order_not_found",
  ) {
    super(message);
    this.name = "CheckoutError";
  }
}

export interface CheckoutInput {
  productKey: string;
  name: string;
  email: string;
  phone: string;
  userId?: string | null;
  /** Referral code from the `eduba_ref` cookie (set by /r/<code> or ?ref=). */
  referralCode?: string | null;
  /** Public coupon code typed by the payer; re-validated and reserved here. */
  couponCode?: string | null;
}

export interface CheckoutResult {
  orderId: string;
  paymentLinkUrl: string;
  product: SiteProduct;
  price: Price;
  coupon: AppliedCoupon | null;
}

/** Finds or creates the local customer and the matching Stream consumer. */
async function upsertCustomer(input: {
  name: string;
  email: string;
  phone: string;
  userId?: string | null;
}): Promise<Customer> {
  const db = getDb();
  const client = stream();

  const { consumer } = await findOrCreateConsumer(client, {
    name: input.name,
    email: input.email,
    phone: input.phone,
    externalId: input.userId ?? undefined,
  });

  const existing = await db
    .select()
    .from(schema.customers)
    .where(eq(schema.customers.streamConsumerId, consumer.id))
    .limit(1);

  if (existing[0]) {
    const [updated] = await db
      .update(schema.customers)
      .set({
        name: input.name,
        email: input.email,
        phone: input.phone,
        userId: existing[0].userId ?? input.userId ?? null,
        updatedAt: new Date(),
      })
      .where(eq(schema.customers.id, existing[0].id))
      .returning();
    return updated;
  }

  const [created] = await db
    .insert(schema.customers)
    .values({
      name: input.name,
      email: input.email,
      phone: input.phone,
      userId: input.userId ?? null,
      streamConsumerId: consumer.id,
    })
    .returning();
  return created;
}

/**
 * Settles a `reserved` coupon row left by an earlier checkout of the same user
 * before a new one may reserve the code again:
 *  - if Stream says that order is paid → it becomes `redeemed` (caller rejects);
 *  - otherwise the old discounted payment link is switched off at Stream, the
 *    old order is expired and the reservation released.
 */
async function settlePendingReservation(row: CouponRedemption): Promise<"redeemed" | "released"> {
  if (!row.orderId) {
    // Reserved but the payment link was never stored: either another request is
    // creating it right now, or that request crashed.
    if (Date.now() - row.createdAt.getTime() < 2 * 60 * 1000) throw new CouponRejectedError("in_progress");
    await releaseRedemption(row.id, "orphaned reservation");
    return "released";
  }
  const order = await getOrder(row.orderId);
  if (!order) {
    await releaseRedemption(row.id, "order missing");
    return "released";
  }
  if (order.status === "paid") {
    await markCouponRedeemed(order.id);
    return "redeemed";
  }
  let state: string;
  try {
    state = (await verifyOrderPayment(order.id)).verdict.state;
  } catch (err) {
    console.error("[checkout] could not verify previous coupon order", err);
    throw new CouponRejectedError("unavailable");
  }
  if (state === "paid") return "redeemed"; // verifyOrderPayment already marked it redeemed

  try {
    await stream().updatePaymentLinkStatus(order.paymentLinkId, "INACTIVE");
  } catch (err) {
    // Already completed/expired links cannot be switched off; that is fine.
    console.warn("[checkout] could not deactivate previous payment link", order.paymentLinkId, (err as Error).message);
  }
  const db = getDb();
  await db
    .update(schema.orders)
    .set({ status: "expired", lastError: "superseded by a new checkout", updatedAt: new Date() })
    .where(and(eq(schema.orders.id, order.id), eq(schema.orders.status, "pending")));
  await releaseRedemption(row.id, "superseded by a new checkout");
  return "released";
}

/** Reserves the coupon for this user or throws CouponRejectedError (one redemption per user per code). */
async function reserveCouponForCheckout(resolved: ResolvedCoupon, userId: string): Promise<CouponRedemption> {
  for (let attempt = 0; attempt < 3; attempt++) {
    const existing = await findActiveRedemption(resolved.mapping.id, userId);
    if (existing?.status === "redeemed") throw new CouponRejectedError("already_redeemed");
    if (existing?.status === "reserved") {
      const outcome = await settlePendingReservation(existing);
      if (outcome === "redeemed") throw new CouponRejectedError("already_redeemed");
    }
    const row = await tryReserve({ mapping: resolved.mapping, userId, price: resolved.price });
    if (row) return row;
    // Lost a race with a concurrent request for the same user and code: re-check.
  }
  throw new CouponRejectedError("in_progress");
}

/**
 * Task 1 core flow: customer → Stream consumer (no duplicates) → payment link
 * for one product (with the Stream coupon attached when a valid code is given)
 * → local order. Returns Stream's hosted payment page URL.
 */
export async function createCheckout(raw: CheckoutInput): Promise<CheckoutResult> {
  const product = getProduct(raw.productKey);
  if (!product) throw new CheckoutError("الباقة المطلوبة غير موجودة", "unknown_product");

  const name = raw.name.trim();
  const email = raw.email.trim().toLowerCase();
  const phone = normalizePhone(raw.phone);
  if (name.length < 2) throw new CheckoutError("يرجى إدخال الاسم الكامل", "invalid_input");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    throw new CheckoutError("يرجى إدخال بريد إلكتروني صحيح", "invalid_input");
  if (!phone) throw new CheckoutError("يرجى إدخال رقم جوال صحيح (مثال: 05xxxxxxxx)", "invalid_input");

  let streamProductId: string;
  try {
    streamProductId = streamProductIdFor(product);
  } catch (err) {
    // Developer detail goes to the server log only; the payer sees a neutral message.
    console.error("[checkout] payments not configured:", (err as Error).message);
    throw new CheckoutError("الاشتراك عبر الموقع غير متاح مؤقتاً، يرجى المحاولة لاحقاً.", "not_configured");
  }

  // Coupon: validated again here (the browser's earlier /validate call is only a preview).
  let resolved: ResolvedCoupon | null = null;
  let reservation: CouponRedemption | null = null;
  const wantsCoupon = typeof raw.couponCode === "string" && raw.couponCode.trim() !== "";
  if (wantsCoupon) {
    if (!raw.userId) throw new CouponRejectedError("auth_required");
    resolved = await resolveCoupon(raw.couponCode, product);
    reservation = await reserveCouponForCheckout(resolved, raw.userId);
  }

  try {
    const db = getDb();
    const customer = await upsertCustomer({ name, email, phone, userId: raw.userId });

    // The order id is generated first so it can be embedded in the redirect URLs and metadata.
    const orderId = crypto.randomUUID();
    const payload = buildPaymentLinkPayload({
      product,
      streamProductId,
      consumerId: customer.streamConsumerId,
      orderId,
      userId: raw.userId ?? null,
      appUrl: env.appUrl,
      couponIds: resolved ? [resolved.coupon.id] : undefined,
    });
    if (resolved) payload.custom_metadata = { ...payload.custom_metadata, coupon_code: resolved.applied.code };

    let link;
    try {
      link = await stream().createPaymentLink(payload);
    } catch (err) {
      if (err instanceof StreamApiError) {
        console.error("[checkout] Stream payment link error", err.status, err.body);
        throw new CheckoutError("تعذّر إنشاء رابط الدفع، حاول مرة أخرى بعد قليل", "stream_error");
      }
      throw err;
    }

    // Stream computes the discounted amount; that is what it will charge and what
    // the success page verifies. Our own quote is only a cross-check.
    let price = resolved ? resolved.price : basePrice(product.amount, product.currency);
    const streamAmount = Number(link.amount);
    if (Number.isFinite(streamAmount) && streamAmount > 0 && Math.abs(streamAmount - price.total) > 0.009) {
      console.warn(`[checkout] Stream link amount ${link.amount} differs from local quote ${price.total}; using Stream's`);
      price = { ...price, total: roundMoney(streamAmount), discount: roundMoney(price.original - streamAmount) };
    }

    const url = withCheckoutLanguage(link.url, "ar");
    const referral = await resolveReferrer({ cookieCode: raw.referralCode, payerUserId: raw.userId, payerEmail: email }).catch((err) => {
      console.error("[checkout] referral lookup failed", err);
      return null;
    });
    await db.insert(schema.orders).values({
      id: orderId,
      customerId: customer.id,
      userId: raw.userId ?? null,
      productKey: product.key,
      streamProductId,
      productType: product.type,
      amount: price.total.toFixed(2),
      originalAmount: price.original.toFixed(2),
      discountAmount: price.discount.toFixed(2),
      couponCodeId: resolved?.mapping.id ?? null,
      streamCouponId: resolved?.coupon.id ?? null,
      currency: product.currency,
      status: "pending",
      paymentLinkId: link.id,
      paymentLinkUrl: url,
      referralCode: referral?.code ?? null,
      referrerUserId: referral?.referrer.id ?? null,
    });
    if (reservation) await attachOrderToRedemption(reservation.id, orderId, price.discount);
    if (referral) {
      await attachReferralToOrder({
        orderId,
        referrer: referral.referrer,
        code: referral.code,
        referredUserId: raw.userId ?? null,
        referredCustomerId: customer.id,
      });
    }

    return { orderId, paymentLinkUrl: url, product, price, coupon: resolved?.applied ?? null };
  } catch (err) {
    // Nothing was charged: give the coupon back so the user can retry.
    if (reservation) await releaseRedemption(reservation.id, "checkout creation failed").catch(() => undefined);
    throw err;
  }
}

export async function getOrder(orderId: string): Promise<(Order & { customer: Customer }) | undefined> {
  if (!/^[0-9a-f-]{36}$/i.test(orderId)) return undefined;
  const db = getDb();
  const rows = await db
    .select({ order: schema.orders, customer: schema.customers })
    .from(schema.orders)
    .innerJoin(schema.customers, eq(schema.orders.customerId, schema.customers.id))
    .where(eq(schema.orders.id, orderId))
    .limit(1);
  if (!rows[0]) return undefined;
  return { ...rows[0].order, customer: rows[0].customer };
}

/** Pulls a subscription from Stream and mirrors it locally. Safe to call repeatedly. */
export async function syncSubscription(
  streamSubscriptionId: string,
  hints: { customerId?: string; orderId?: string | null; productKey?: string | null } = {},
) {
  const db = getDb();
  const sub = await stream().getSubscription(streamSubscriptionId);
  const snap = subscriptionSnapshot(sub);

  let customerId = hints.customerId;
  if (!customerId && sub.organization_consumer_id) {
    const c = await db
      .select({ id: schema.customers.id })
      .from(schema.customers)
      .where(eq(schema.customers.streamConsumerId, sub.organization_consumer_id))
      .limit(1);
    customerId = c[0]?.id;
  }
  if (!customerId) return null; // subscription created outside the website; nothing to mirror

  const [row] = await db
    .insert(schema.subscriptions)
    .values({
      customerId,
      orderId: hints.orderId ?? null,
      streamSubscriptionId,
      productKey: hints.productKey ?? null,
      ...snap,
      raw: sub,
    })
    .onConflictDoUpdate({
      target: schema.subscriptions.streamSubscriptionId,
      set: {
        ...snap,
        raw: sub,
        orderId: hints.orderId ?? undefined,
        productKey: hints.productKey ?? undefined,
        updatedAt: new Date(),
      },
    })
    .returning();
  return row;
}

export interface VerificationOutcome {
  verdict: InvoiceVerdict | { state: "unknown"; reason: string };
  order: Order;
}

/**
 * Server-side confirmation used by the success page, the status endpoint and
 * the webhook: fetch the invoice from Stream and apply the verification rules.
 * Only a verified "paid" verdict flips the order to `paid`.
 */
export async function verifyOrderPayment(
  orderId: string,
  hints: { invoiceId?: string | null; paymentId?: string | null } = {},
): Promise<VerificationOutcome> {
  const db = getDb();
  const order = await getOrder(orderId);
  if (!order) throw new CheckoutError("الطلب غير موجود", "order_not_found");

  if (order.status === "paid") {
    return {
      verdict: { state: "paid", subscriptionId: order.subscriptionId, paymentId: order.paymentId, paidAt: order.paidAt?.toISOString() ?? null },
      order,
    };
  }

  // Locate the invoice: the id from the redirect/webhook, the one stored earlier,
  // or (fallback) the invoice list filtered by our payment link id.
  let invoice: Invoice | undefined;
  const invoiceId = hints.invoiceId ?? order.invoiceId ?? undefined;
  try {
    if (invoiceId) {
      invoice = await stream().getInvoice(invoiceId);
    } else {
      const list = await stream().listInvoices({ payment_link_id: order.paymentLinkId, include_payments: true, limit: 5 });
      invoice = list.data?.[0];
    }
  } catch (err) {
    if (err instanceof StreamApiError && err.status === 404) {
      return { verdict: { state: "unknown", reason: "invoice not found yet" }, order };
    }
    throw err;
  }
  if (!invoice) return { verdict: { state: "unknown", reason: "no invoice for this payment link yet" }, order };

  const verdict = evaluateInvoice(invoice, {
    paymentLinkId: order.paymentLinkId,
    streamConsumerId: order.customer.streamConsumerId,
    amount: Number(order.amount),
    currency: order.currency,
  });

  if (verdict.state === "mismatch") {
    console.warn("[checkout] invoice mismatch", { orderId, invoiceId: invoice.id, reason: verdict.reason });
    await db
      .update(schema.orders)
      .set({ lastError: `mismatch: ${verdict.reason}`, updatedAt: new Date() })
      .where(eq(schema.orders.id, orderId));
    return { verdict, order };
  }

  if (verdict.state === "paid") {
    const paidAt = verdict.paidAt ? new Date(verdict.paidAt) : new Date();
    const [updated] = await db
      .update(schema.orders)
      .set({
        status: "paid",
        invoiceId: invoice.id,
        paymentId: verdict.paymentId ?? hints.paymentId ?? null,
        subscriptionId: verdict.subscriptionId,
        paidAt,
        lastError: null,
        updatedAt: new Date(),
      })
      .where(and(eq(schema.orders.id, orderId), inArray(schema.orders.status, ["pending", "expired", "failed"])))
      .returning();
    if (updated?.couponCodeId) {
      // One-time coupon: from now on this user can never use the code again.
      try {
        await markCouponRedeemed(updated.id);
      } catch (err) {
        console.error("[coupons] could not mark redemption", err);
      }
    }
    if (updated) {
      // Referral commission: booked once per order (idempotent), never blocks the payment flow.
      try {
        const result = await rewardReferralForOrder(updated);
        if (updated.referrerUserId) console.log(`[referral] order ${orderId}: ${result}`);
      } catch (err) {
        console.error("[referral] reward failed", err);
      }
    }
    if (verdict.subscriptionId) {
      try {
        await syncSubscription(verdict.subscriptionId, {
          customerId: order.customerId,
          orderId,
          productKey: order.productKey,
        });
      } catch (err) {
        console.error("[checkout] subscription sync failed", err);
      }
    }
    return { verdict, order: updated ?? { ...order, status: "paid" } };
  }

  // pending / failed: remember the invoice id for later checks
  await db
    .update(schema.orders)
    .set({
      invoiceId: invoice.id,
      status: verdict.state === "failed" ? "failed" : order.status,
      lastError: verdict.reason,
      updatedAt: new Date(),
    })
    .where(eq(schema.orders.id, orderId));
  if (verdict.state === "failed" && order.couponCodeId) {
    // Dead invoice: nothing was charged, the user may use the coupon again.
    await releaseCouponForOrder(orderId, verdict.reason).catch((err) => console.error("[coupons] release failed", err));
  }
  return { verdict, order: { ...order, invoiceId: invoice.id } };
}

/** Marks a pending order as failed (from the failure redirect or a failed-payment webhook). */
export async function recordOrderFailure(orderId: string, reason: string) {
  const db = getDb();
  await db
    .update(schema.orders)
    .set({ lastError: reason, updatedAt: new Date() })
    .where(and(eq(schema.orders.id, orderId), eq(schema.orders.status, "pending")));
}
