import "server-only";
import { NextResponse } from "next/server";

/** JSON response that is never cached by browsers or the CDN. */
export function json<T>(body: T, status = 200): NextResponse {
  return NextResponse.json(body, { status, headers: { "Cache-Control": "no-store" } });
}

/**
 * Same-origin guard for state-changing JSON endpoints called by our own pages.
 * Browsers always send `Origin` on cross-site POSTs, so a mismatch means the
 * request did not come from this site.
 */
export function isSameOrigin(req: Request): boolean {
  const origin = req.headers.get("origin");
  if (!origin) return true; // same-origin navigations / server-to-server calls
  try {
    const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host");
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

export async function readJson(req: Request): Promise<unknown> {
  try {
    return await req.json();
  } catch {
    return undefined;
  }
}
