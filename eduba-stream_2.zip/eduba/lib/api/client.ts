/**
 * Browser-side API client for the checkout. Thin, typed wrappers around the
 * merchant backend endpoints — the only way the checkout UI talks to the
 * server. No pricing or coupon rules live here.
 */
import type {
  CreateCheckoutRequest,
  CreateCheckoutResponse,
  ValidateCouponRequest,
  ValidateCouponResponse,
} from "./contracts";

async function postJson<T>(url: string, body: unknown): Promise<{ status: number; data: T | null }> {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(body),
    credentials: "same-origin",
    cache: "no-store",
  });
  let data: T | null = null;
  try {
    data = (await res.json()) as T;
  } catch {
    data = null;
  }
  return { status: res.status, data };
}

const NETWORK_MESSAGE = "تعذّر الاتصال بالخادم. تحقق من اتصالك وحاول مرة أخرى.";

export async function validateCoupon(req: ValidateCouponRequest): Promise<ValidateCouponResponse | { error: string }> {
  try {
    const { data } = await postJson<ValidateCouponResponse>("/api/coupons/validate", req);
    if (data && "valid" in data) return data;
    return { error: NETWORK_MESSAGE };
  } catch {
    return { error: NETWORK_MESSAGE };
  }
}

export async function createCheckout(req: CreateCheckoutRequest): Promise<CreateCheckoutResponse> {
  try {
    const { data } = await postJson<CreateCheckoutResponse>("/api/checkout", req);
    if (data && "ok" in data) return data;
  } catch {
    // fall through
  }
  return { ok: false, error: { code: "internal_error", message: NETWORK_MESSAGE } };
}
