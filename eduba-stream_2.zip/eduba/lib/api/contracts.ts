/**
 * Public HTTP contracts between the checkout frontend and the merchant backend.
 *
 * Types only — no logic — so the browser bundle never contains pricing or
 * coupon rules. Every value shown to the payer (prices, discount, messages)
 * comes from these responses. See docs/STREAM-COUPON-INTEGRATION.md.
 */

export type ProductKey = "pro_monthly" | "test_one_time";

export interface Price {
  currency: string;
  /** Catalogue price before any coupon. */
  original: number;
  discount: number;
  /** What Stream will charge. */
  total: number;
}

export interface AppliedCoupon {
  /** The code as the payer typed it (normalised to lower case). */
  code: string;
  type: "percentage" | "fixed";
  /** 10 → 10 % or 10 SAR depending on `type`. */
  value: number;
  /** Ready-to-show Arabic label, e.g. "خصم 10%". */
  label: string;
}

export type CouponRejectionReason =
  | "invalid_format" // not a syntactically valid code
  | "not_found" // no active mapping for this code
  | "inactive" // mapped, but switched off in Stream
  | "currency_mismatch" // fixed-amount coupon in another currency
  | "not_applicable" // would make the total 0 or invalid
  | "auth_required" // coupons are per account → sign in first
  | "already_redeemed" // this account already used this code
  | "in_progress" // another checkout with this code is being created right now
  | "unavailable"; // Stream unreachable / not configured

// POST /api/coupons/validate ---------------------------------------------------

export interface ValidateCouponRequest {
  code: string;
  productKey: ProductKey;
}

export type ValidateCouponResponse =
  | { valid: true; coupon: AppliedCoupon; price: Price; message: string }
  | { valid: false; reason: CouponRejectionReason; message: string; price: Price };

// POST /api/checkout -------------------------------------------------------------

export interface CreateCheckoutRequest {
  productKey: ProductKey;
  name: string;
  email: string;
  /** Saudi mobile, any common format (05…, 5…, +9665…). Normalised server-side to E.164. */
  phone: string;
  /** Optional; validated and reserved again on the server (never trusted from the client). */
  couponCode?: string | null;
}

export type CheckoutErrorCode =
  | "invalid_input"
  | "unknown_product"
  | "auth_required"
  | "coupon_rejected"
  | "stream_error"
  | "not_configured"
  | "internal_error";

export type CreateCheckoutResponse =
  | {
      ok: true;
      orderId: string;
      /** Stream hosted payment page; the browser is redirected here. */
      paymentUrl: string;
      price: Price;
      coupon: AppliedCoupon | null;
    }
  | {
      ok: false;
      error: { code: CheckoutErrorCode; message: string; reason?: CouponRejectionReason };
    };

// GET /api/checkout/status?order=<id> -----------------------------------------

export interface CheckoutStatusResponse {
  state: "paid" | "pending" | "failed" | "mismatch" | "unknown";
  reason?: string;
}
