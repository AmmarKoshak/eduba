import {
  boolean,
  integer,
  jsonb,
  numeric,
  pgEnum,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
  index,
  uuid,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const userRoleEnum = pgEnum("user_role", ["student", "parent"]);
export const orderStatusEnum = pgEnum("order_status", [
  "pending",
  "paid",
  "failed",
  "expired",
  "refunded",
]);

/** Site accounts (students / parents). Admin access is an email allow-list, see lib/env.ts. */
export const users = pgTable(
  "users",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    email: text("email").notNull(),
    username: text("username"),
    name: text("name").notNull(),
    phone: text("phone"),
    passwordHash: text("password_hash").notNull(),
    role: userRoleEnum("role").notNull().default("student"),
    /** Public referral code, e.g. "7K3PQ2XA" → link /r/7K3PQ2XA */
    referralCode: text("referral_code"),
    /** Code that was active when this user signed up (attribution). */
    referredByCode: text("referred_by_code"),
    isInfluencer: boolean("is_influencer").notNull().default(false),
    /** Per-influencer commission override (percent of the first payment). */
    commissionRatePercent: numeric("commission_rate_percent", { precision: 5, scale: 2 }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("users_email_unique").on(t.email),
    uniqueIndex("users_username_unique").on(t.username),
    uniqueIndex("users_referral_code_unique").on(t.referralCode),
  ],
);

/** A paying customer, mirrored to a Stream consumer. One row per Stream consumer. */
export const customers = pgTable(
  "customers",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
    name: text("name").notNull(),
    email: text("email").notNull(),
    phone: text("phone").notNull(),
    streamConsumerId: text("stream_consumer_id").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("customers_stream_consumer_id_unique").on(t.streamConsumerId),
    index("customers_email_idx").on(t.email),
    index("customers_phone_idx").on(t.phone),
    index("customers_user_id_idx").on(t.userId),
  ],
);

/** One checkout attempt = one Stream payment link bound to one consumer. */
export const orders = pgTable(
  "orders",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    customerId: uuid("customer_id")
      .notNull()
      .references(() => customers.id, { onDelete: "restrict" }),
    userId: uuid("user_id").references(() => users.id, { onDelete: "set null" }),
    productKey: text("product_key").notNull(),
    streamProductId: text("stream_product_id").notNull(),
    productType: text("product_type").notNull(), // RECURRING | ONE_OFF
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
    currency: text("currency").notNull().default("SAR"),
    status: orderStatusEnum("status").notNull().default("pending"),
    paymentLinkId: text("payment_link_id").notNull(),
    paymentLinkUrl: text("payment_link_url").notNull(),
    invoiceId: text("invoice_id"),
    paymentId: text("payment_id"),
    subscriptionId: text("subscription_id"),
    lastError: text("last_error"),
    referralCode: text("referral_code"),
    referrerUserId: uuid("referrer_user_id").references(() => users.id, { onDelete: "set null" }),
    /** Price before the coupon; `amount` is what Stream will charge (after discount). */
    originalAmount: numeric("original_amount", { precision: 12, scale: 2 }),
    discountAmount: numeric("discount_amount", { precision: 12, scale: 2 }).notNull().default("0"),
    couponCodeId: uuid("coupon_code_id").references(() => couponCodes.id, { onDelete: "set null" }),
    /** Stream coupon UUID that was attached to this order's payment link. */
    streamCouponId: text("stream_coupon_id"),
    paidAt: timestamp("paid_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("orders_payment_link_id_unique").on(t.paymentLinkId),
    index("orders_customer_id_idx").on(t.customerId),
    index("orders_invoice_id_idx").on(t.invoiceId),
    index("orders_status_idx").on(t.status),
  ],
);

/** Local mirror of Stream subscriptions, kept fresh by webhooks + success-page verification. */
export const subscriptions = pgTable(
  "subscriptions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    customerId: uuid("customer_id")
      .notNull()
      .references(() => customers.id, { onDelete: "restrict" }),
    orderId: uuid("order_id").references(() => orders.id, { onDelete: "set null" }),
    streamSubscriptionId: text("stream_subscription_id").notNull(),
    productKey: text("product_key"),
    status: text("status").notNull(), // Stream SubscriptionStatus
    amount: numeric("amount", { precision: 12, scale: 2 }),
    currency: text("currency"),
    currentPeriodStart: timestamp("current_period_start", { withTimezone: true }),
    currentPeriodEnd: timestamp("current_period_end", { withTimezone: true }),
    cancelAtPeriodEnd: boolean("cancel_at_period_end").notNull().default(false),
    raw: jsonb("raw"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("subscriptions_stream_id_unique").on(t.streamSubscriptionId),
    index("subscriptions_customer_id_idx").on(t.customerId),
  ],
);

/**
 * Every webhook delivery we accepted. The unique `eventKey` makes handlers
 * idempotent: Stream retries up to 5 times and may deliver the same event twice.
 */
export const webhookEvents = pgTable(
  "webhook_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    eventKey: text("event_key").notNull(),
    eventType: text("event_type").notNull(),
    entityType: text("entity_type"),
    entityId: text("entity_id"),
    status: text("status"),
    payload: jsonb("payload").notNull(),
    attempts: integer("attempts").notNull().default(1),
    receivedAt: timestamp("received_at", { withTimezone: true }).notNull().defaultNow(),
    processedAt: timestamp("processed_at", { withTimezone: true }),
    error: text("error"),
  },
  (t) => [
    uniqueIndex("webhook_events_event_key_unique").on(t.eventKey),
    index("webhook_events_entity_idx").on(t.entityType, t.entityId),
  ],
);

// ---------------------------------------------------------------------------
// Referral wallets (built in the app — Stream has no wallet/referral feature)
// ---------------------------------------------------------------------------

export const walletTxTypeEnum = pgEnum("wallet_tx_type", ["commission", "settlement", "settlement_reversal", "adjustment"]);
export const referralStatusEnum = pgEnum("referral_status", ["pending", "rewarded", "void"]);
export const settlementStatusEnum = pgEnum("settlement_status", ["pending", "paid", "canceled"]);

/** One wallet per user (payer or influencer). Balance = sum of transactions. */
export const wallets = pgTable(
  "wallets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    balance: numeric("balance", { precision: 12, scale: 2 }).notNull().default("0"),
    lifetimeEarned: numeric("lifetime_earned", { precision: 12, scale: 2 }).notNull().default("0"),
    currency: text("currency").notNull().default("SAR"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("wallets_user_id_unique").on(t.userId)],
);

export const walletTransactions = pgTable(
  "wallet_transactions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    walletId: uuid("wallet_id")
      .notNull()
      .references(() => wallets.id, { onDelete: "cascade" }),
    type: walletTxTypeEnum("type").notNull(),
    /** Positive = credit, negative = debit. */
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
    balanceAfter: numeric("balance_after", { precision: 12, scale: 2 }).notNull(),
    /** Guarantees each commission / settlement is booked once, e.g. "commission:<order id>". */
    idempotencyKey: text("idempotency_key").notNull(),
    orderId: uuid("order_id").references(() => orders.id, { onDelete: "set null" }),
    settlementId: uuid("settlement_id"),
    description: text("description"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("wallet_tx_idempotency_unique").on(t.idempotencyKey),
    index("wallet_tx_wallet_idx").on(t.walletId),
  ],
);

/** A referred checkout. Rewarded once, on the referred customer's first successful payment. */
export const referrals = pgTable(
  "referrals",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    referrerUserId: uuid("referrer_user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    referralCode: text("referral_code").notNull(),
    referredUserId: uuid("referred_user_id").references(() => users.id, { onDelete: "set null" }),
    referredCustomerId: uuid("referred_customer_id")
      .notNull()
      .references(() => customers.id, { onDelete: "cascade" }),
    orderId: uuid("order_id")
      .notNull()
      .references(() => orders.id, { onDelete: "cascade" }),
    status: referralStatusEnum("status").notNull().default("pending"),
    commissionAmount: numeric("commission_amount", { precision: 12, scale: 2 }),
    voidReason: text("void_reason"),
    rewardedAt: timestamp("rewarded_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("referrals_order_id_unique").on(t.orderId),
    index("referrals_referrer_idx").on(t.referrerUserId),
    index("referrals_customer_idx").on(t.referredCustomerId),
  ],
);

/** Monthly payout of a wallet balance, paid by bank transfer outside the system. */
export const settlements = pgTable(
  "settlements",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    walletId: uuid("wallet_id")
      .notNull()
      .references(() => wallets.id, { onDelete: "cascade" }),
    period: text("period").notNull(), // YYYY-MM
    amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
    currency: text("currency").notNull().default("SAR"),
    status: settlementStatusEnum("status").notNull().default("pending"),
    reference: text("reference"),
    note: text("note"),
    createdByEmail: text("created_by_email"),
    paidAt: timestamp("paid_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("settlements_wallet_idx").on(t.walletId), index("settlements_status_idx").on(t.status)],
);

// --- Coupons -----------------------------------------------------------------
// Stream owns the coupon itself (discount value, active flag); the merchant owns
// which public codes customers may type and who has already used them.

export const couponRedemptionStatusEnum = pgEnum("coupon_redemption_status", [
  "reserved", // checkout started with the coupon, payment not confirmed yet
  "redeemed", // Stream confirmed the discounted payment
  "released", // abandoned / expired / failed: the user may try again
]);

/** Public coupon codes (what customers type) mapped to Stream coupon UUIDs. */
export const couponCodes = pgTable(
  "coupon_codes",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    /** Stored normalised (trimmed, lower-case); unique. */
    code: text("code").notNull(),
    streamCouponId: text("stream_coupon_id").notNull(),
    /** Snapshot of the Stream coupon name when mapped (display only; Stream stays the source of truth). */
    streamCouponName: text("stream_coupon_name"),
    isActive: boolean("is_active").notNull().default(true),
    note: text("note"),
    createdByEmail: text("created_by_email"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("coupon_codes_code_unique").on(t.code)],
);

/**
 * One row per checkout that used a coupon. The partial unique index is the
 * one-time-per-user guarantee: a user can hold at most one reserved or
 * redeemed row per code, enforced by Postgres even under concurrent requests.
 */
export const couponRedemptions = pgTable(
  "coupon_redemptions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    couponCodeId: uuid("coupon_code_id")
      .notNull()
      .references(() => couponCodes.id, { onDelete: "restrict" }),
    streamCouponId: text("stream_coupon_id").notNull(),
    userId: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    orderId: uuid("order_id").references(() => orders.id, { onDelete: "set null" }),
    status: couponRedemptionStatusEnum("status").notNull().default("reserved"),
    discountAmount: numeric("discount_amount", { precision: 12, scale: 2 }).notNull(),
    currency: text("currency").notNull().default("SAR"),
    releaseReason: text("release_reason"),
    redeemedAt: timestamp("redeemed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("coupon_redemptions_active_per_user")
      .on(t.couponCodeId, t.userId)
      .where(sql`${t.status} in ('reserved', 'redeemed')`),
    uniqueIndex("coupon_redemptions_order_unique").on(t.orderId),
    index("coupon_redemptions_user_idx").on(t.userId),
  ],
);

export type CouponCode = typeof couponCodes.$inferSelect;
export type CouponRedemption = typeof couponRedemptions.$inferSelect;

export type Wallet = typeof wallets.$inferSelect;
export type WalletTransaction = typeof walletTransactions.$inferSelect;
export type Referral = typeof referrals.$inferSelect;
export type Settlement = typeof settlements.$inferSelect;

export type User = typeof users.$inferSelect;
export type Customer = typeof customers.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type Subscription = typeof subscriptions.$inferSelect;
export type WebhookEvent = typeof webhookEvents.$inferSelect;
