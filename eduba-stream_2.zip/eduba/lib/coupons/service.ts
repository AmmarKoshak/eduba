import "server-only";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import type { AppliedCoupon, CouponRejectionReason, Price } from "@/lib/api/contracts";
import { getDb, schema } from "@/lib/db";
import type { CouponCode, CouponRedemption } from "@/lib/db/schema";
import type { SiteProduct } from "@/lib/products";
import { stream, StreamApiError } from "@/lib/stream/client";
import type { Coupon } from "@/lib/stream/types";
import { applyCoupon, basePrice, describeDiscount, normalizeCouponCode } from "./pricing";

/**
 * Coupon backend.
 *
 * Responsibilities are split on purpose:
 *  - Stream owns the coupon (discount value, currency, active flag) and applies
 *    it to the payment link, so the amount charged is computed by Stream.
 *  - The merchant (this module) owns which public codes exist, maps them to
 *    Stream coupon UUIDs, and enforces "one redemption per user per code".
 */

export const COUPON_MESSAGES: Record<CouponRejectionReason, string> = {
  invalid_format: "صيغة الكوبون غير صحيحة.",
  not_found: "الكوبون غير صالح.",
  inactive: "انتهت صلاحية هذا الكوبون أو تم إيقافه.",
  currency_mismatch: "هذا الكوبون لا ينطبق على عملة هذه الباقة.",
  not_applicable: "لا يمكن تطبيق هذا الكوبون على هذه الباقة.",
  auth_required: "سجّل الدخول لاستخدام الكوبون، فكل كوبون يُستخدم مرة واحدة لكل حساب.",
  already_redeemed: "لقد استخدمت هذا الكوبون من قبل. يمكن استخدام كل كوبون مرة واحدة فقط لكل حساب.",
  in_progress: "يوجد طلب دفع قيد الإنشاء بهذا الكوبون، حاول مرة أخرى بعد لحظات.",
  unavailable: "تعذّر التحقق من الكوبون الآن، حاول مرة أخرى بعد قليل.",
};

export class CouponRejectedError extends Error {
  constructor(public readonly reason: CouponRejectionReason, message = COUPON_MESSAGES[reason]) {
    super(message);
    this.name = "CouponRejectedError";
  }
}

export function isUniqueViolation(err: unknown): boolean {
  const e = err as { code?: string; cause?: { code?: string } } | null;
  return e?.code === "23505" || e?.cause?.code === "23505";
}

export function couponLabel(type: "percentage" | "fixed", value: number, currency: string): string {
  const n = Number.isInteger(value) ? String(value) : value.toFixed(2);
  return type === "percentage" ? `خصم ${n}%` : `خصم ${n} ${currency === "SAR" ? "ريال" : currency}`;
}

export interface ResolvedCoupon {
  mapping: CouponCode;
  coupon: Coupon;
  applied: AppliedCoupon;
  price: Price;
}

async function fetchStreamCoupon(id: string): Promise<Coupon | null> {
  try {
    return await stream().getCoupon(id);
  } catch (err) {
    if (err instanceof StreamApiError && (err.status === 404 || err.status === 422)) return null;
    console.error("[coupons] Stream coupon lookup failed", err);
    throw new CouponRejectedError("unavailable");
  }
}

/**
 * Code → mapping (our DB) → coupon (Stream) → price. Throws CouponRejectedError.
 * Does not look at the user; see `assertNotRedeemed`.
 */
export async function resolveCoupon(rawCode: unknown, product: SiteProduct): Promise<ResolvedCoupon> {
  const code = normalizeCouponCode(rawCode);
  if (!code) throw new CouponRejectedError("invalid_format");

  const db = getDb();
  const [mapping] = await db.select().from(schema.couponCodes).where(eq(schema.couponCodes.code, code)).limit(1);
  if (!mapping || !mapping.isActive) throw new CouponRejectedError("not_found");

  const coupon = await fetchStreamCoupon(mapping.streamCouponId);
  if (!coupon) {
    console.warn(`[coupons] code "${code}" points to Stream coupon ${mapping.streamCouponId}, which no longer exists`);
    throw new CouponRejectedError("not_found");
  }
  if (!coupon.is_active) throw new CouponRejectedError("inactive");

  const terms = { isPercentage: coupon.is_percentage, discountValue: coupon.discount_value, currency: coupon.currency };
  const result = applyCoupon(product.amount, product.currency, terms);
  if (!result.ok) throw new CouponRejectedError(result.reason);

  const { type, value } = describeDiscount(terms);
  return {
    mapping,
    coupon,
    applied: { code, type, value, label: couponLabel(type, value, product.currency) },
    price: result.price,
  };
}

/** The reserved or redeemed row for (code, user), if any. */
export async function findActiveRedemption(couponCodeId: string, userId: string): Promise<CouponRedemption | undefined> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.couponRedemptions)
    .where(
      and(
        eq(schema.couponRedemptions.couponCodeId, couponCodeId),
        eq(schema.couponRedemptions.userId, userId),
        inArray(schema.couponRedemptions.status, ["reserved", "redeemed"]),
      ),
    )
    .limit(1);
  return rows[0];
}

export type QuoteResult =
  | { valid: true; coupon: AppliedCoupon; price: Price; message: string }
  | { valid: false; reason: CouponRejectionReason; message: string; price: Price };

/** Read-only check used by `POST /api/coupons/validate`. Nothing is reserved here. */
export async function quoteCoupon(params: { code: unknown; product: SiteProduct; userId: string | null }): Promise<QuoteResult> {
  const { product } = params;
  const fallback = basePrice(product.amount, product.currency);
  try {
    if (!normalizeCouponCode(params.code)) throw new CouponRejectedError("invalid_format");
    // Per-account coupons: anonymous visitors are asked to sign in before we
    // even say whether a code exists (prevents guessing codes without an account).
    if (!params.userId) throw new CouponRejectedError("auth_required");
    const resolved = await resolveCoupon(params.code, product);
    const existing = await findActiveRedemption(resolved.mapping.id, params.userId);
    if (existing?.status === "redeemed") throw new CouponRejectedError("already_redeemed");
    return {
      valid: true,
      coupon: resolved.applied,
      price: resolved.price,
      message: `تم تطبيق الكوبون: ${resolved.applied.label}`,
    };
  } catch (err) {
    if (err instanceof CouponRejectedError) {
      return { valid: false, reason: err.reason, message: err.message, price: fallback };
    }
    throw err;
  }
}

// ---------------------------------------------------------------------------
// Redemption lifecycle: reserved → redeemed | released
// ---------------------------------------------------------------------------

/**
 * Inserts the `reserved` row. The partial unique index
 * (coupon_code_id, user_id) WHERE status IN ('reserved','redeemed') makes this
 * the single source of truth: two concurrent checkouts cannot both reserve.
 * Returns null when another active row exists (caller decides what to do).
 */
export async function tryReserve(params: {
  mapping: CouponCode;
  userId: string;
  price: Price;
}): Promise<CouponRedemption | null> {
  const db = getDb();
  try {
    const [row] = await db
      .insert(schema.couponRedemptions)
      .values({
        couponCodeId: params.mapping.id,
        streamCouponId: params.mapping.streamCouponId,
        userId: params.userId,
        status: "reserved",
        discountAmount: params.price.discount.toFixed(2),
        currency: params.price.currency,
      })
      .returning();
    return row;
  } catch (err) {
    if (isUniqueViolation(err)) return null;
    throw err;
  }
}

export async function attachOrderToRedemption(redemptionId: string, orderId: string, discount: number) {
  const db = getDb();
  await db
    .update(schema.couponRedemptions)
    .set({ orderId, discountAmount: discount.toFixed(2), updatedAt: new Date() })
    .where(eq(schema.couponRedemptions.id, redemptionId));
}

export async function releaseRedemption(redemptionId: string, reason: string) {
  const db = getDb();
  await db
    .update(schema.couponRedemptions)
    .set({ status: "released", releaseReason: reason.slice(0, 200), updatedAt: new Date() })
    .where(and(eq(schema.couponRedemptions.id, redemptionId), eq(schema.couponRedemptions.status, "reserved")));
}

/** Called when an order's invoice is dead (expired / cancelled / rejected): the user may try again. */
export async function releaseCouponForOrder(orderId: string, reason: string) {
  const db = getDb();
  await db
    .update(schema.couponRedemptions)
    .set({ status: "released", releaseReason: reason.slice(0, 200), updatedAt: new Date() })
    .where(and(eq(schema.couponRedemptions.orderId, orderId), eq(schema.couponRedemptions.status, "reserved")));
}

/**
 * Called once Stream has confirmed the (discounted) payment. From now on the
 * same user can never reserve this code again.
 */
export async function markCouponRedeemed(orderId: string): Promise<boolean> {
  const db = getDb();
  try {
    const rows = await db
      .update(schema.couponRedemptions)
      .set({ status: "redeemed", redeemedAt: new Date(), updatedAt: new Date() })
      .where(and(eq(schema.couponRedemptions.orderId, orderId), sql`${schema.couponRedemptions.status} <> 'redeemed'`))
      .returning({ id: schema.couponRedemptions.id });
    return rows.length > 0;
  } catch (err) {
    // A released row whose old link got paid while a newer reservation exists.
    if (isUniqueViolation(err)) {
      console.warn(`[coupons] order ${orderId} paid with a coupon the user had already re-reserved`);
      return false;
    }
    throw err;
  }
}

// ---------------------------------------------------------------------------
// Admin
// ---------------------------------------------------------------------------

export async function listCouponCodes() {
  const db = getDb();
  const codes = await db.select().from(schema.couponCodes).orderBy(desc(schema.couponCodes.createdAt));
  const counts = await db
    .select({
      couponCodeId: schema.couponRedemptions.couponCodeId,
      status: schema.couponRedemptions.status,
      n: sql<number>`count(*)::int`,
    })
    .from(schema.couponRedemptions)
    .groupBy(schema.couponRedemptions.couponCodeId, schema.couponRedemptions.status);
  return codes.map((c) => {
    const mine = counts.filter((r) => r.couponCodeId === c.id);
    const get = (s: string) => mine.find((r) => r.status === s)?.n ?? 0;
    return { ...c, redeemed: get("redeemed"), reserved: get("reserved"), released: get("released") };
  });
}

export async function listRecentRedemptions(limit = 50) {
  const db = getDb();
  return db
    .select({
      id: schema.couponRedemptions.id,
      status: schema.couponRedemptions.status,
      discountAmount: schema.couponRedemptions.discountAmount,
      currency: schema.couponRedemptions.currency,
      releaseReason: schema.couponRedemptions.releaseReason,
      createdAt: schema.couponRedemptions.createdAt,
      redeemedAt: schema.couponRedemptions.redeemedAt,
      orderId: schema.couponRedemptions.orderId,
      code: schema.couponCodes.code,
      userEmail: schema.users.email,
    })
    .from(schema.couponRedemptions)
    .innerJoin(schema.couponCodes, eq(schema.couponRedemptions.couponCodeId, schema.couponCodes.id))
    .innerJoin(schema.users, eq(schema.couponRedemptions.userId, schema.users.id))
    .orderBy(desc(schema.couponRedemptions.createdAt))
    .limit(limit);
}

export class CouponAdminError extends Error {}

/** Maps a public code to an existing Stream coupon (verified against Stream first). */
export async function createCouponCode(params: {
  code: string;
  streamCouponId: string;
  note?: string | null;
  createdByEmail: string;
}): Promise<CouponCode> {
  const code = normalizeCouponCode(params.code);
  if (!code) throw new CouponAdminError("الرمز يجب أن يكون من 2 إلى 40 حرفاً أو رقماً (يسمح بـ - و _).");
  const coupon = await fetchStreamCoupon(params.streamCouponId).catch(() => null);
  if (!coupon) throw new CouponAdminError("لم يتم العثور على هذا الكوبون في Stream.");
  const db = getDb();
  try {
    const [row] = await db
      .insert(schema.couponCodes)
      .values({
        code,
        streamCouponId: coupon.id,
        streamCouponName: coupon.name,
        note: params.note?.trim() || null,
        createdByEmail: params.createdByEmail,
      })
      .returning();
    return row;
  } catch (err) {
    if (isUniqueViolation(err)) throw new CouponAdminError(`الرمز "${code}" مستخدم من قبل.`);
    throw err;
  }
}

export async function setCouponCodeActive(id: string, isActive: boolean): Promise<CouponCode | undefined> {
  const db = getDb();
  const [row] = await db
    .update(schema.couponCodes)
    .set({ isActive, updatedAt: new Date() })
    .where(eq(schema.couponCodes.id, id))
    .returning();
  return row;
}
