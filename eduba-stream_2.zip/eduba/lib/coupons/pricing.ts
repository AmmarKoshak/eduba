/**
 * Pure coupon rules (no I/O) so they can be unit-tested and reused by any
 * backend. The frontend never calls these directly: it receives the computed
 * price from the API.
 */

export interface CouponTerms {
  /** Stream: `is_percentage` */
  isPercentage: boolean;
  /** Stream: `discount_value` (decimal string or number) */
  discountValue: number | string;
  /** Stream: `currency` (fixed-amount coupons only) */
  currency?: string | null;
}

export interface PriceBreakdown {
  currency: string;
  original: number;
  discount: number;
  total: number;
}

/** Codes are case-insensitive and stored trimmed + lower-cased. */
export function normalizeCouponCode(input: unknown): string | null {
  if (typeof input !== "string") return null;
  const code = input.normalize("NFKC").trim().toLowerCase();
  // Letters (any script), digits, dash, underscore; 2–40 characters.
  if (!/^[\p{L}\p{N}_-]{2,40}$/u.test(code)) return null;
  return code;
}

export function roundMoney(n: number): number {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

export function basePrice(amount: number, currency: string): PriceBreakdown {
  return { currency, original: roundMoney(amount), discount: 0, total: roundMoney(amount) };
}

export type DiscountResult =
  | { ok: true; price: PriceBreakdown }
  | { ok: false; reason: "currency_mismatch" | "not_applicable" };

/**
 * Applies one coupon to a price, the way Stream does at payment-link level:
 * percentage of the amount, or a fixed amount in the same currency, never
 * below zero. A coupon that would make the payment 0 is rejected here because
 * a paid checkout needs something to charge.
 */
export function applyCoupon(amount: number, currency: string, terms: CouponTerms): DiscountResult {
  const value = Number(terms.discountValue);
  if (!Number.isFinite(value) || value <= 0) return { ok: false, reason: "not_applicable" };

  let discount: number;
  if (terms.isPercentage) {
    if (value > 100) return { ok: false, reason: "not_applicable" };
    discount = roundMoney((amount * value) / 100);
  } else {
    if (!terms.currency || terms.currency.toUpperCase() !== currency.toUpperCase()) {
      return { ok: false, reason: "currency_mismatch" };
    }
    discount = roundMoney(value);
  }
  discount = Math.min(discount, roundMoney(amount));
  const total = roundMoney(amount - discount);
  if (total <= 0) return { ok: false, reason: "not_applicable" };
  return { ok: true, price: { currency, original: roundMoney(amount), discount, total } };
}

/** Short human label for the discount, e.g. "10%" or "50 SAR". */
export function describeDiscount(terms: CouponTerms): { type: "percentage" | "fixed"; value: number } {
  return { type: terms.isPercentage ? "percentage" : "fixed", value: Number(terms.discountValue) };
}
