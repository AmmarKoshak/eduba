import "server-only";
import { eq, sql } from "drizzle-orm";
import { getDb, schema } from "@/lib/db";
import { releaseCouponForOrder } from "@/lib/coupons/service";
import { recordOrderFailure, syncSubscription, verifyOrderPayment } from "@/lib/checkout/service";
import { stream } from "./client";
import type { StreamWebhookPayload } from "./types";

/**
 * Idempotency key for a delivery. Stream does not send a delivery id, so the
 * key combines event type, entity id and the event timestamp (which is stable
 * across retries of the same delivery).
 */
export function eventKeyFor(payload: StreamWebhookPayload, headers: { entityId?: string | null; event?: string | null; timestamp?: string | null }): string {
  const type = payload.event_type ?? headers.event ?? "UNKNOWN";
  const entity = payload.entity_id ?? headers.entityId ?? "unknown";
  const ts = payload.timestamp ?? headers.timestamp ?? "";
  const status = payload.status ?? "";
  return `${type}:${entity}:${ts}:${status}`;
}

/**
 * Records the delivery. Returns `duplicate: true` when an identical delivery
 * was already processed successfully, so the handler can be skipped.
 */
export async function registerDelivery(eventKey: string, payload: StreamWebhookPayload) {
  const db = getDb();
  const [row] = await db
    .insert(schema.webhookEvents)
    .values({
      eventKey,
      eventType: payload.event_type ?? "UNKNOWN",
      entityType: payload.entity_type ?? null,
      entityId: payload.entity_id ?? null,
      status: payload.status ?? null,
      payload,
    })
    .onConflictDoUpdate({
      target: schema.webhookEvents.eventKey,
      set: { attempts: sql`${schema.webhookEvents.attempts} + 1` },
    })
    .returning({ id: schema.webhookEvents.id, processedAt: schema.webhookEvents.processedAt, attempts: schema.webhookEvents.attempts });
  return { id: row.id, duplicate: row.processedAt !== null, attempts: row.attempts };
}

export async function markDelivery(id: string, outcome: { ok: true } | { ok: false; error: string }) {
  const db = getDb();
  await db
    .update(schema.webhookEvents)
    .set(outcome.ok ? { processedAt: new Date(), error: null } : { error: outcome.error })
    .where(eq(schema.webhookEvents.id, id));
}

async function findOrderIdForInvoice(invoiceId: string, metadataOrderId?: unknown): Promise<string | null> {
  const db = getDb();
  if (typeof metadataOrderId === "string" && /^[0-9a-f-]{36}$/i.test(metadataOrderId)) {
    const byMeta = await db
      .select({ id: schema.orders.id })
      .from(schema.orders)
      .where(eq(schema.orders.id, metadataOrderId))
      .limit(1);
    if (byMeta[0]) return byMeta[0].id;
  }
  const byInvoice = await db
    .select({ id: schema.orders.id })
    .from(schema.orders)
    .where(eq(schema.orders.invoiceId, invoiceId))
    .limit(1);
  if (byInvoice[0]) return byInvoice[0].id;

  // Fall back to the payment link the invoice was paid through (fetched from Stream, never from the payload).
  const invoice = await stream().getInvoice(invoiceId);
  if (!invoice.payment_link_id) return null;
  const byLink = await db
    .select({ id: schema.orders.id })
    .from(schema.orders)
    .where(eq(schema.orders.paymentLinkId, invoice.payment_link_id))
    .limit(1);
  return byLink[0]?.id ?? null;
}

/**
 * Applies a verified webhook. Every branch re-reads the entity from Stream and
 * writes the resulting state, so re-running it is harmless (idempotent).
 */
export async function handleStreamEvent(payload: StreamWebhookPayload): Promise<string> {
  const type = payload.event_type;
  const data = payload.data ?? {};
  const invoiceId = data.invoice?.id;
  const metaOrderId = data.metadata?.order_id;

  switch (type) {
    case "PAYMENT_SUCCEEDED":
    case "PAYMENT_MARKED_AS_PAID":
    case "INVOICE_COMPLETED": {
      if (!invoiceId) return "no invoice in payload";
      const orderId = await findOrderIdForInvoice(invoiceId, metaOrderId);
      if (!orderId) return "no matching order (payment made outside the website)";
      const { verdict } = await verifyOrderPayment(orderId, { invoiceId, paymentId: data.payment?.id ?? null });
      return `order ${orderId}: ${verdict.state}`;
    }

    case "PAYMENT_FAILED":
    case "PAYMENT_LINK_PAY_ATTEMPT_FAILED":
    case "INVOICE_REJECTED":
    case "INVOICE_CANCELED":
    case "INVOICE_EXPIRED":
    case "PAYMENT_EXPIRED": {
      // A declined card leaves the link usable (the payer can retry), so the coupon
      // stays reserved; a dead invoice/link gives the coupon back to the user.
      const terminal = type.startsWith("INVOICE_") || type === "PAYMENT_EXPIRED";
      let orderId: string | null = null;
      if (invoiceId) orderId = await findOrderIdForInvoice(invoiceId, metaOrderId);
      else if (typeof metaOrderId === "string" && /^[0-9a-f-]{36}$/i.test(metaOrderId)) orderId = metaOrderId;
      if (!orderId) return invoiceId ? "no matching order" : "nothing to update";
      await recordOrderFailure(orderId, type);
      if (terminal) await releaseCouponForOrder(orderId, type);
      return `order ${orderId}: ${type}`;
    }

    case "PAYMENT_REFUNDED":
    case "PAYMENT_PARTIALLY_REFUNDED": {
      if (!invoiceId) return "no invoice in payload";
      const orderId = await findOrderIdForInvoice(invoiceId, metaOrderId);
      if (!orderId) return "no matching order";
      const db = getDb();
      await db
        .update(schema.orders)
        .set({ status: type === "PAYMENT_REFUNDED" ? "refunded" : undefined, lastError: type, updatedAt: new Date() })
        .where(eq(schema.orders.id, orderId));
      return `order ${orderId}: ${type}`;
    }

    default: {
      if (type.startsWith("SUBSCRIPTION_")) {
        const subId = payload.entity_type === "SUBSCRIPTION" ? payload.entity_id : data.subscription?.id;
        if (!subId) return "no subscription id in payload";
        const row = await syncSubscription(subId);
        return row ? `subscription ${subId}: ${row.status}` : `subscription ${subId}: not ours`;
      }
      return `ignored ${type}`;
    }
  }
}
