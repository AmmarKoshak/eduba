/**
 * One-time coupon redemption against a real Postgres (DATABASE_URL from .env).
 * Stream is replaced by an in-memory fake; the database (and its partial unique
 * index) is real, because that is what enforces "once per user".
 * Skipped automatically when no database is reachable.
 */
import { randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { inArray } from "drizzle-orm";

const COUPON_ID = "c0ffee00-0000-4000-8000-0000000000a1";
const INACTIVE_COUPON_ID = "c0ffee00-0000-4000-8000-0000000000a2";
const suffix = randomUUID().slice(0, 8);
const CODE = `xz21-${suffix}`;
const OFF_CODE = `off-${suffix}`;

type FakeLink = { id: string; url: string; amount: string; status: string; payload: Record<string, unknown>; invoice?: Record<string, unknown> };
const links = new Map<string, FakeLink>();
const consumers = new Map<string, { id: string; name: string; email: string; phone_number: string }>();

const fakeStream = {
  getCoupon: vi.fn(async (id: string) => {
    if (id === COUPON_ID) return { id, name: "xz21", discount_value: "10.000", is_percentage: true, currency: null, is_active: true };
    if (id === INACTIVE_COUPON_ID) return { id, name: "old", discount_value: "20.000", is_percentage: true, currency: null, is_active: false };
    const { StreamApiError } = await import("@/lib/stream/client");
    throw new StreamApiError("not found", 404);
  }),
  listConsumers: vi.fn(async ({ search_term }: { search_term: string }) => ({
    data: [...consumers.values()].filter((c) => c.email === search_term || c.phone_number === search_term),
    pagination: {},
  })),
  createConsumer: vi.fn(async (body: { name: string; email: string; phone_number: string }) => {
    const c = { id: randomUUID(), ...body };
    consumers.set(c.id, c);
    return c;
  }),
  createPaymentLink: vi.fn(async (payload: Record<string, unknown>) => {
    const id = randomUUID();
    const discounted = (payload.coupons as string[] | undefined)?.includes(COUPON_ID);
    const link: FakeLink = { id, url: `https://pay.example/${id}`, amount: discounted ? "103.50" : "115.00", status: "ACTIVE", payload };
    links.set(id, link);
    return { id, url: link.url, amount: link.amount, status: "ACTIVE" };
  }),
  updatePaymentLinkStatus: vi.fn(async (id: string, status: string) => {
    const l = links.get(id)!;
    if (l.status === "COMPLETED") throw new Error("completed");
    l.status = status;
    return { id, status };
  }),
  getInvoice: vi.fn(async (id: string) => {
    const link = [...links.values()].find((l) => l.invoice?.id === id);
    return link!.invoice;
  }),
  listInvoices: vi.fn(async ({ payment_link_id }: { payment_link_id: string }) => {
    const l = links.get(payment_link_id);
    return { data: l?.invoice ? [l.invoice] : [], pagination: {} };
  }),
  getSubscription: vi.fn(async (id: string) => ({ id, status: "ACTIVE", amount: "103.50", currency: "SAR" })),
};

vi.mock("@/lib/stream/client", async (importOriginal) => {
  const mod = await importOriginal<typeof import("@/lib/stream/client")>();
  return { ...mod, stream: () => fakeStream };
});

/** Simulates the payer completing (or abandoning) the hosted page. */
function settleLink(linkId: string, outcome: "paid" | "expired") {
  const l = links.get(linkId)!;
  const payload = l.payload as { organization_consumer_id: string };
  l.invoice = {
    id: randomUUID(),
    payment_link_id: linkId,
    organization_consumer_id: payload.organization_consumer_id,
    currency: "SAR",
    total_amount: l.amount,
    paid_amount: outcome === "paid" ? l.amount : "0",
    status: outcome === "paid" ? "COMPLETED" : "EXPIRED",
    type: "ONE_OFF",
    payments: outcome === "paid" ? [{ id: randomUUID(), current_status: "SUCCEEDED", payed_at: new Date().toISOString(), amount: l.amount }] : [],
  };
  if (outcome === "paid") l.status = "COMPLETED";
}

let dbAvailable = false;
let db: ReturnType<typeof import("@/lib/db")["getDb"]>;
let schema: typeof import("@/lib/db/schema");
let svc: typeof import("@/lib/checkout/service");
let coupons: typeof import("@/lib/coupons/service");
let products: typeof import("@/lib/products");
const userIds: string[] = [];
let mappingIds: string[] = [];

async function makeUser(tag: string) {
  const [u] = await db
    .insert(schema.users)
    .values({ email: `${tag}-${suffix}@example.com`, name: `User ${tag}`, passwordHash: "x" })
    .returning();
  userIds.push(u.id);
  return u;
}

function checkoutInput(user: { id: string; email: string }, code: string | null, phone: string) {
  return { productKey: "pro_monthly", name: "Test Payer", email: user.email, phone, userId: user.id, couponCode: code };
}

beforeAll(async () => {
  if (!process.env.DATABASE_URL) return;
  try {
    const dbMod = await import("@/lib/db");
    schema = await import("@/lib/db/schema");
    db = dbMod.getDb();
    await db.execute("select 1 from coupon_redemptions limit 1");
    dbAvailable = true;
  } catch {
    dbAvailable = false;
    return;
  }
  svc = await import("@/lib/checkout/service");
  coupons = await import("@/lib/coupons/service");
  products = await import("@/lib/products");
  const rows = await db
    .insert(schema.couponCodes)
    .values([
      { code: CODE, streamCouponId: COUPON_ID, streamCouponName: "xz21" },
      { code: OFF_CODE, streamCouponId: INACTIVE_COUPON_ID, streamCouponName: "old" },
    ])
    .returning();
  mappingIds = rows.map((r) => r.id);
});

afterAll(async () => {
  if (!dbAvailable) return;
  await db.delete(schema.couponRedemptions).where(inArray(schema.couponRedemptions.couponCodeId, mappingIds));
  const orderRows = await db.select({ id: schema.orders.id, customerId: schema.orders.customerId }).from(schema.orders).where(inArray(schema.orders.userId, userIds));
  if (orderRows.length) {
    await db.delete(schema.orders).where(inArray(schema.orders.id, orderRows.map((o) => o.id)));
    await db.delete(schema.customers).where(inArray(schema.customers.id, orderRows.map((o) => o.customerId)));
  }
  await db.delete(schema.couponCodes).where(inArray(schema.couponCodes.id, mappingIds));
  await db.delete(schema.users).where(inArray(schema.users.id, userIds));
});

describe("coupon redemption (DB)", () => {
  it("validates codes through the backend mapping and Stream", async () => {
    if (!dbAvailable) return;
    const pro = products.PRODUCTS.pro_monthly;
    const u = await makeUser("quote");

    expect(await coupons.quoteCoupon({ code: CODE, product: pro, userId: null })).toMatchObject({ valid: false, reason: "auth_required" });
    expect(await coupons.quoteCoupon({ code: "nope-" + suffix, product: pro, userId: u.id })).toMatchObject({ valid: false, reason: "not_found" });
    expect(await coupons.quoteCoupon({ code: "x", product: pro, userId: u.id })).toMatchObject({ valid: false, reason: "invalid_format" });
    expect(await coupons.quoteCoupon({ code: OFF_CODE, product: pro, userId: u.id })).toMatchObject({ valid: false, reason: "inactive" });

    const ok = await coupons.quoteCoupon({ code: CODE.toUpperCase(), product: pro, userId: u.id });
    expect(ok).toMatchObject({ valid: true, coupon: { code: CODE, type: "percentage", value: 10 }, price: { original: 115, discount: 11.5, total: 103.5 } });
  });

  it("charges the discounted amount, then blocks a second redemption by the same user", async () => {
    if (!dbAvailable) return;
    const u = await makeUser("once");
    const first = await svc.createCheckout(checkoutInput(u, CODE, "0500000101"));
    expect(first.price).toEqual({ currency: "SAR", original: 115, discount: 11.5, total: 103.5 });
    expect(first.coupon?.code).toBe(CODE);
    const firstLink = [...links.values()].find((l) => l.url === first.paymentLinkUrl.split("?")[0])!;
    expect(firstLink.payload.coupons).toEqual([COUPON_ID]);

    const order = await svc.getOrder(first.orderId);
    expect(order).toMatchObject({ amount: "103.50", originalAmount: "115.00", discountAmount: "11.50", streamCouponId: COUPON_ID });

    // Payer abandons and starts again: the old discounted link is switched off and the coupon re-reserved.
    const second = await svc.createCheckout(checkoutInput(u, CODE, "0500000101"));
    expect(fakeStream.updatePaymentLinkStatus).toHaveBeenCalledWith(firstLink.id, "INACTIVE");
    expect((await svc.getOrder(first.orderId))?.status).toBe("expired");

    // Stream confirms the second payment → redeemed.
    const secondLink = [...links.values()].find((l) => l.url === second.paymentLinkUrl.split("?")[0])!;
    settleLink(secondLink.id, "paid");
    const { verdict } = await svc.verifyOrderPayment(second.orderId);
    expect(verdict.state).toBe("paid");
    const rows = await db.select().from(schema.couponRedemptions).where(inArray(schema.couponRedemptions.userId, [u.id]));
    expect(rows.map((r) => r.status).sort()).toEqual(["redeemed", "released"]);

    // Same user, same code: rejected by preview AND by checkout (backend enforcement).
    expect(await coupons.quoteCoupon({ code: CODE, product: products.PRODUCTS.pro_monthly, userId: u.id })).toMatchObject({ valid: false, reason: "already_redeemed" });
    await expect(svc.createCheckout(checkoutInput(u, CODE, "0500000101"))).rejects.toMatchObject({ reason: "already_redeemed" });

    // Without the coupon the same user can still buy at full price.
    const full = await svc.createCheckout(checkoutInput(u, null, "0500000101"));
    expect(full.price.total).toBe(115);
  });

  it("lets other users redeem the same code", async () => {
    if (!dbAvailable) return;
    const other = await makeUser("other");
    const r = await svc.createCheckout(checkoutInput(other, CODE, "0500000102"));
    expect(r.price.total).toBe(103.5);
  });

  it("gives the coupon back when the invoice dies unpaid", async () => {
    if (!dbAvailable) return;
    const u = await makeUser("expired");
    const r = await svc.createCheckout(checkoutInput(u, CODE, "0500000103"));
    const link = [...links.values()].find((l) => l.url === r.paymentLinkUrl.split("?")[0])!;
    settleLink(link.id, "expired");
    expect((await svc.verifyOrderPayment(r.orderId)).verdict.state).toBe("failed");
    expect(await coupons.quoteCoupon({ code: CODE, product: products.PRODUCTS.pro_monthly, userId: u.id })).toMatchObject({ valid: true });
  });

  it("never leaves two live discounted checkouts for simultaneous requests", async () => {
    if (!dbAvailable) return;
    const u = await makeUser("race");
    const results = await Promise.allSettled([
      svc.createCheckout(checkoutInput(u, CODE, "0500000104")),
      svc.createCheckout(checkoutInput(u, CODE, "0500000104")),
    ]);
    // Depending on timing the second request is either refused (in_progress) or
    // supersedes the first one (old link switched off). Never two live ones.
    for (const r of results) {
      if (r.status === "rejected") expect(r.reason).toMatchObject({ reason: "in_progress" });
    }
    expect(results.some((r) => r.status === "fulfilled")).toBe(true);
    const active = await db.select().from(schema.couponRedemptions).where(inArray(schema.couponRedemptions.userId, [u.id]));
    expect(active.filter((r) => r.status === "reserved" || r.status === "redeemed")).toHaveLength(1);
    const orders = await db.select().from(schema.orders).where(inArray(schema.orders.userId, [u.id]));
    const liveLinks = orders.filter((o) => links.get(o.paymentLinkId)?.status === "ACTIVE");
    expect(liveLinks).toHaveLength(1);
    expect(orders.filter((o) => o.status === "pending")).toHaveLength(1);
  });

  it("enforces one active redemption per user and code in Postgres itself", async () => {
    if (!dbAvailable) return;
    const u = await makeUser("index");
    const values = { couponCodeId: mappingIds[0], streamCouponId: COUPON_ID, userId: u.id, discountAmount: "11.50" };
    await db.insert(schema.couponRedemptions).values({ ...values, status: "redeemed" });
    await expect(db.insert(schema.couponRedemptions).values({ ...values, status: "reserved" })).rejects.toThrow();
    // released rows do not count
    await db.insert(schema.couponRedemptions).values({ ...values, status: "released" });
  });
});
