import { describe, expect, it } from "vitest";
import { applyCoupon, basePrice, normalizeCouponCode } from "@/lib/coupons/pricing";
import { buildPaymentLinkPayload } from "@/lib/checkout/payment-link";
import { PRODUCTS } from "@/lib/products";

describe("normalizeCouponCode", () => {
  it("is case-insensitive and trims", () => {
    expect(normalizeCouponCode("  XZ21 ")).toBe("xz21");
    expect(normalizeCouponCode("Summer_2026-a")).toBe("summer_2026-a");
  });
  it("accepts Arabic letters and digits", () => {
    expect(normalizeCouponCode("خصم10")).toBe("خصم10");
  });
  it("rejects empty, too short, too long and symbols", () => {
    for (const bad of ["", " ", "a", "x".repeat(41), "xz 21", "xz21;drop", "<script>", 21, null, undefined]) {
      expect(normalizeCouponCode(bad as unknown)).toBeNull();
    }
  });
});

describe("applyCoupon", () => {
  it("applies a percentage coupon (10% of 115 SAR)", () => {
    const r = applyCoupon(115, "SAR", { isPercentage: true, discountValue: "10.000", currency: null });
    expect(r).toEqual({ ok: true, price: { currency: "SAR", original: 115, discount: 11.5, total: 103.5 } });
  });
  it("rounds to halalas", () => {
    const r = applyCoupon(115, "SAR", { isPercentage: true, discountValue: "13", currency: null });
    expect(r.ok && r.price).toEqual({ currency: "SAR", original: 115, discount: 14.95, total: 100.05 });
  });
  it("applies a fixed coupon in the same currency", () => {
    const r = applyCoupon(115, "SAR", { isPercentage: false, discountValue: "50.000", currency: "SAR" });
    expect(r.ok && r.price.total).toBe(65);
  });
  it("rejects a fixed coupon in another currency", () => {
    expect(applyCoupon(115, "SAR", { isPercentage: false, discountValue: 10, currency: "USD" })).toEqual({ ok: false, reason: "currency_mismatch" });
  });
  it("rejects coupons that would make the payment 0 or are nonsensical", () => {
    expect(applyCoupon(115, "SAR", { isPercentage: true, discountValue: 100 })).toEqual({ ok: false, reason: "not_applicable" });
    expect(applyCoupon(115, "SAR", { isPercentage: false, discountValue: 1000, currency: "SAR" })).toEqual({ ok: false, reason: "not_applicable" });
    expect(applyCoupon(115, "SAR", { isPercentage: true, discountValue: 0 })).toEqual({ ok: false, reason: "not_applicable" });
    expect(applyCoupon(115, "SAR", { isPercentage: true, discountValue: 150 })).toEqual({ ok: false, reason: "not_applicable" });
  });
  it("base price has no discount", () => {
    expect(basePrice(115, "SAR")).toEqual({ currency: "SAR", original: 115, discount: 0, total: 115 });
  });
});

describe("payment link with coupon", () => {
  const base = {
    product: PRODUCTS.pro_monthly,
    streamProductId: "prod-1",
    consumerId: "cons-1",
    orderId: "order-1",
    appUrl: "https://eduba.test",
    now: new Date("2026-11-09T00:00:00Z"),
  };
  it("passes Stream coupon UUIDs at link level", () => {
    const p = buildPaymentLinkPayload({ ...base, couponIds: ["c0ffee00-0000-4000-8000-000000000001"] });
    expect(p.coupons).toEqual(["c0ffee00-0000-4000-8000-000000000001"]);
    expect(p.items).toEqual([{ product_id: "prod-1", quantity: 1 }]);
  });
  it("omits coupons when none are given", () => {
    expect(buildPaymentLinkPayload(base).coupons).toBeUndefined();
  });
});
