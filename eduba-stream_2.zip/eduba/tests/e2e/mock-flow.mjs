#!/usr/bin/env node
/**
 * End-to-end run against the local mock Stream server.
 *
 * Prerequisites (three terminals, or background processes):
 *   npm run stream:mock                # mock Stream API + hosted checkout on :4567
 *   npm run build && npm run start     # the site on :3000 with .env pointing at the mock
 *   node tests/e2e/mock-flow.mjs       # this script (needs playwright + chromium installed)
 *
 * Env: E2E_BASE_URL (default http://localhost:3000), E2E_ADMIN_EMAIL / E2E_ADMIN_PASSWORD
 * (defaults match `npm run user:create` in the README), E2E_SHOTS=dir for screenshots.
 */
import { chromium } from "playwright";
import { mkdir } from "node:fs/promises";

const BASE = (process.env.E2E_BASE_URL ?? "http://localhost:3000").replace(/\/+$/, "");
const ADMIN_EMAIL = process.env.E2E_ADMIN_EMAIL ?? "ammarkoshak@streampay.sa";
const ADMIN_PASSWORD = process.env.E2E_ADMIN_PASSWORD ?? "Admin12345!";
const SHOTS = process.env.E2E_SHOTS ?? "";
if (SHOTS) await mkdir(SHOTS, { recursive: true });

const results = [];
const step = async (name, fn) => {
  try {
    const detail = await fn();
    results.push({ name, ok: true, detail });
    console.log(`✓ ${name}${detail ? ` — ${detail}` : ""}`);
  } catch (err) {
    results.push({ name, ok: false, detail: err.message });
    console.log(`✗ ${name} — ${err.message}`);
  }
};
const shot = async (page, name, full = false) => {
  if (SHOTS) await page.screenshot({ path: `${SHOTS}/${name}.png`, fullPage: full });
};
const expect = (cond, msg) => {
  if (!cond) throw new Error(msg);
};

/** Fills the checkout form (optionally applies a coupon) and follows the redirect to Stream's hosted page. */
async function startCheckout(p, { plan = "pro_monthly", phone, coupon } = {}) {
  await p.goto(`${BASE}/checkout?plan=${plan}`, { waitUntil: "networkidle" });
  if (phone) await p.fill("#phone", phone);
  if (coupon) {
    await p.fill("[data-testid=coupon-input]", coupon);
    await p.click("[data-testid=coupon-apply]");
    await p.waitForSelector("[data-testid=coupon-feedback][data-state=applied]");
  }
  await Promise.all([p.waitForURL(/\/ds\//), p.click("[data-testid=checkout-submit]")]);
  return p.url();
}

const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1366, height: 900 }, locale: "ar-SA", deviceScaleFactor: 1 });
const page = await ctx.newPage();
page.setDefaultTimeout(20000);

await step("home page renders all sections", async () => {
  await page.goto(`${BASE}/`);
  const text = await page.locator("main").innerText();
  for (const t of ["أذكى من المدرس الخصوصي", "لماذا تدفع أكثر", "ادرس بطريقتك", "لوحة تحكم ولي الأمر", "إيدوبا Pro", "115", "الأسئلة الشائعة", "بيت الألواح"]) {
    expect(text.includes(t), `missing "${t}"`);
  }
  await shot(page, "01-home-desktop", true);
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto(`${BASE}/#pricing`);
  await shot(page, "02-home-mobile", true);
  await page.setViewportSize({ width: 1366, height: 900 });
});

await step("sign-in as admin", async () => {
  await page.goto(`${BASE}/sign-in`);
  await shot(page, "03-sign-in");
  await page.fill("#identifier", ADMIN_EMAIL);
  await page.fill("#password", ADMIN_PASSWORD);
  await page.click("button[type=submit]");
  await page.waitForURL(/\/account/);
  expect((await page.locator("h1").innerText()).includes("مرحباً"), "account greeting missing");
  await shot(page, "04-account-free");
});

let successUrl = "";
await step("checkout: no embedded card form; redirect to Stream's hosted page", async () => {
  await page.goto(`${BASE}/checkout?plan=pro_monthly`, { waitUntil: "networkidle" });
  expect((await page.inputValue("#email")) === ADMIN_EMAIL, "email not prefilled");
  expect((await page.locator("iframe").count()) === 0, "embedded payment iframe should be gone");
  expect((await page.locator("[data-testid=coupon-input]").count()) === 1, "coupon field missing");
  await shot(page, "05-checkout-form");
  const href = await startCheckout(page, { phone: "0500000001" });
  expect(href.includes("language=ar"), "language=ar missing from checkout URL");
  await shot(page, "06-stream-hosted-page");
  return href;
});

await step("pay with an approved card on the hosted page → verified success page", async () => {
  await page.click("a:has-text('ادفع الآن')");
  await page.waitForURL(/\/checkout\/success/);
  successUrl = page.url();
  await page.waitForSelector("text=تم الدفع بنجاح", { timeout: 20000 });
  await shot(page, "08-success-paid");
  const url = new URL(successUrl);
  expect(url.searchParams.get("invoice_id"), "invoice_id missing from redirect");
  return `order ${url.searchParams.get("order")}`;
});

await step("tampered redirect (foreign invoice id) is NOT shown as paid", async () => {
  const url = new URL(successUrl);
  url.searchParams.set("invoice_id", "00000000-0000-4000-8000-000000000000");
  // order already paid → still paid (we trust our DB, not the query string)
  await page.goto(url.toString());
  const paid = await page.locator("text=تم الدفع بنجاح").count();
  expect(paid === 1, "paid order should stay paid regardless of query string");
});

await step("account shows the active subscription + portal button", async () => {
  await page.goto(`${BASE}/account`);
  const text = await page.locator("main").innerText();
  expect(text.includes("نشط"), "subscription not active");
  expect(text.includes("إدارة الاشتراك"), "portal button missing");
  await shot(page, "09-account-pro");
  await page.click("button:has-text('إدارة الاشتراك')");
  await page.waitForURL(/\/portal\?c=/);
  return "portal session opened";
});

await step("declined card → failure page, order stays unpaid", async () => {
  await startCheckout(page, { phone: "0500000001" });
  await page.click("a:has-text('بطاقة مرفوضة')");
  await page.waitForURL(/\/checkout\/failed/);
  await page.waitForSelector("text=لم تكتمل عملية الدفع");
  await shot(page, "10-failed");
  const order = new URL(page.url()).searchParams.get("order");
  await page.goto(`${BASE}/checkout/success?order=${order}`);
  const paid = await page.locator("text=تم الدفع بنجاح").count();
  expect(paid === 0, "a failed order must never render as paid");
  return `order ${order}`;
});

await step("installments on a one-time product (3 payments)", async () => {
  await startCheckout(page, { plan: "test_one_time", phone: "0500000001" });
  const inst = page.locator("a:has-text('قسّطها')");
  expect((await inst.count()) === 1, "installment option missing on the one-time product (payment_methods.installment not sent)");
  await inst.click();
  await page.waitForURL(/\/checkout\/(success|failed)/);
  await shot(page, "11-installments-result");
  // First instalment succeeded → Stream collects the rest; the purchase counts as paid.
  await page.waitForSelector("text=تم الدفع بنجاح");
  return "paid after first instalment";
});

await step("admin overview: revenue, active subscriptions, failed payments", async () => {
  await page.goto(`${BASE}/admin`);
  const text = await page.locator("main").innerText();
  await shot(page, "12-admin-overview", true);
  expect(text.includes("إيرادات هذا الشهر"), "summary cards missing");
  expect(text.includes("الاشتراكات النشطة"), "active subs card missing");
  return text.match(/إيرادات هذا الشهر\s+([^\n]+)/)?.[1]?.trim();
});

await step("admin invoices: filters + pagination + dashboard links", async () => {
  await page.goto(`${BASE}/admin/invoices?status=COMPLETED&limit=10`);
  const rows = await page.locator("tbody tr").count();
  expect(rows >= 1, "no completed invoices listed");
  const links = await page.locator("a:has-text('فتح في Stream')").count();
  expect(links >= 1, "dashboard links missing");
  await shot(page, "13-admin-invoices", true);
  await page.goto(`${BASE}/admin/invoices?status=DRAFT`);
  expect((await page.locator("text=لا توجد نتائج").count()) === 1, "status filter not applied");
  return `${rows} rows`;
});

await step("admin payments / subscriptions / customers pages", async () => {
  for (const [path, shotName] of [
    ["/admin/payments", "14-admin-payments"],
    ["/admin/subscriptions?status=ACTIVE", "15-admin-subscriptions"],
    ["/admin/customers?q=ammar", "16-admin-customers"],
  ]) {
    await page.goto(`${BASE}${path}`);
    expect((await page.locator("tbody tr").count()) >= 1, `${path} has no rows`);
    await shot(page, shotName, true);
  }
});

await step("coupon: anonymous visitor is asked to sign in (backend decides)", async () => {
  const ctxA = await browser.newContext({ viewport: { width: 1366, height: 900 } });
  const pa = await ctxA.newPage();
  await pa.goto(`${BASE}/checkout?plan=pro_monthly`, { waitUntil: "networkidle" });
  await pa.fill("[data-testid=coupon-input]", "XZ21");
  await pa.click("[data-testid=coupon-apply]");
  const fb = pa.locator("[data-testid=coupon-feedback][data-state=rejected]");
  await fb.waitFor();
  expect((await fb.getAttribute("data-reason")) === "auth_required", "expected auth_required");
  await shot(pa, "19-coupon-sign-in");
  await ctxA.close();
});

await step("coupon: unmapped code is rejected before mapping", async () => {
  await page.goto(`${BASE}/checkout?plan=pro_monthly`, { waitUntil: "networkidle" });
  await page.fill("[data-testid=coupon-input]", "xz21");
  await page.click("[data-testid=coupon-apply]");
  const fb = page.locator("[data-testid=coupon-feedback][data-state=rejected]");
  await fb.waitFor();
  expect((await fb.getAttribute("data-reason")) === "not_found", "unmapped code must be invalid");
  expect((await page.locator("[data-testid=price-total]").innerText()).includes("115"), "price must stay 115");
  await shot(page, "20-coupon-invalid");
});

await step("admin maps Stream coupon \"xz21\" to public code XZ21 (confirmation dialog)", async () => {
  await page.goto(`${BASE}/admin/coupons`, { waitUntil: "networkidle" });
  const row = page.locator("tr", { hasText: "xz21" }).filter({ hasText: "خصم 10%" }).first();
  await row.locator("button:has-text('ربط برمز')").click();
  const dialog = page.locator("dialog[open]");
  await dialog.locator("input[name=code]").fill("XZ21");
  await dialog.locator("button[type=submit]").click();
  await page.waitForSelector("[data-testid=admin-toast]");
  await dialog.locator("button:has-text('إغلاق')").click();
  await page.waitForSelector("table >> text=xz21");
  await shot(page, "21-admin-coupons", true);
});

await step("coupon XZ21: 10% off shown, Stream link charges 103.5, payment verified", async () => {
  await page.goto(`${BASE}/checkout?plan=pro_monthly`, { waitUntil: "networkidle" });
  await page.fill("#phone", "0500000001");
  await page.fill("[data-testid=coupon-input]", "XZ21");
  await page.click("[data-testid=coupon-apply]");
  await page.waitForSelector("[data-testid=coupon-feedback][data-state=applied]");
  const total = await page.locator("[data-testid=price-total]").innerText();
  expect(total.includes("103.5"), `discounted total not shown: ${total}`);
  expect((await page.locator("[data-testid=price-discount]").innerText()).includes("11.5"), "discount line missing");
  await shot(page, "22-coupon-applied");
  await Promise.all([page.waitForURL(/\/ds\//), page.click("[data-testid=checkout-submit]")]);
  const amount = await page.locator("#amount").innerText();
  expect(amount.includes("103.50"), `Stream hosted page amount ${amount}`);
  await shot(page, "23-stream-discounted");
  await page.click("a:has-text('ادفع الآن')");
  await page.waitForURL(/\/checkout\/success/);
  await page.waitForSelector("text=تم الدفع بنجاح");
  expect((await page.locator("main").innerText()).includes("103.5"), "success page should show the discounted amount");
  return amount;
});

await step("coupon XZ21 cannot be used twice by the same account (UI and API)", async () => {
  await page.goto(`${BASE}/checkout?plan=pro_monthly`, { waitUntil: "networkidle" });
  await page.fill("[data-testid=coupon-input]", "xz21");
  await page.click("[data-testid=coupon-apply]");
  const fb = page.locator("[data-testid=coupon-feedback][data-state=rejected]");
  await fb.waitFor();
  expect((await fb.getAttribute("data-reason")) === "already_redeemed", "second use must be rejected");
  await shot(page, "24-coupon-already-used");
  // Bypass the UI entirely: the backend still refuses.
  const res = await page.request.post(`${BASE}/api/checkout`, {
    data: { productKey: "pro_monthly", name: "Admin", email: ADMIN_EMAIL, phone: "0500000001", couponCode: "XZ21" },
    headers: { origin: BASE },
  });
  const body = await res.json();
  expect(res.status() === 409 && body.error?.reason === "already_redeemed", `API returned ${res.status()} ${JSON.stringify(body)}`);
  return "409 already_redeemed";
});

await step("admin coupons page shows the confirmed redemption", async () => {
  await page.goto(`${BASE}/admin/coupons`);
  const text = await page.locator("main").innerText();
  expect(text.includes("مستخدم: 1") || text.includes("مستخدم:\t1") || /مستخدم:\s*1/.test(text), "redemption count not shown");
  expect(text.includes(ADMIN_EMAIL), "redemption log missing the user");
});

await step("anonymous user is sent to sign-in for /admin", async () => {
  const ctx2 = await browser.newContext({ viewport: { width: 1366, height: 900 } });
  const p2 = await ctx2.newPage();
  const res = await p2.goto(`${BASE}/admin`);
  expect(res.url().includes("/sign-in"), `anonymous user not redirected (got ${res.url()})`);
  await ctx2.close();
});

await step("sign-up as a student works and a non-admin gets 403 on /admin", async () => {
  const ctx3 = await browser.newContext({ viewport: { width: 1366, height: 900 } });
  const p3 = await ctx3.newPage();
  p3.setDefaultTimeout(20000);
  await p3.goto(`${BASE}/role-select?plan=pro`, { waitUntil: "networkidle" });
  // The role cards are client state: wait for hydration before clicking.
  await p3.waitForFunction(() => document.querySelector("button[aria-pressed]") !== null);
  await p3.click("button[aria-pressed]:has-text('طالب')");
  const cont = p3.getByRole("button", { name: "متابعة", exact: true });
  await cont.waitFor();
  await cont.click();
  await p3.waitForURL(/\/sign-up\?role=student/);
  const email = `student-${Date.now()}@example.com`;
  await p3.fill("#name", "طالب تجريبي");
  await p3.fill("#email", email);
  await p3.fill("#password", "Student12345!");
  await p3.click("button[type=submit]");
  await p3.waitForURL(/\/checkout\?plan=pro_monthly/); // plan=pro carries through sign-up
  expect((await p3.inputValue("#email")) === email, "new user not prefilled on checkout");
  await p3.goto(`${BASE}/admin`);
  await p3.waitForSelector("text=غير مصرّح");
  await shot(p3, "17-admin-forbidden");
  await ctx3.close();
  return email;
});

await step("referral: payer link → referred customer pays → flat reward credited once", async () => {
  // 1) The admin account doubles as the influencer for this run: open its wallet to get the referral link.
  await page.goto(`${BASE}/account/wallet`);
  const refLink = await page.inputValue("#referral-link");
  expect(/\/r\/[A-Z0-9]{8}$/.test(refLink), `unexpected referral link ${refLink}`);
  const balanceBefore = (await page.locator("main").innerText()).match(/الرصيد الحالي\s+([\d.,]+)/)?.[1] ?? "0";

  // 2) A brand-new visitor follows the link, signs up and pays.
  const ctx4 = await browser.newContext({ viewport: { width: 1366, height: 900 } });
  const p4 = await ctx4.newPage();
  p4.setDefaultTimeout(20000);
  const landed = await p4.goto(refLink.replace(/^https?:\/\/[^/]+/, BASE));
  expect(landed.url().includes("/#pricing") || landed.url().endsWith("/"), `referral landing went to ${landed.url()}`);
  const cookies = await ctx4.cookies(BASE);
  expect(cookies.some((c) => c.name === "eduba_ref"), "referral cookie not set");
  const email = `referred-${Date.now()}@example.com`;
  await p4.goto(`${BASE}/sign-up?role=parent&plan=pro`, { waitUntil: "networkidle" });
  await p4.fill("#name", "ولي أمر مُحال");
  await p4.fill("#email", email);
  await p4.fill("#phone", `05${String(Date.now()).slice(-8)}`);
  await p4.fill("#password", "Referred12345!");
  await p4.click("button[type=submit]");
  await p4.waitForURL(/\/checkout\?plan=pro_monthly/);
  await startCheckout(p4);
  await p4.click("a:has-text('ادفع الآن')");
  await p4.waitForURL(/\/checkout\/success/);
  await p4.waitForSelector("text=تم الدفع بنجاح");
  // The referred user also has a wallet page with their own link (no self-credit).
  await p4.goto(`${BASE}/account/wallet`);
  const referredText = await p4.locator("main").innerText();
  expect(referredText.includes("0 ريال") || referredText.includes("الرصيد الحالي"), "referred user wallet missing");
  await ctx4.close();

  // 3) Back as the influencer/admin: commission booked exactly once.
  await page.goto(`${BASE}/account/wallet`);
  const text = await page.locator("main").innerText();
  expect(text.includes("تمت المكافأة"), "referral not rewarded");
  await shot(page, "18-wallet-influencer", true);
  return `balance ${balanceBefore} → ${text.match(/الرصيد الحالي\s+([\d.,]+)/)?.[1]}`;
});

await step("admin: wallets, referrals log, monthly settlement run + mark paid (confirmation dialogs)", async () => {
  await page.goto(`${BASE}/admin/wallets`);
  expect((await page.locator("tbody tr").count()) >= 1, "no wallets listed");
  await shot(page, "19-admin-wallets", true);
  await page.goto(`${BASE}/admin/referrals`);
  expect((await page.locator("text=تمت المكافأة").count()) >= 1, "referral log missing rewarded row");

  // Settlement run (balance may be under the 100 SAR minimum → use the per-wallet dialog instead).
  await page.goto(`${BASE}/admin/wallets`);
  const row = page.locator("tbody tr").first();
  await row.locator("button:has-text('تسوية')").first().click();
  const dialog = page.locator("dialog[open]");
  await dialog.waitFor();
  await shot(page, "20-admin-settlement-dialog");
  await dialog.locator("button[type=submit]").click();
  try {
    await dialog.locator("text=تم إنشاء تسوية").waitFor();
  } catch {
    const texts = await page.locator("dialog").allInnerTexts();
    throw new Error(`settlement dialog did not confirm. open=${await page.locator("dialog[open]").count()} texts=${JSON.stringify(texts.map((t) => t.replace(/\s+/g, " ").slice(0, 200)))}`);
  }
  await page.goto(`${BASE}/admin/settlements?status=pending`);
  expect((await page.locator("tbody tr").count()) >= 1, "pending settlement missing");
  await page.locator("tbody tr").first().locator("button:has-text('تسجيل كمدفوعة')").click();
  const d2 = page.locator("dialog[open]");
  await d2.locator("input[name=reference]").fill("BANK-TEST-001");
  await d2.locator("button[type=submit]").click();
  await page.locator("[data-testid=admin-toast]:has-text('تم تسجيل التسوية')").waitFor();
  await page.goto(`${BASE}/admin/settlements?status=paid`);
  expect((await page.locator("text=BANK-TEST-001").count()) >= 1, "paid settlement not listed");
  await shot(page, "21-admin-settlements", true);
});

await step("webhook endpoint rejects unsigned requests", async () => {
  const res = await fetch(`${BASE}/api/webhooks/stream`, { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
  expect(res.status === 401, `expected 401, got ${res.status}`);
});

await browser.close();
const failed = results.filter((r) => !r.ok);
console.log(`\n${results.length - failed.length}/${results.length} steps passed`);
process.exit(failed.length ? 1 : 0);
