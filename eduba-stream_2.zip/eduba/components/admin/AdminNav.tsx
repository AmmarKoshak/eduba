"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const TABS = [
  { href: "/admin", label: "نظرة عامة" },
  { href: "/admin/invoices", label: "الفواتير والمدفوعات" },
  { href: "/admin/payments", label: "عمليات الدفع" },
  { href: "/admin/subscriptions", label: "الاشتراكات" },
  { href: "/admin/customers", label: "العملاء" },
  { href: "/admin/coupons", label: "الكوبونات" },
  { href: "/admin/wallets", label: "المحافظ والإحالات" },
  { href: "/admin/settlements", label: "التسويات" },
  { href: "/admin/referrals", label: "سجل الإحالات" },
];

export function AdminNav() {
  const pathname = usePathname();
  return (
    <nav className="flex gap-1 overflow-x-auto border-b border-border mb-6 -mx-1 px-1">
      {TABS.map((t) => {
        const active = t.href === "/admin" ? pathname === "/admin" : pathname.startsWith(t.href);
        return (
          <Link
            key={t.href}
            href={t.href}
            className={`relative px-4 py-3 text-sm font-bold whitespace-nowrap transition ${
              active ? "text-primary" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.label}
            {active && <span className="absolute inset-x-2 -bottom-[1px] h-0.5 bg-primary rounded-full" />}
          </Link>
        );
      })}
    </nav>
  );
}
