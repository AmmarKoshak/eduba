"use client";

import Link from "next/link";
import { useState } from "react";
import { Check, ExternalLink, Loader2, Lock, TicketPercent, X } from "lucide-react";
import { createCheckout, validateCoupon } from "@/lib/api/client";
import type { AppliedCoupon, CouponRejectionReason, Price, ProductKey } from "@/lib/api/contracts";
import { cardClass, inputClass, primaryButtonClass } from "@/components/ui/classes";

type CouponState =
  | { kind: "idle" }
  | { kind: "checking" }
  | { kind: "applied"; coupon: AppliedCoupon; price: Price; message: string }
  | { kind: "rejected"; reason: CouponRejectionReason | "network"; message: string };

function money(n: number, currency: string) {
  const v = new Intl.NumberFormat("ar-SA-u-nu-latn", { maximumFractionDigits: 2 }).format(n);
  return `${v} ${currency === "SAR" ? "ريال" : currency}`;
}

/**
 * Checkout UI. Everything it shows about money comes from the backend:
 * the initial price from the server render, the discounted price from
 * POST /api/coupons/validate, and the final amount from POST /api/checkout.
 * Payment itself happens on Stream's hosted page.
 */
export function CouponCheckout({
  product,
  initialPrice,
  defaults,
  signedIn,
  signInHref,
}: {
  product: { key: ProductKey; title: string; recurring: boolean; features: string[] };
  initialPrice: Price;
  defaults: { name?: string | null; email?: string | null; phone?: string | null };
  signedIn: boolean;
  signInHref: string;
}) {
  const [name, setName] = useState(defaults.name ?? "");
  const [email, setEmail] = useState(defaults.email ?? "");
  const [phone, setPhone] = useState(defaults.phone ?? "");
  const [code, setCode] = useState("");
  const [coupon, setCoupon] = useState<CouponState>({ kind: "idle" });
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [redirectUrl, setRedirectUrl] = useState<string | null>(null);

  const price = coupon.kind === "applied" ? coupon.price : initialPrice;

  async function applyCoupon(): Promise<CouponState> {
    const trimmed = code.trim();
    if (!trimmed) return { kind: "idle" };
    setCoupon({ kind: "checking" });
    const res = await validateCoupon({ code: trimmed, productKey: product.key });
    const next: CouponState =
      "error" in res
        ? { kind: "rejected", reason: "network", message: res.error }
        : res.valid
          ? { kind: "applied", coupon: res.coupon, price: res.price, message: res.message }
          : { kind: "rejected", reason: res.reason, message: res.message };
    setCoupon(next);
    return next;
  }

  function removeCoupon() {
    setCode("");
    setCoupon({ kind: "idle" });
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    // A code typed but not applied yet is validated first, so the payer sees the
    // price they will be charged before leaving the page.
    let current = coupon;
    if (code.trim() && current.kind !== "applied") {
      current = await applyCoupon();
      if (current.kind !== "applied") return;
    }

    setSubmitting(true);
    const res = await createCheckout({
      productKey: product.key,
      name,
      email,
      phone,
      couponCode: current.kind === "applied" ? current.coupon.code : null,
    });
    if (!res.ok) {
      setSubmitting(false);
      if (res.error.code === "coupon_rejected" || res.error.reason) {
        setCoupon({ kind: "rejected", reason: res.error.reason ?? "not_found", message: res.error.message });
      } else {
        setError(res.error.message);
      }
      return;
    }
    setRedirectUrl(res.paymentUrl);
    window.location.assign(res.paymentUrl);
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-8 lg:gap-12 items-start">
      <div className="order-2 lg:order-1">
        <div className="text-xs sm:text-sm font-bold text-primary mb-3">الدفع</div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-foreground mb-2">
          {product.recurring ? "اشترك في إيدوبا Pro" : product.title}
        </h1>
        <p className="text-sm sm:text-base text-muted-foreground mb-6">
          أدخل بياناتك وكوبون الخصم إن وُجد، ثم أكمل الدفع على صفحة Stream الآمنة.
          {product.recurring && " يتجدد الاشتراك شهرياً ويمكنك إلغاؤه في أي وقت."}
        </p>

        <form onSubmit={onSubmit} className={`${cardClass} p-5 sm:p-7 space-y-5`} noValidate>
          <div>
            <label htmlFor="name" className="block text-sm font-bold text-foreground mb-1.5">
              الاسم الكامل
            </label>
            <input id="name" value={name} onChange={(e) => setName(e.target.value)} required autoComplete="name" className={inputClass} placeholder="مثال: أحمد العلي" />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="phone" className="block text-sm font-bold text-foreground mb-1.5">
                رقم الجوال
              </label>
              <input id="phone" type="tel" inputMode="tel" dir="ltr" required autoComplete="tel" value={phone} onChange={(e) => setPhone(e.target.value)} className={`${inputClass} text-left`} placeholder="05xxxxxxxx" />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-bold text-foreground mb-1.5">
                البريد الإلكتروني
              </label>
              <input id="email" type="email" dir="ltr" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className={`${inputClass} text-left`} placeholder="name@example.com" />
            </div>
          </div>

          {/* Coupon */}
          <div className="border-t border-border pt-5">
            <label htmlFor="coupon" className="flex items-center gap-2 text-sm font-bold text-foreground mb-1.5">
              <TicketPercent className="w-4 h-4 text-primary" />
              كوبون الخصم <span className="font-normal text-muted-foreground">(اختياري)</span>
            </label>

            {coupon.kind === "applied" ? (
              <div data-testid="coupon-feedback" data-state="applied" className="flex items-center justify-between gap-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3">
                <div className="flex items-center gap-2 text-sm text-emerald-800">
                  <Check className="w-4 h-4 shrink-0" strokeWidth={3} />
                  <span>
                    <span dir="ltr" className="font-bold uppercase">{coupon.coupon.code}</span> — {coupon.message}
                  </span>
                </div>
                <button type="button" onClick={removeCoupon} className="inline-flex items-center gap-1 text-xs font-bold text-emerald-800 hover:underline" data-testid="coupon-remove">
                  <X className="w-3.5 h-3.5" /> إزالة
                </button>
              </div>
            ) : (
              <>
                <div className="flex gap-2">
                  <input
                    id="coupon"
                    data-testid="coupon-input"
                    dir="ltr"
                    autoComplete="off"
                    autoCapitalize="characters"
                    value={code}
                    onChange={(e) => {
                      setCode(e.target.value);
                      if (coupon.kind === "rejected") setCoupon({ kind: "idle" });
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        void applyCoupon();
                      }
                    }}
                    className={`${inputClass} text-left uppercase`}
                    placeholder="XZ21"
                    aria-invalid={coupon.kind === "rejected"}
                    aria-describedby="coupon-help"
                  />
                  <button
                    type="button"
                    data-testid="coupon-apply"
                    onClick={() => void applyCoupon()}
                    disabled={!code.trim() || coupon.kind === "checking"}
                    className="shrink-0 inline-flex items-center justify-center gap-2 px-5 rounded-xl border-2 border-primary text-primary font-bold text-sm hover:bg-primary/5 transition disabled:opacity-50"
                  >
                    {coupon.kind === "checking" ? <Loader2 className="w-4 h-4 animate-spin" /> : "تطبيق"}
                  </button>
                </div>
                <div id="coupon-help" className="mt-2 min-h-5 text-xs" aria-live="polite">
                  {coupon.kind === "rejected" ? (
                    <span data-testid="coupon-feedback" data-state="rejected" data-reason={coupon.reason} className="text-red-700">
                      {coupon.message}
                      {coupon.reason === "auth_required" && (
                        <>
                          {" "}
                          <Link href={signInHref} className="font-bold underline">
                            تسجيل الدخول
                          </Link>
                        </>
                      )}
                    </span>
                  ) : (
                    !signedIn && <span className="text-muted-foreground">الكوبونات متاحة للحسابات المسجلة، ويُستخدم كل كوبون مرة واحدة لكل حساب.</span>
                  )}
                </div>
              </>
            )}
          </div>

          {error && <div className="text-sm text-red-700 bg-red-50 border border-red-100 rounded-xl px-4 py-3">{error}</div>}

          {redirectUrl ? (
            <div className="text-sm text-emerald-800 bg-emerald-50 border border-emerald-100 rounded-xl px-4 py-3 flex items-center justify-between gap-3">
              <span className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" /> جارٍ تحويلك إلى صفحة الدفع الآمنة من Stream…
              </span>
              <a href={redirectUrl} className="inline-flex items-center gap-1 font-bold underline">
                فتح <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          ) : (
            <button type="submit" data-testid="checkout-submit" disabled={submitting || coupon.kind === "checking"} className={`${primaryButtonClass} w-full`}>
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
              {submitting ? "جارٍ تجهيز الدفع…" : `متابعة إلى الدفع • ${money(price.total, price.currency)}`}
            </button>
          )}

          <p className="text-[11px] sm:text-xs text-muted-foreground text-center leading-relaxed">
            يتم الدفع على صفحة Stream الآمنة ولا نحتفظ ببيانات بطاقتك. بالمتابعة توافق على شروط الاستخدام.
          </p>
        </form>
      </div>

      <aside className="order-1 lg:order-2">
        <div className={`${cardClass} p-6 sm:p-7 lg:sticky lg:top-6`}>
          <div className="text-sm font-bold text-muted-foreground mb-3 text-start">ملخص الطلب</div>
          <div className="flex items-baseline justify-between gap-3 mb-1">
            <span className="text-lg font-bold text-foreground">{product.recurring ? "إيدوبا Pro" : product.title}</span>
            <span className="text-base font-bold text-foreground" data-testid="price-original">
              {money(price.original, price.currency)}
            </span>
          </div>
          <div className="text-xs text-muted-foreground mb-4">
            {product.recurring ? "اشتراك شهري • شامل ضريبة القيمة المضافة" : "دفعة واحدة • شامل ضريبة القيمة المضافة"}
          </div>

          <dl className="space-y-2 border-t border-border pt-4 mb-5 text-sm">
            {price.discount > 0 && coupon.kind === "applied" && (
              <div className="flex justify-between text-emerald-700" data-testid="price-discount">
                <dt>
                  الخصم (<span dir="ltr" className="uppercase">{coupon.coupon.code}</span> — {coupon.coupon.label})
                </dt>
                <dd>− {money(price.discount, price.currency)}</dd>
              </div>
            )}
            <div className="flex justify-between items-baseline">
              <dt className="font-bold text-foreground">المستحق الآن</dt>
              <dd className="text-2xl font-black text-foreground" data-testid="price-total">
                {money(price.total, price.currency)}
              </dd>
            </div>
          </dl>

          <ul className="space-y-2.5 border-t border-border pt-5">
            {product.features.map((f) => (
              <li key={f} className="flex items-start gap-2.5 text-sm text-foreground">
                <span className="shrink-0 mt-0.5 inline-flex w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 items-center justify-center">
                  <Check className="w-3 h-3" strokeWidth={3} />
                </span>
                <span className="flex-1 text-start">{f}</span>
              </li>
            ))}
          </ul>
        </div>
      </aside>
    </div>
  );
}
