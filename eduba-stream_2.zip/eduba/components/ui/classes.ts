/** Shared Tailwind class strings (safe to import from client and server components). */
export const inputClass =
  "w-full rounded-xl border border-input bg-white px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition";

export const primaryButtonClass =
  "inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl text-white font-bold text-sm sm:text-base hover:opacity-95 transition bg-gradient-to-r from-[#1174FF] to-[#0A4699] disabled:opacity-60 disabled:cursor-not-allowed";

export const secondaryButtonClass =
  "inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl border-2 border-primary text-primary font-bold text-sm sm:text-base hover:bg-primary/5 transition";

export const cardClass =
  "rounded-3xl bg-white border border-border shadow-[0_24px_50px_-30px_rgba(15,32,80,0.18)]";
