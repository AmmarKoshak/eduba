# Integrating Stream coupons into a merchant checkout

A reference implementation built for the Eduba website (Next.js), written so a merchant on any stack can follow
the same steps. It shows how a merchant backend turns a code typed by a customer (for example `XZ21`) into a
Stream coupon, charges the discounted amount through a Stream payment link, and makes sure each customer account
can use a code only once.

- Stream API base: `https://stream-app-service.streampay.sa/api/v2`
- Authentication: header `x-api-key: base64("<API_KEY>:<API_SECRET>")`, **server side only**
- Code map: `lib/coupons/*` (business logic), `lib/checkout/service.ts` (orchestration), `app/api/**/route.ts`
  (HTTP endpoints), `lib/api/contracts.ts` (request/response types), `components/checkout/CouponCheckout.tsx` (UI)

---

## 1. Who owns what

| Concern | Owner | Why |
| --- | --- | --- |
| Discount value, % or fixed, currency, active flag | **Stream** (`/coupons`) | Stream applies the coupon to the payment link and charges the discounted amount, so Stream must be the source of truth. |
| Which codes customers may type, and what they map to | **Merchant backend** (`coupon_codes` table) | Stream coupons are identified by UUID and their `name` is free text. A mapping table keeps internal coupons private and lets you rename or retire public codes without touching Stream. |
| "Once per customer account" | **Merchant backend** (`coupon_redemptions` table + a Postgres unique index) | Stream counts total redemptions per coupon, not per customer. |
| Prices shown to the customer | **Merchant backend** (API responses) | The browser never computes prices; it only displays what the API returns. |
| Card, Mada, Apple Pay and other payment details | **Stream hosted page** | The merchant site never sees card data. |

```
Browser (checkout page)            Merchant backend                          Stream API
───────────────────────            ────────────────                          ──────────
type "XZ21" ── POST /api/coupons/validate ──► code → coupon_codes ──────────► GET /coupons/{uuid}
            ◄── { valid, price, coupon } ───  apply rules, check per-user use
submit      ── POST /api/checkout ─────────► re-validate, RESERVE (DB)
                                             find/create consumer ──────────► GET/POST /consumers
                                             create discounted link ────────► POST /payment_links { coupons:[uuid] }
            ◄── { paymentUrl, price } ──────  store order (amount = link.amount)
redirect to Stream hosted page ───────────────────────────────────────────────► customer pays
                                             ◄── webhook PAYMENT_SUCCEEDED (signed) ──
success page ── GET /checkout/success ─────► GET invoice, verify amount ───────► GET /invoices/{id}
                                             order = paid, coupon = REDEEMED
```

---

## 2. One-time setup

1. **Create the coupon in Stream** (dashboard, or the API):

   ```http
   POST /api/v2/coupons
   x-api-key: <base64 key:secret>
   Content-Type: application/json

   { "name": "xz21", "discount_value": 10, "is_percentage": true, "is_active": true }
   ```

   For a fixed amount coupon, use `"is_percentage": false, "currency": "SAR"`. The response contains the coupon `id`
   (UUID), which is what payment links need.

2. **Map a public code to it.** In this project, go to `/admin/coupons`, choose **ربط برمز** (map to a code) on the
   Stream coupon, type `XZ21` and confirm. That inserts a row into `coupon_codes` (`code = 'xz21'`, `stream_coupon_id = <uuid>`).
   For automated environments, set `COUPON_CODE_SEED="xz21=<uuid>"`. The build then creates the mapping if it is missing.

3. Nothing else changes in Stream. Payment links, webhooks and products are the same as a checkout without coupons.

---

## 3. Merchant API (frontend ⇄ backend)

All endpoints are JSON, same origin, and use the signed-in session cookie. The types are in `lib/api/contracts.ts`.

### 3.1 `POST /api/coupons/validate` — preview a coupon

Read only. Nothing is reserved. Use it to give the customer feedback while they type.

Request:

```json
{ "code": "XZ21", "productKey": "pro_monthly" }
```

Response `200` (valid):

```json
{
  "valid": true,
  "coupon": { "code": "xz21", "type": "percentage", "value": 10, "label": "خصم 10%" },
  "price": { "currency": "SAR", "original": 115, "discount": 11.5, "total": 103.5 },
  "message": "تم تطبيق الكوبون: خصم 10%"
}
```

Response `200` (rejected; the price falls back to the full amount):

```json
{
  "valid": false,
  "reason": "already_redeemed",
  "message": "لقد استخدمت هذا الكوبون من قبل. يمكن استخدام كل كوبون مرة واحدة فقط لكل حساب.",
  "price": { "currency": "SAR", "original": 115, "discount": 0, "total": 115 }
}
```

Errors: `400` malformed body or unknown product, `403` cross-origin request, `500` unexpected error.

### 3.2 `POST /api/checkout` — create the Stream payment link

The coupon is validated **again** and reserved here. The preview above is never trusted.

Request:

```json
{ "productKey": "pro_monthly", "name": "Ahmad Ali", "email": "ahmad@example.com", "phone": "0501234567", "couponCode": "XZ21" }
```

Response `201`:

```json
{
  "ok": true,
  "orderId": "5687e9c0-bea0-4bd7-baa8-9a7b2201cef4",
  "paymentUrl": "https://…streampay.sa/…?language=ar",
  "price": { "currency": "SAR", "original": 115, "discount": 11.5, "total": 103.5 },
  "coupon": { "code": "xz21", "type": "percentage", "value": 10, "label": "خصم 10%" }
}
```

The browser then redirects to `paymentUrl` (Stream's hosted page).

Error response shape: `{ "ok": false, "error": { "code", "message", "reason"? } }`

| HTTP | `error.code` | When |
| --- | --- | --- |
| 400 | `invalid_input` / `unknown_product` | missing or invalid name, email, phone or product |
| 401 | `auth_required` | a coupon was sent without a signed-in account |
| 409 | `coupon_rejected` (`reason: already_redeemed` or `in_progress`) | already used by this account, or a parallel checkout holds the reservation |
| 422 | `coupon_rejected` (`reason: not_found`, `inactive`, `currency_mismatch`, `not_applicable`, `invalid_format`) | the code cannot be applied |
| 502 | `stream_error` | Stream refused to create the payment link |
| 503 | `not_configured` or `coupon_rejected` (`reason: unavailable`) | Stream keys or product missing, or Stream unreachable |

### 3.3 Rejection reasons

| `reason` | Meaning |
| --- | --- |
| `invalid_format` | not 2–40 letters, digits, `-` or `_` |
| `auth_required` | coupons are per account. Checked before the code is looked up, so anonymous visitors cannot probe which codes exist |
| `not_found` | no active mapping for the code, or the mapped Stream coupon was deleted |
| `inactive` | the Stream coupon is switched off (`is_active: false`) |
| `currency_mismatch` | fixed-amount coupon in a different currency from the product |
| `not_applicable` | the discount would make the total 0 or less (a paid checkout needs an amount to charge), or the value is invalid |
| `already_redeemed` | this account already paid with this code |
| `in_progress` | another checkout for the same account and code is being created at this moment |
| `unavailable` | Stream could not be reached to check the coupon |

### 3.4 Existing endpoints used by the flow

- `GET /api/checkout/status?order=<id>` returns `{ "state": "paid" | "pending" | "failed" | "mismatch" | "unknown" }` and is polled by the success page.
- `POST /api/webhooks/stream` receives Stream webhooks (HMAC-SHA256 signed, deduplicated). See README §"How the payment flow works".

---

## 4. Stream API calls, step by step

| Step | Call | Notes |
| --- | --- | --- |
| Look up coupon | `GET /coupons/{coupon_id}` | `{ id, name, discount_value: "10.000", is_percentage, currency, is_active, redemptions }`. A `404` means the coupon was deleted, and the code is treated as invalid. |
| List coupons (admin) | `GET /coupons?page=1&limit=100&search_term=…` | `search_term` matches the name, case-insensitively. |
| Find or create consumer | `GET /consumers?search_term=<email or phone>` then `POST /consumers` | Exact match on email, then phone, so no duplicate consumers are created. |
| Create payment link | `POST /payment_links` | `items: [{product_id, quantity: 1}]`, `organization_consumer_id`, `max_number_of_payments: 1`, `coupons: ["<coupon uuid>"]`, redirect URLs, `custom_metadata: { order_id, coupon_code }`. **Coupons are UUIDs, never names.** |
| Read Stream's price | response of the call above | `amount` = price after discount, `original_amount` = price before. The order stores `amount` because that is what Stream charges and what verification compares against. |
| Switch off an abandoned link | `PATCH /payment_links/{id}/status` `{ "status": "INACTIVE" }` | Used when the same customer starts a new checkout with the same code, so an old discounted link cannot be paid later. |
| Verify payment | `GET /invoices/{id}` | Check `payment_link_id`, `organization_consumer_id`, `currency`, `total_amount` (discounted) and status `COMPLETED`. `coupon_calculation_metadata` shows how Stream applied the coupon. |

Example payment-link request body sent by `lib/checkout/payment-link.ts`:

```json
{
  "name": "إيدوبا Pro – اشتراك شهري",
  "currency": "SAR",
  "items": [{ "product_id": "8ae6fc99-4696-47cb-8bad-36d1c86f01c0", "quantity": 1 }],
  "coupons": ["<stream coupon uuid>"],
  "organization_consumer_id": "<consumer uuid>",
  "max_number_of_payments": 1,
  "valid_until": "2026-11-10T15:00:00.000Z",
  "contact_information_type": "PHONE",
  "success_redirect_url": "https://<site>/checkout/success?order=<order id>",
  "failure_redirect_url": "https://<site>/checkout/failed?order=<order id>",
  "custom_metadata": { "order_id": "<order id>", "product_key": "pro_monthly", "coupon_code": "xz21", "source": "website" }
}
```

---

## 5. One redemption per account

### Data model (`drizzle/0002_coupons.sql`)

- `coupon_codes(id, code UNIQUE, stream_coupon_id, stream_coupon_name, is_active, note, created_by_email, …)`
- `coupon_redemptions(id, coupon_code_id, stream_coupon_id, user_id, order_id UNIQUE, status, discount_amount, currency, release_reason, redeemed_at, …)`
- `orders` gains `original_amount`, `discount_amount`, `coupon_code_id`, `stream_coupon_id`

The guarantee is one partial unique index, enforced by Postgres even when requests arrive at the same moment:

```sql
CREATE UNIQUE INDEX coupon_redemptions_active_per_user
  ON coupon_redemptions (coupon_code_id, user_id)
  WHERE status IN ('reserved', 'redeemed');
```

### States

```
             POST /api/checkout                  Stream confirms payment
  (none) ───────────────────────► reserved ─────────────────────────────► redeemed   (final: code blocked for this user)
                                     │
                                     │ invoice expired / cancelled / rejected,
                                     │ link creation failed, or the user starts a new checkout
                                     ▼
                                  released   (does not count; the user may try again)
```

- **Reserve** (`tryReserve`): insert `reserved`. If the unique index refuses, another reservation exists:
  - `redeemed`: reject with `already_redeemed`.
  - `reserved` with an order: ask Stream about that order first. If it was paid, it becomes `redeemed` and the request is rejected.
    Otherwise the old link is set to `INACTIVE`, the old order to `expired`, and the old row to `released`, then the new checkout reserves again.
  - `reserved` without an order yet (a parallel request is creating the link): reject with `in_progress`.
- **Redeem** (`markCouponRedeemed`): runs inside the same server-side verification that marks the order paid (success page, status polling, or webhook), so whichever arrives first wins and repeats are harmless.
- **Release** (`releaseCouponForOrder`): on `INVOICE_EXPIRED`, `INVOICE_CANCELED`, `INVOICE_REJECTED` or `PAYMENT_EXPIRED` webhooks, or when verification finds a dead invoice. A **declined card does not release** the coupon, because the customer can retry on the same Stream page.

---

## 6. Security checklist

- API keys exist only on the server (`lib/env.ts`). The browser receives no Stream IDs or keys.
- The checkout endpoint re-validates everything and never trusts the preview or any client-side price.
- Coupons require a signed-in account, and anonymous calls get `auth_required` before the code is looked up.
- Only codes mapped in `coupon_codes` work. Other coupons in the Stream organisation (internal or easy-to-guess names) cannot be used.
- State-changing endpoints reject cross-origin `Origin` headers.
- Success is shown only after `GET /invoices/{id}` matches the order (payment link, consumer, currency, discounted amount).
- Recommended for production: rate-limit `POST /api/coupons/validate` per IP and account (for example with the Vercel Firewall or an edge rate-limit rule).

---

## 7. Porting to another stack

The logic is small enough to copy as is:

```text
validate(code, product, user):
    code = normalise(code)                      # trim, lower-case, 2–40 [letters digits - _]
    if !user: reject auth_required
    mapping = db.coupon_codes[code] (active)    else reject not_found
    coupon  = stream.GET /coupons/{mapping.stream_coupon_id}
    if !coupon.is_active: reject inactive
    price   = apply(coupon, product.price)      # % or fixed same currency, never ≤ 0
    if db has REDEEMED (mapping, user): reject already_redeemed
    return price

checkout(input, user):
    price = validate(...)                       # again, server side
    reserve(mapping, user)                      # unique index; settle/replace an old pending reservation
    try:
        consumer = find_or_create(email, phone)
        link = stream.POST /payment_links { items:[product], coupons:[coupon.id], consumer, max_payments:1, redirects }
        order = save(amount = link.amount, original, discount, coupon)
        return link.url
    except: release(reservation); raise

on verified payment (webhook or success page):
    order.status = paid; reservation.status = redeemed
on dead invoice:
    reservation.status = released
```

---

## 8. Testing

- `tests/coupon-pricing.test.ts`: normalisation, % and fixed discounts, rounding, currency mismatch, zero-total rejection, coupon UUIDs on the payment link.
- `tests/coupon-redemption-db.test.ts` (real Postgres, Stream faked): mapping and validation, discounted order amount,
  re-checkout switches off the old link, payment marks the coupon redeemed, second use rejected (preview **and**
  checkout), other users unaffected, a dead invoice releases the coupon, simultaneous checkouts never leave two live
  discounted links (the later one is refused or supersedes the earlier), and the unique index itself.
- `tests/e2e/mock-flow.mjs` against `npm run stream:mock`: anonymous visitor must sign in, an unmapped code is rejected,
  the admin maps `XZ21`, the 10% discount is shown, Stream's page charges 103.50 SAR, payment is verified, and a second
  use is rejected in the UI and by a direct API call (409).
- The mock (`scripts/mock-stream.mjs`) implements `/coupons`, discounted payment links and `PATCH /payment_links/{id}/status`.

## 9. Known limits

- **Renewals.** For a subscription, whether the coupon also discounts later monthly renewals is decided by Stream's
  coupon and subscription settings. The website only controls the checkout. Check one renewal in Stream before relying on it.
- "Once per account" is per website account. Someone who creates several accounts can use a code once per account.
  Tie redemptions to the Stream consumer (email or phone) as well if that matters.
- A coupon that would make the total 0 is rejected, because a paid checkout needs an amount to charge. Free access
  vouchers would need a separate flow that does not create a payment link.
