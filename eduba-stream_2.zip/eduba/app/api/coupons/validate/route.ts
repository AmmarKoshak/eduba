import { z } from "zod";
import { auth } from "@/auth";
import type { ValidateCouponResponse } from "@/lib/api/contracts";
import { isSameOrigin, json, readJson } from "@/lib/api/http";
import { quoteCoupon } from "@/lib/coupons/service";
import { getProduct } from "@/lib/products";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const bodySchema = z.object({
  code: z.string().max(100),
  productKey: z.string().max(40),
});

/**
 * POST /api/coupons/validate — preview a coupon for the signed-in user.
 * Read-only: nothing is reserved until POST /api/checkout. The response always
 * carries the price to display, so the page holds no pricing logic.
 */
export async function POST(req: Request) {
  if (!isSameOrigin(req)) return json({ error: "forbidden" }, 403);
  const parsed = bodySchema.safeParse(await readJson(req));
  if (!parsed.success) return json({ error: "invalid_input" }, 400);
  const product = getProduct(parsed.data.productKey);
  if (!product) return json({ error: "unknown_product" }, 400);

  const session = await auth();
  try {
    const result: ValidateCouponResponse = await quoteCoupon({
      code: parsed.data.code,
      product,
      userId: session?.user?.id ?? null,
    });
    return json(result);
  } catch (err) {
    console.error("[api/coupons/validate]", err);
    return json({ error: "internal_error" }, 500);
  }
}
