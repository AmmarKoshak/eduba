import { cookies } from "next/headers";
import { z } from "zod";
import { auth } from "@/auth";
import type { CheckoutErrorCode, CouponRejectionReason, CreateCheckoutResponse } from "@/lib/api/contracts";
import { isSameOrigin, json, readJson } from "@/lib/api/http";
import { CheckoutError, createCheckout } from "@/lib/checkout/service";
import { CouponRejectedError } from "@/lib/coupons/service";
import { referralConfig } from "@/lib/referrals/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const bodySchema = z.object({
  productKey: z.string().max(40),
  name: z.string().max(120),
  email: z.string().max(200),
  phone: z.string().max(30),
  couponCode: z.string().max(100).nullish(),
});

function failure(status: number, code: CheckoutErrorCode, message: string, reason?: CouponRejectionReason) {
  const body: CreateCheckoutResponse = { ok: false, error: { code, message, ...(reason ? { reason } : {}) } };
  return json(body, status);
}

const CHECKOUT_STATUS: Record<string, number> = {
  invalid_input: 400,
  unknown_product: 400,
  auth_required: 401,
  stream_error: 502,
  not_configured: 503,
};

/**
 * POST /api/checkout — creates the Stream payment link (with the coupon, if
 * any) and returns the hosted payment page URL for the browser to open.
 */
export async function POST(req: Request) {
  if (!isSameOrigin(req)) return failure(403, "invalid_input", "طلب غير مسموح.");
  const parsed = bodySchema.safeParse(await readJson(req));
  if (!parsed.success) return failure(400, "invalid_input", "بيانات الطلب غير مكتملة.");

  const session = await auth();
  const referralCode = (await cookies()).get(referralConfig.cookieName)?.value ?? null;

  try {
    const result = await createCheckout({
      ...parsed.data,
      couponCode: parsed.data.couponCode ?? null,
      userId: session?.user?.id ?? null,
      referralCode,
    });
    const body: CreateCheckoutResponse = {
      ok: true,
      orderId: result.orderId,
      paymentUrl: result.paymentLinkUrl,
      price: result.price,
      coupon: result.coupon,
    };
    return json(body, 201);
  } catch (err) {
    if (err instanceof CouponRejectedError) {
      if (err.reason === "auth_required") return failure(401, "auth_required", err.message, err.reason);
      if (err.reason === "unavailable") return failure(503, "coupon_rejected", err.message, err.reason);
      const status = err.reason === "already_redeemed" || err.reason === "in_progress" ? 409 : 422;
      return failure(status, "coupon_rejected", err.message, err.reason);
    }
    if (err instanceof CheckoutError) {
      return failure(CHECKOUT_STATUS[err.code] ?? 400, err.code as CheckoutErrorCode, err.message);
    }
    console.error("[api/checkout] unexpected error", err);
    return failure(500, "internal_error", "حدث خطأ غير متوقع، حاول مرة أخرى.");
  }
}
