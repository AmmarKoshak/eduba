import Link from "next/link";
import { auth } from "@/auth";
import { CouponCheckout } from "@/components/checkout/CouponCheckout";
import { Card, PageShell } from "@/components/site/PageShell";
import { findUserById } from "@/lib/auth/users";
import { basePrice } from "@/lib/coupons/pricing";
import { getProduct, resolveProductKey } from "@/lib/products";

export const metadata = { title: "الاشتراك في إيدوبا Pro | إيدوبا" };
export const dynamic = "force-dynamic";

const PRO_FEATURES = [
  "رسائل غير محدودة مع المعلّم الذكي",
  "جميع الاختبارات بلا حدود",
  "تحديات غير محدودة",
  "حساب الأهل الكامل",
  "تحليلات ذكاء اصطناعي متقدمة للطالب",
];

export default async function CheckoutPage({
  searchParams,
}: {
  searchParams: Promise<{ plan?: string }>;
}) {
  const { plan } = await searchParams;
  const productKey = resolveProductKey(plan) ?? "pro_monthly";
  const product = getProduct(productKey);
  const session = await auth();
  const user = session?.user?.id ? await findUserById(session.user.id) : undefined;

  if (!product) {
    return (
      <PageShell width="min(92%,640px)">
        <Card className="p-8 text-center">
          <h1 className="text-2xl font-bold mb-3">الباقة غير موجودة</h1>
          <Link href="/#pricing" className="text-primary font-bold hover:underline">
            العودة إلى الأسعار
          </Link>
        </Card>
      </PageShell>
    );
  }

  const isRecurring = product.type === "RECURRING";
  const signInHref = `/sign-in?callbackUrl=${encodeURIComponent(`/checkout?plan=${product.key}`)}`;

  return (
    <PageShell>
      <CouponCheckout
        product={{
          key: product.key,
          title: product.name,
          recurring: isRecurring,
          features: isRecurring ? PRO_FEATURES : [product.description],
        }}
        initialPrice={basePrice(product.amount, product.currency)}
        defaults={{ name: user?.name, email: user?.email, phone: user?.phone }}
        signedIn={!!session?.user?.id}
        signInHref={signInHref}
      />
    </PageShell>
  );
}
