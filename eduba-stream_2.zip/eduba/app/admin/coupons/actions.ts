"use server";

import { requireAdmin } from "@/auth";
import type { AdminActionState } from "@/app/admin/wallets/actions";
import { CouponAdminError, createCouponCode, setCouponCodeActive } from "@/lib/coupons/service";

/** Admin writes for coupon codes. Each is triggered from a confirmation dialog and re-checks the allow-list. */
export async function mapCouponCode(_prev: AdminActionState | null, formData: FormData): Promise<AdminActionState> {
  const admin = await requireAdmin();
  if (!admin?.email) return { ok: false, message: "غير مصرّح" };
  const streamCouponId = String(formData.get("streamCouponId") ?? "");
  const code = String(formData.get("code") ?? "");
  try {
    const row = await createCouponCode({
      code,
      streamCouponId,
      note: String(formData.get("note") ?? "") || null,
      createdByEmail: admin.email,
    });
    return { ok: true, message: `تم ربط الرمز "${row.code}" بكوبون Stream "${row.streamCouponName ?? row.streamCouponId}".` };
  } catch (err) {
    if (err instanceof CouponAdminError) return { ok: false, message: err.message };
    console.error("[admin/coupons] map failed", err);
    return { ok: false, message: "تعذّر حفظ الرمز، حاول مرة أخرى." };
  }
}

export async function toggleCouponCode(_prev: AdminActionState | null, formData: FormData): Promise<AdminActionState> {
  const admin = await requireAdmin();
  if (!admin?.email) return { ok: false, message: "غير مصرّح" };
  const id = String(formData.get("id") ?? "");
  const enable = String(formData.get("enable") ?? "") === "1";
  const row = await setCouponCodeActive(id, enable);
  if (!row) return { ok: false, message: "الرمز غير موجود" };
  return { ok: true, message: enable ? `تم تفعيل الرمز "${row.code}".` : `تم إيقاف الرمز "${row.code}". لن يقبله الموقع بعد الآن.` };
}
