import { ConfirmActionDialog } from "@/components/admin/ConfirmActionDialog";
import { ErrorNotice, Mono, StatCard, Table, shortId } from "@/components/admin/ui";
import { couponLabel, listCouponCodes, listRecentRedemptions } from "@/lib/coupons/service";
import { formatDateTime, formatMoney } from "@/lib/format";
import { stream } from "@/lib/stream/client";
import type { Coupon } from "@/lib/stream/types";
import { mapCouponCode, toggleCouponCode } from "./actions";

export const dynamic = "force-dynamic";

const REDEMPTION_AR: Record<string, { label: string; tone: string }> = {
  reserved: { label: "محجوز (بانتظار الدفع)", tone: "bg-amber-100 text-amber-800" },
  redeemed: { label: "مستخدم", tone: "bg-emerald-100 text-emerald-700" },
  released: { label: "مُلغى/متاح مجدداً", tone: "bg-gray-100 text-gray-700" },
};

function discountText(c: Pick<Coupon, "is_percentage" | "discount_value" | "currency">) {
  return couponLabel(c.is_percentage ? "percentage" : "fixed", Number(c.discount_value), c.currency ?? "SAR");
}

export default async function AdminCouponsPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q = "" } = await searchParams;
  const [codes, redemptions] = await Promise.all([listCouponCodes(), listRecentRedemptions(50)]);

  let streamCoupons: Coupon[] = [];
  let streamError: string | null = null;
  try {
    const res = await stream().listCoupons({ page: 1, limit: 100, search_term: q || undefined });
    streamCoupons = res.data ?? [];
  } catch (err) {
    streamError = err instanceof Error ? err.message : String(err);
  }
  const byId = new Map(streamCoupons.map((c) => [c.id, c]));
  const mappedIds = new Set(codes.map((c) => c.streamCouponId));

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="رموز فعّالة" value={String(codes.filter((c) => c.isActive).length)} tone="text-primary" hint={`من أصل ${codes.length} رمز`} />
        <StatCard label="استخدامات مؤكدة" value={String(codes.reduce((n, c) => n + c.redeemed, 0))} tone="text-emerald-600" hint="دفعات خصم أكدتها Stream" />
        <StatCard label="بانتظار الدفع" value={String(codes.reduce((n, c) => n + c.reserved, 0))} tone="text-amber-600" hint="روابط دفع مفتوحة بكوبون" />
        <StatCard label="كوبونات في Stream" value={streamError ? "—" : String(streamCoupons.length)} hint="المصدر الأساسي للخصم" />
      </div>

      <section>
        <h2 className="text-lg font-bold mb-1">الرموز المتاحة للعملاء</h2>
        <p className="text-sm text-muted-foreground mb-4">
          العميل يكتب الرمز في صفحة الدفع، ويحوّله الخادم إلى كوبون Stream المرتبط به. أي رمز غير موجود هنا يُرفض، وكل حساب يستخدم الرمز مرة واحدة فقط.
        </p>
        <Table head={["الرمز", "كوبون Stream", "الخصم", "الحالة في Stream", "استخدامات", "أُضيف", ""]} empty={codes.length === 0}>
          {codes.map((c) => {
            const sc = byId.get(c.streamCouponId);
            return (
              <tr key={c.id} className="hover:bg-secondary/40 align-top">
                <td className="px-4 py-3">
                  <span dir="ltr" className="font-mono font-bold uppercase">{c.code}</span>
                  {!c.isActive && <span className="ms-2 inline-block px-2 py-0.5 rounded-md text-[11px] font-bold bg-gray-100 text-gray-600">موقوف</span>}
                  {c.note && <div className="text-xs text-muted-foreground mt-1">{c.note}</div>}
                </td>
                <td className="px-4 py-3">
                  <div>{sc?.name ?? c.streamCouponName ?? "—"}</div>
                  <Mono>{shortId(c.streamCouponId)}</Mono>
                </td>
                <td className="px-4 py-3 whitespace-nowrap">{sc ? discountText(sc) : "—"}</td>
                <td className="px-4 py-3 whitespace-nowrap">
                  {sc ? (sc.is_active ? <span className="text-emerald-700 font-bold text-xs">فعّال</span> : <span className="text-red-700 font-bold text-xs">موقوف في Stream</span>) : <span className="text-xs text-muted-foreground">{streamError ? "تعذّر التحقق" : "غير موجود في Stream"}</span>}
                </td>
                <td className="px-4 py-3 whitespace-nowrap text-xs">
                  <div>مستخدم: <b>{c.redeemed}</b></div>
                  <div className="text-muted-foreground">محجوز: {c.reserved} • مُلغى: {c.released}</div>
                </td>
                <td className="px-4 py-3 whitespace-nowrap text-muted-foreground text-xs">
                  {formatDateTime(c.createdAt)}
                  {c.createdByEmail && <div dir="ltr">{c.createdByEmail}</div>}
                </td>
                <td className="px-4 py-3">
                  {c.isActive ? (
                    <ConfirmActionDialog
                      action={toggleCouponCode}
                      trigger="إيقاف"
                      tone="danger"
                      title={`إيقاف الرمز ${c.code.toUpperCase()}`}
                      description="لن يقبل الموقع هذا الرمز بعد الآن. روابط الدفع التي أُنشئت به سابقاً لا تتأثر، والكوبون في Stream يبقى كما هو."
                      confirmLabel="إيقاف الرمز"
                      hidden={{ id: c.id, enable: "0" }}
                    />
                  ) : (
                    <ConfirmActionDialog
                      action={toggleCouponCode}
                      trigger="تفعيل"
                      title={`تفعيل الرمز ${c.code.toUpperCase()}`}
                      description="سيقبل الموقع هذا الرمز مجدداً (مرة واحدة لكل حساب)."
                      confirmLabel="تفعيل"
                      hidden={{ id: c.id, enable: "1" }}
                    />
                  )}
                </td>
              </tr>
            );
          })}
        </Table>
      </section>

      <section>
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-4">
          <div>
            <h2 className="text-lg font-bold mb-1">كوبونات Stream</h2>
            <p className="text-sm text-muted-foreground">بيانات حية من Stream. اختر كوبوناً واربطه برمز يكتبه العملاء.</p>
          </div>
          <form method="get" action="/admin/coupons" className="flex gap-2">
            <input type="search" name="q" defaultValue={q} placeholder="بحث باسم الكوبون" className="rounded-lg border border-input px-3 py-2 text-sm" />
            <button type="submit" className="px-4 py-2 rounded-lg bg-primary text-white text-sm font-bold">بحث</button>
          </form>
        </div>
        {streamError ? (
          <ErrorNotice message={streamError} />
        ) : (
          <Table head={["الاسم في Stream", "الخصم", "الحالة", "استخدامات Stream", "المعرّف", ""]} empty={streamCoupons.length === 0}>
            {streamCoupons.map((sc) => (
              <tr key={sc.id} className="hover:bg-secondary/40">
                <td className="px-4 py-3 font-bold">{sc.name}</td>
                <td className="px-4 py-3 whitespace-nowrap">{discountText(sc)}</td>
                <td className="px-4 py-3 whitespace-nowrap text-xs">{sc.is_active ? <span className="text-emerald-700 font-bold">فعّال</span> : <span className="text-muted-foreground">موقوف</span>}</td>
                <td className="px-4 py-3">{sc.redemptions ?? 0}</td>
                <td className="px-4 py-3"><Mono>{shortId(sc.id)}</Mono></td>
                <td className="px-4 py-3">
                  <ConfirmActionDialog
                    action={mapCouponCode}
                    trigger={mappedIds.has(sc.id) ? "ربط برمز آخر" : "ربط برمز"}
                    disabled={!sc.is_active}
                    title={`ربط "${sc.name}" برمز للعملاء`}
                    description={`سيتمكن العملاء المسجلون من كتابة هذا الرمز في صفحة الدفع للحصول على ${discountText(sc)}، مرة واحدة لكل حساب. يتم حساب الخصم وتطبيقه بواسطة Stream.`}
                    confirmLabel="حفظ الرمز"
                    hidden={{ streamCouponId: sc.id }}
                    fields={[
                      { name: "code", label: "الرمز الذي يكتبه العميل", placeholder: "مثال: XZ21", required: true },
                      { name: "note", label: "ملاحظة داخلية (اختياري)" },
                    ]}
                  />
                </td>
              </tr>
            ))}
          </Table>
        )}
      </section>

      <section>
        <h2 className="text-lg font-bold mb-4">آخر الاستخدامات</h2>
        <Table head={["الرمز", "المستخدم", "الحالة", "الخصم", "الطلب", "التاريخ"]} empty={redemptions.length === 0}>
          {redemptions.map((r) => (
            <tr key={r.id} className="hover:bg-secondary/40">
              <td className="px-4 py-3"><span dir="ltr" className="font-mono font-bold uppercase">{r.code}</span></td>
              <td className="px-4 py-3" dir="ltr">{r.userEmail}</td>
              <td className="px-4 py-3 whitespace-nowrap">
                <span className={`inline-block px-2 py-0.5 rounded-md text-[11px] font-bold ${REDEMPTION_AR[r.status]?.tone ?? ""}`} title={r.releaseReason ?? undefined}>
                  {REDEMPTION_AR[r.status]?.label ?? r.status}
                </span>
              </td>
              <td className="px-4 py-3 whitespace-nowrap">{formatMoney(r.discountAmount, r.currency)}</td>
              <td className="px-4 py-3"><Mono>{shortId(r.orderId)}</Mono></td>
              <td className="px-4 py-3 whitespace-nowrap text-muted-foreground text-xs">{formatDateTime(r.redeemedAt ?? r.createdAt)}</td>
            </tr>
          ))}
        </Table>
      </section>
    </div>
  );
}
