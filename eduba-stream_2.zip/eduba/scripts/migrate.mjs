#!/usr/bin/env node
/**
 * Runs Drizzle migrations when DATABASE_URL is set (Vercel build, local build).
 * Skips with a warning when it is not, so a first deploy without a database
 * still builds; the site then works for static pages only until the DB exists.
 */
import { spawnSync } from "node:child_process";

if (!process.env.DATABASE_URL) {
  console.warn("[migrate] DATABASE_URL is not set — skipping migrations (add a Postgres database and redeploy).");
  process.exit(0);
}
const r = spawnSync("npx", ["drizzle-kit", "migrate"], { stdio: "inherit", shell: process.platform === "win32" });
if (r.status !== 0) process.exit(r.status ?? 1);
// Optional coupon-code bootstrap (no-op unless COUPON_CODE_SEED is set).
const s = spawnSync(process.execPath, ["scripts/seed-coupons.mjs"], { stdio: "inherit" });
process.exit(s.status ?? 1);
