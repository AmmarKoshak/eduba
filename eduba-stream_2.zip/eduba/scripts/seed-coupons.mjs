#!/usr/bin/env node
/**
 * Optional: create coupon-code mappings from the environment at deploy time.
 *
 *   COUPON_CODE_SEED="xz21=<stream coupon uuid>,summer=<uuid>"
 *
 * Existing codes are left untouched (ON CONFLICT DO NOTHING), so this is safe on
 * every build. Day-to-day mapping is done in /admin/coupons; this exists so a
 * fresh environment can be bootstrapped without clicking through the admin.
 */
import pg from "pg";

const seed = (process.env.COUPON_CODE_SEED ?? "").trim();
if (!seed || !process.env.DATABASE_URL) process.exit(0);

const pairs = seed
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean)
  .map((s) => {
    const [code, id] = s.split("=").map((x) => x?.trim());
    return { code: code?.normalize("NFKC").toLowerCase(), id };
  })
  .filter((p) => p.code && /^[\p{L}\p{N}_-]{2,40}$/u.test(p.code) && p.id);

if (pairs.length === 0) {
  console.warn("[seed-coupons] COUPON_CODE_SEED has no valid code=uuid pairs; nothing to do.");
  process.exit(0);
}

const url = process.env.DATABASE_URL;
const ssl = /localhost|127\.0\.0\.1/.test(url) ? undefined : { rejectUnauthorized: false };
const client = new pg.Client({ connectionString: url, ssl });
await client.connect();
try {
  for (const { code, id } of pairs) {
    const r = await client.query(
      `insert into coupon_codes (code, stream_coupon_id, note, created_by_email)
       values ($1, $2, 'seeded from COUPON_CODE_SEED', 'deploy')
       on conflict (code) do nothing`,
      [code, id],
    );
    console.log(`[seed-coupons] ${code} → ${id}: ${r.rowCount ? "created" : "already exists"}`);
  }
} finally {
  await client.end();
}
