# إيدوبا — Eduba website + Stream payments

Rebuild of the public eduba.tech site (Next.js 15, Tailwind v4, Arabic RTL) with
payments on [Stream](https://streampay.sa): a coupon-aware checkout for **إيدوبا Pro
(115 ريال/شهر)** that hands payment to Stream's hosted page, server-side payment
verification, signed webhooks, a customer portal link, and an `/admin` dashboard
fed live from the Stream API.

**Merchant integration guide for coupons:** [`docs/STREAM-COUPON-INTEGRATION.md`](docs/STREAM-COUPON-INTEGRATION.md)
(architecture, API contracts, Stream calls, one-time redemption, porting notes).

## Stack

| Layer | Choice |
| --- | --- |
| Framework | Next.js 15 (App Router, Turbopack), React 19, TypeScript |
| Styling | Tailwind CSS v4, lucide-react, self-hosted Cairo + Tajawal fonts |
| Database | Postgres via Drizzle ORM (`lib/db/schema.ts`, migrations in `drizzle/`) |
| Auth | Auth.js v5 (credentials: email/username + password, JWT sessions) |
| Payments | Stream API v2 (server-only client in `lib/stream/client.ts`) + Stream Embed SDK |
| Tests | Vitest (unit + DB-backed webhook test), Playwright end-to-end against a local mock of Stream |

## Quick start (local)

```bash
cp .env.example .env            # fill in DATABASE_URL, AUTH_SECRET, ADMIN_EMAILS
npm install
npm run db:migrate              # creates the tables
npm run user:create -- --email you@example.com --password "min 8 chars" --name "Admin"
npm run dev                     # http://localhost:3000
```

Two ways to run payments locally:

1. **Mock Stream (no account needed)** — in a second terminal `npm run stream:mock`, and in `.env`:
   `STREAM_API_BASE_URL=http://127.0.0.1:4567/api/v2`, `STREAM_API_KEY=mock`, `STREAM_API_SECRET=mock`,
   `STREAM_PRODUCT_PRO_MONTHLY_ID=mock-pro-monthly`, `STREAM_PRODUCT_TEST_ONE_TIME_ID=mock-test-one-time`,
   `STREAM_WEBHOOK_SECRET=mock-webhook-secret`. The mock serves a fake hosted checkout with
   "approved card / Apple Pay / 3 instalments / declined card" buttons and posts signed webhooks to the app.
2. **Stream sandbox** — put your *sandbox* key pair in `.env`, then `npm run stream:setup` (see below).
   Webhooks need a public HTTPS URL, so for local sandbox testing expose port 3000 with a tunnel
   (e.g. `cloudflared tunnel --url http://localhost:3000`) and set `NEXT_PUBLIC_APP_URL` to it before running the setup.

Brand images: the repo ships lightweight placeholders. Run `npm run assets:download`
(on a machine that can reach eduba.tech) to copy the real logo/mascots into `public/`.

## Stream setup

```bash
npm run stream:setup                      # verifies the key pair (refuses live keys), creates the Pro product, registers the webhook
npm run stream:setup -- --with-test-product   # also creates a 300 SAR one-time product to test installments
```

The script prints `STREAM_PRODUCT_PRO_MONTHLY_ID`, `STREAM_WEBHOOK_SECRET` (and the test product id)
to copy into `.env` / Vercel. It is idempotent; if a webhook for the URL already exists it tells you to
reuse the secret you saved (Stream never returns it again).

Hosted alternative: create the product in the Stream dashboard (Products → recurring, monthly, 115 SAR) and
the webhook under Settings → Webhooks (URL `https://<domain>/api/webhooks/stream`, choose a secret), then
copy the ids/secret into the env.

## Environment variables

See `.env.example` for the full list with comments. Required in production:
`NEXT_PUBLIC_APP_URL`, `DATABASE_URL`, `AUTH_SECRET`, `ADMIN_EMAILS`, `STREAM_API_KEY`, `STREAM_API_SECRET`,
`STREAM_WEBHOOK_SECRET`, `STREAM_PRODUCT_PRO_MONTHLY_ID`. Optional: `STREAM_API_BASE_URL`,
`STREAM_PRODUCT_TEST_ONE_TIME_ID`, `STREAM_ENABLE_AMEX`, `STREAM_DASHBOARD_URL`, `STREAM_WEBHOOK_TOLERANCE_SECONDS`,
`COUPON_CODE_SEED`.

Secrets are read on the server only (`lib/env.ts`); nothing Stream-related is exposed to the browser.

## How the payment flow works

1. `اشترك في Pro` → `/checkout?plan=pro_monthly` collects name, phone (normalised to E.164), email
   (prefilled for signed-in users) and an optional **coupon code**. "تطبيق" calls `POST /api/coupons/validate`,
   which maps the code to a Stream coupon and returns the discounted price (signed-in users only).
2. `POST /api/checkout` → `createCheckout()` (`lib/checkout/service.ts`): re-validates and **reserves** the coupon
   (one redemption per account, enforced by a Postgres unique index), then
   search Stream consumers by exact email, then exact phone → create only if none → store the mapping in
   `customers` → `POST /payment_links` for **one** product, bound to that consumer, `max_number_of_payments: 1`,
   success/failure redirect URLs carrying our `order` id, `custom_metadata.order_id`, and `coupons: [<Stream coupon UUID>]`
   when a code was applied (the order stores Stream's discounted `amount`). Installments
   (`payment_methods.installment`) are requested only for one-time products; recurring links keep the
   organisation defaults (Stream disables installments on subscriptions anyway).
3. The browser is redirected to Stream's hosted payment page (no card, Apple Pay or Samsung Pay fields on our site).
   When the payer finishes, Stream redirects back to `/checkout/success?order=…&invoice_id=…`.
4. `/checkout/success` never trusts the query string: it fetches the invoice from Stream and checks that it
   belongs to this order's payment link and consumer, has the expected amount and currency, and is paid
   (`COMPLETED`, or first instalment succeeded for `INSTALLMENTS`). Only then is the order marked `paid`, the
   coupon marked **redeemed**, the subscription mirrored, and "تم الدفع بنجاح" shown. While Stream is still settling it polls
   `/api/checkout/status` (same verification) for up to 90 s.
5. `/api/webhooks/stream` reads the raw body, verifies `X-Webhook-Signature` (`t=…,v1=HMAC-SHA256(secret, "t.body")`),
   rejects timestamps older than 5 minutes, deduplicates deliveries in `webhook_events` (Stream retries up to 5×),
   and re-runs the same verification / subscription sync. Handler errors return 500 so Stream retries;
   duplicates return 200 immediately.
6. `/account` shows the plan and opens Stream's Customer Portal (`POST /consumer_portal/sessions`) for card
   updates, invoices and cancellation.

## Coupons

Coupons are created in Stream (dashboard or `POST /coupons`). Customers type a **public code** that an admin maps to a
Stream coupon in `/admin/coupons`. Unmapped codes are rejected, so internal Stream coupons stay private. Each account
can redeem a code once. A pending checkout is replaced (and its old discounted link switched off) if the user starts again,
and a dead invoice gives the coupon back. Full details: [`docs/STREAM-COUPON-INTEGRATION.md`](docs/STREAM-COUPON-INTEGRATION.md).

## Admin (`/admin`)

Login + allow-list (`ADMIN_EMAILS`, re-checked server-side on every request). Tabs: overview cards
(revenue this month, active subscriptions, failed payments), invoices & payments (`GET /invoices?include_payments=true`,
the only Stream list that includes the customer), payments, subscriptions (next billing = `current_period_end`),
customers. Filters (date range, status, free-text/customer) and pagination are passed straight to the Stream API.
Every row links to the Stream dashboard. Stream data is read-only (no refunds or cancellations from here); the
only writes are coupon-code mappings and the referral/settlement actions, each behind a confirmation dialog.

## Referral wallets (payers + influencers)

Stream has no wallet or referral feature, so this lives in the app (`lib/referrals/*`, tables `wallets`,
`wallet_transactions`, `referrals`, `settlements`):

- Every user has a referral code and link `/r/<CODE>` (also `?ref=<CODE>` on any page). Visiting it stores a
  30-day cookie; the code is attached to the order at checkout (and to the account at sign-up).
- When the referred customer's **first** payment is verified (success page or webhook), the referrer's wallet is
  credited once: regular payers get a flat `REFERRAL_PAYER_REWARD_SAR` (default 20), influencers get
  `REFERRAL_INFLUENCER_RATE_PERCENT` of the payment (default 20 %, overridable per influencer). Self-referrals and
  repeat payments by the same customer are ignored. Booking is idempotent (`commission:<order id>`).
- `/account/wallet`: referral link with copy/share, balance, lifetime earnings, referral list, ledger and settlements.
- `/admin/wallets`: balances, pending payouts, promote/demote influencers (with rate); **"إنشاء تسويات الشهر"** creates
  a pending settlement (and debits the wallet) for every balance ≥ `SETTLEMENT_MIN_SAR` (default 100);
  `/admin/settlements`: mark paid with the bank-transfer reference, or cancel (money returns to the wallet);
  `/admin/referrals`: the full log. All admin writes go through a confirmation dialog and are re-checked against
  `ADMIN_EMAILS` on the server.
- Payouts themselves are bank transfers you make outside the system (Stream only collects money).

## Apple Pay / wallets

Payment now happens on Stream's hosted page, so Apple Pay / Samsung Pay are whatever Stream enables for the
organisation on that page. `public/.well-known/apple-developer-merchantid-domain-association` (Stream's
domain-verification file) is kept for the case where you go back to embedding Stream's checkout on your own domain.

## Scripts

| Command | What it does |
| --- | --- |
| `npm run dev` / `build` / `start` | Next.js |
| `npm run test` | Vitest (unit tests + webhook integration test when `DATABASE_URL` is reachable) |
| `node tests/e2e/mock-flow.mjs` | Playwright end-to-end run against `npm run stream:mock` + a running site |
| `npm run db:generate` / `db:migrate` / `db:studio` | Drizzle migrations / browser |
| `npm run stream:setup` | Create Stream product(s) + webhook, print env values |
| `npm run stream:mock` | Local fake Stream API + hosted checkout on :4567 |
| `npm run user:create` | Create / reset a site user from the CLI (`--influencer --rate 20` to flag an influencer) |
| `COUPON_CODE_SEED=code=<uuid> npm run build` | Optional: create coupon-code mappings at deploy time (never overwrites) |
| `npm run assets:download` | Copy the real brand images from the live site into `public/` |

## Deploying on Vercel

1. Import the repo (or run `vercel`), framework Next.js.
2. Storage → Create Database → **Postgres (Neon)** → it sets `DATABASE_URL`.
3. Add the other env vars from `.env.example` (Production + Preview).
4. The build runs `drizzle-kit migrate && next build`, so tables are created on the first deploy.
5. Run `NEXT_PUBLIC_APP_URL=https://<your-domain> npm run stream:setup` once from your machine
   (with the sandbox or production key pair) to register the webhook for that domain, then add the printed
   `STREAM_WEBHOOK_SECRET` / product ids to Vercel and redeploy.
6. Create your admin login with `npm run user:create` against the production `DATABASE_URL`.
