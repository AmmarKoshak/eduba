/**
 * Centralised, server-only access to environment variables.
 *
 * Nothing here is ever sent to the browser: this module is only imported from
 * server components, server actions, route handlers and scripts. Values are
 * read lazily so that `next build` does not fail on a machine where the
 * secrets are not set yet; a clear error is thrown at the moment a missing
 * value is actually needed.
 */

function required(name: string): string {
  const value = process.env[name];
  if (!value || value.trim() === "") {
    throw new Error(
      `Missing environment variable ${name}. Copy .env.example to .env and fill it in.`,
    );
  }
  return value.trim();
}

function optional(name: string, fallback: string): string {
  const value = process.env[name];
  return value && value.trim() !== "" ? value.trim() : fallback;
}

export const env = {
  /** Public base URL of this deployment, e.g. https://eduba.tech (no trailing slash). */
  get appUrl(): string {
    const raw = optional(
      "NEXT_PUBLIC_APP_URL",
      optional("APP_URL", "http://localhost:3000"),
    );
    return raw.replace(/\/+$/, "");
  },

  get databaseUrl(): string {
    return required("DATABASE_URL");
  },

  /** Comma-separated list of emails allowed into /admin. */
  get adminEmails(): string[] {
    return optional("ADMIN_EMAILS", "")
      .split(",")
      .map((e) => e.trim().toLowerCase())
      .filter(Boolean);
  },

  // --- Stream (streampay.sa) -------------------------------------------------
  get streamApiKey(): string {
    return required("STREAM_API_KEY");
  },
  get streamApiSecret(): string {
    return required("STREAM_API_SECRET");
  },
  /** x-api-key header value = Base64("API_KEY:API_SECRET"). */
  get streamAuthHeader(): string {
    return Buffer.from(`${this.streamApiKey}:${this.streamApiSecret}`).toString(
      "base64",
    );
  },
  get streamApiBaseUrl(): string {
    return optional(
      "STREAM_API_BASE_URL",
      "https://stream-app-service.streampay.sa/api/v2",
    ).replace(/\/+$/, "");
  },
  get streamWebhookSecret(): string {
    return required("STREAM_WEBHOOK_SECRET");
  },
  /** Max age (seconds) of a webhook timestamp we still accept. */
  get streamWebhookTolerance(): number {
    return Number(optional("STREAM_WEBHOOK_TOLERANCE_SECONDS", "300"));
  },
  get streamDashboardUrl(): string {
    return optional("STREAM_DASHBOARD_URL", "https://app.streampay.sa").replace(
      /\/+$/,
      "",
    );
  },
  get streamEmbedScriptUrl(): string {
    return optional(
      "NEXT_PUBLIC_STREAM_EMBED_SCRIPT_URL",
      "https://stream-embed.streampay.sa/sdk/embed.min.js",
    );
  },
  /** Stream product ids, created by `npm run stream:setup`. */
  get streamProductProMonthlyId(): string {
    return required("STREAM_PRODUCT_PRO_MONTHLY_ID");
  },
  get streamProductTestOneTimeId(): string | undefined {
    const v = process.env.STREAM_PRODUCT_TEST_ONE_TIME_ID;
    return v && v.trim() !== "" ? v.trim() : undefined;
  },

  isProduction: process.env.NODE_ENV === "production",
};

export function isAdminEmail(email: string | null | undefined): boolean {
  if (!email) return false;
  return env.adminEmails.includes(email.trim().toLowerCase());
}
