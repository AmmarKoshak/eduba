/**
 * Phone normalisation to E.164, tuned for Saudi numbers (Stream expects E.164,
 * e.g. +966501234567). Returns `null` when the input cannot be a valid number.
 */
export function normalizePhone(input: string): string | null {
  if (!input) return null;
  // Convert Arabic-Indic digits to Latin digits, then strip everything but digits and '+'.
  const latin = input.replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));
  let digits = latin.replace(/[^\d+]/g, "");
  if (digits.startsWith("00")) digits = `+${digits.slice(2)}`;
  const hasPlus = digits.startsWith("+");
  digits = digits.replace(/\+/g, "");

  if (!hasPlus) {
    if (/^05\d{8}$/.test(digits)) return `+966${digits.slice(1)}`;
    if (/^5\d{8}$/.test(digits)) return `+966${digits}`;
    if (/^9665\d{8}$/.test(digits)) return `+${digits}`;
    if (/^966\d{8,9}$/.test(digits)) return `+${digits}`;
    return null;
  }
  // International number provided explicitly.
  if (/^\d{8,15}$/.test(digits)) return `+${digits}`;
  return null;
}

export function isSaudiMobile(e164: string): boolean {
  return /^\+9665\d{8}$/.test(e164);
}
