import "server-only";
import bcrypt from "bcryptjs";
import { eq, or } from "drizzle-orm";
import { getDb, schema } from "@/lib/db";
import type { User } from "@/lib/db/schema";

const BCRYPT_ROUNDS = 12;

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, BCRYPT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function normalizeEmail(email: string): string {
  return email.trim().toLowerCase();
}

export function normalizeUsername(username: string | null | undefined): string | null {
  if (!username) return null;
  const u = username.trim().toLowerCase();
  return u === "" ? null : u;
}

/** Finds a user by email or username (both case-insensitive). */
export async function findUserByIdentifier(identifier: string): Promise<User | undefined> {
  const db = getDb();
  const value = identifier.trim().toLowerCase();
  if (!value) return undefined;
  const rows = await db
    .select()
    .from(schema.users)
    .where(or(eq(schema.users.email, value), eq(schema.users.username, value)))
    .limit(1);
  return rows[0];
}

export async function findUserById(id: string): Promise<User | undefined> {
  const db = getDb();
  const rows = await db.select().from(schema.users).where(eq(schema.users.id, id)).limit(1);
  return rows[0];
}

export class UserExistsError extends Error {
  constructor(public readonly field: "email" | "username") {
    super(field === "email" ? "البريد الإلكتروني مستخدم مسبقاً" : "اسم المستخدم مستخدم مسبقاً");
    this.name = "UserExistsError";
  }
}

export async function createUser(input: {
  name: string;
  email: string;
  username?: string | null;
  phone?: string | null;
  password: string;
  role: "student" | "parent";
  referredByCode?: string | null;
}): Promise<User> {
  const db = getDb();
  const email = normalizeEmail(input.email);
  const username = normalizeUsername(input.username);

  const existing = await db
    .select({ id: schema.users.id, email: schema.users.email, username: schema.users.username })
    .from(schema.users)
    .where(
      username
        ? or(eq(schema.users.email, email), eq(schema.users.username, username))
        : eq(schema.users.email, email),
    )
    .limit(1);
  if (existing[0]) {
    throw new UserExistsError(existing[0].email === email ? "email" : "username");
  }

  const passwordHash = await hashPassword(input.password);
  const [user] = await db
    .insert(schema.users)
    .values({
      name: input.name.trim(),
      email,
      username,
      phone: input.phone ?? null,
      passwordHash,
      role: input.role,
      referredByCode: input.referredByCode ?? null,
    })
    .returning();
  return user;
}
