import "server-only";
import { drizzle, type NodePgDatabase } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import * as schema from "./schema";
import { env } from "@/lib/env";

/**
 * One connection pool per server process. In development Next.js hot-reloads
 * modules, so the pool is cached on `globalThis` to avoid leaking connections.
 */
const globalForDb = globalThis as unknown as {
  __edubaPool?: Pool;
  __edubaDb?: NodePgDatabase<typeof schema>;
};

function createPool(): Pool {
  const connectionString = env.databaseUrl;
  // Hosted Postgres (Neon, Supabase, Vercel) requires TLS; local Postgres usually does not.
  const needsSsl =
    /sslmode=require/.test(connectionString) ||
    (!/localhost|127\.0\.0\.1/.test(connectionString) && env.isProduction);
  return new Pool({
    connectionString,
    max: 5,
    ssl: needsSsl ? { rejectUnauthorized: false } : undefined,
  });
}

export function getDb(): NodePgDatabase<typeof schema> {
  if (!globalForDb.__edubaDb) {
    globalForDb.__edubaPool = createPool();
    globalForDb.__edubaDb = drizzle(globalForDb.__edubaPool, { schema });
  }
  return globalForDb.__edubaDb;
}

export { schema };
