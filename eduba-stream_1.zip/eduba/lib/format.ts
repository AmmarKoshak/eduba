const sarFormatter = new Intl.NumberFormat("ar-SA-u-nu-latn", {
  style: "decimal",
  minimumFractionDigits: 0,
  maximumFractionDigits: 2,
});

export function formatMoney(amount: string | number | null | undefined, currency = "SAR"): string {
  if (amount === null || amount === undefined || amount === "") return "—";
  const n = typeof amount === "string" ? Number(amount) : amount;
  if (!Number.isFinite(n)) return String(amount);
  const label = currency === "SAR" ? "ريال" : currency;
  return `${sarFormatter.format(n)} ${label}`;
}

const dateFormatter = new Intl.DateTimeFormat("ar-SA-u-nu-latn-ca-gregory", {
  year: "numeric",
  month: "short",
  day: "numeric",
  timeZone: "Asia/Riyadh",
});

const dateTimeFormatter = new Intl.DateTimeFormat("ar-SA-u-nu-latn-ca-gregory", {
  year: "numeric",
  month: "short",
  day: "numeric",
  hour: "2-digit",
  minute: "2-digit",
  timeZone: "Asia/Riyadh",
});

export function formatDate(value: string | Date | null | undefined): string {
  if (!value) return "—";
  const d = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(d.getTime())) return "—";
  return dateFormatter.format(d);
}

export function formatDateTime(value: string | Date | null | undefined): string {
  if (!value) return "—";
  const d = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(d.getTime())) return "—";
  return dateTimeFormatter.format(d);
}

/** First and last instant of the current month in Asia/Riyadh, as ISO strings. */
export function currentMonthRange(now = new Date()): { from: string; to: string } {
  const riyadhOffsetMs = 3 * 60 * 60 * 1000; // Asia/Riyadh has no DST (UTC+3)
  const local = new Date(now.getTime() + riyadhOffsetMs);
  const start = Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), 1) - riyadhOffsetMs;
  const end = Date.UTC(local.getUTCFullYear(), local.getUTCMonth() + 1, 1) - riyadhOffsetMs - 1;
  return { from: new Date(start).toISOString(), to: new Date(end).toISOString() };
}
