import type { CurrencyCode, PaymentMethodsDto, ProductType, RecurringInterval } from "@/lib/stream/types";

/**
 * Product catalogue of the site. Prices shown on the page and the amount we
 * verify after payment both come from here, so they can never drift apart.
 *
 * Each product maps to a Stream product id (env), created by `npm run stream:setup`.
 */
export interface SiteProduct {
  key: ProductKey;
  name: string;
  description: string;
  type: ProductType;
  amount: number;
  currency: CurrencyCode;
  recurringInterval?: RecurringInterval;
  recurringIntervalCount?: number;
  /** Name of the env variable that stores the Stream product id. */
  streamProductIdEnv: string;
  /** Only for one-time products: enable installments (Stream disables them on subscriptions). */
  allowInstallments?: boolean;
  /** Hidden products are not shown on the pricing page (e.g. sandbox test products). */
  hidden?: boolean;
}

export type ProductKey = "pro_monthly" | "test_one_time";

export const PRODUCTS: Record<ProductKey, SiteProduct> = {
  pro_monthly: {
    key: "pro_monthly",
    name: "إيدوبا Pro – اشتراك شهري",
    description: "جميع المواد، رسائل واختبارات وتحديات غير محدودة، وتحليلات متقدمة للطالب.",
    type: "RECURRING",
    amount: 115,
    currency: "SAR",
    recurringInterval: "MONTH",
    recurringIntervalCount: 1,
    streamProductIdEnv: "STREAM_PRODUCT_PRO_MONTHLY_ID",
  },
  // One-time product used only to exercise the installments flow in the sandbox.
  // Keep it hidden in production or remove it once a real one-time package exists.
  test_one_time: {
    key: "test_one_time",
    name: "باقة تجريبية (اختبار الأقساط)",
    description: "منتج تجريبي لمرة واحدة لاختبار الدفع بالتقسيط في بيئة الاختبار.",
    type: "ONE_OFF",
    amount: 300,
    currency: "SAR",
    streamProductIdEnv: "STREAM_PRODUCT_TEST_ONE_TIME_ID",
    allowInstallments: true,
    hidden: true,
  },
};

export const PRO_PRICE_SAR = PRODUCTS.pro_monthly.amount;

export function getProduct(key: string | null | undefined): SiteProduct | undefined {
  if (!key) return undefined;
  return (PRODUCTS as Record<string, SiteProduct>)[key];
}

/** Legacy query values used by the original site (`?plan=pro`). */
export function resolveProductKey(plan: string | null | undefined): ProductKey | undefined {
  if (!plan) return undefined;
  if (plan === "pro" || plan === "pro_monthly") return "pro_monthly";
  if (plan === "test_one_time") return "test_one_time";
  return undefined;
}

/**
 * Payment methods sent with a payment link.
 * - Recurring products: `undefined` → organisation defaults (Stream disables installments itself).
 * - One-time products: explicit object; because the DTO is all-or-nothing, cards must be
 *   re-enabled alongside `installment`.
 */
export function paymentMethodsFor(product: SiteProduct): PaymentMethodsDto | undefined {
  if (product.type !== "ONE_OFF") return undefined;
  return {
    visa: true,
    mastercard: true,
    amex: process.env.STREAM_ENABLE_AMEX === "true",
    bank_transfer: false,
    installment: product.allowInstallments === true,
  };
}

export function streamProductIdFor(product: SiteProduct): string {
  const id = process.env[product.streamProductIdEnv];
  if (!id || id.trim() === "") {
    throw new Error(
      `Missing ${product.streamProductIdEnv}. Run \`npm run stream:setup\` and copy the printed ids into .env.`,
    );
  }
  return id.trim();
}
