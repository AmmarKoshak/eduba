/** Referral programme settings (env-overridable, see .env.example). */

function num(name: string, fallback: number): number {
  const v = Number(process.env[name]);
  return Number.isFinite(v) && v >= 0 ? v : fallback;
}

export const referralConfig = {
  /** Flat reward (SAR) a regular payer earns when someone they referred pays for the first time. */
  get payerRewardSar(): number {
    return num("REFERRAL_PAYER_REWARD_SAR", 20);
  },
  /** Default influencer commission, percent of the referred customer's first payment. */
  get influencerRatePercent(): number {
    return num("REFERRAL_INFLUENCER_RATE_PERCENT", 20);
  },
  /** Minimum wallet balance included in a monthly settlement run. */
  get settlementMinSar(): number {
    return num("SETTLEMENT_MIN_SAR", 100);
  },
  /** How long a referral cookie stays valid (days). */
  get cookieDays(): number {
    return num("REFERRAL_COOKIE_DAYS", 30);
  },
  cookieName: "eduba_ref",
};

export const REFERRAL_CODE_RE = /^[A-Z0-9]{6,12}$/;

const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O/1/I

export function generateReferralCode(length = 8, random: (n: number) => number = defaultRandom): string {
  let out = "";
  for (let i = 0; i < length; i++) out += ALPHABET[random(ALPHABET.length)];
  return out;
}

function defaultRandom(n: number): number {
  // crypto is global in Node 20+/browsers
  const buf = new Uint32Array(1);
  crypto.getRandomValues(buf);
  return buf[0] % n;
}

export function normalizeReferralCode(raw: string | null | undefined): string | null {
  if (!raw) return null;
  const code = raw.trim().toUpperCase().replace(/[\s-]/g, "");
  return REFERRAL_CODE_RE.test(code) ? code : null;
}

/** Commission for one rewarded referral. Pure, unit-tested. */
export function computeCommission(params: {
  orderAmount: number;
  referrerIsInfluencer: boolean;
  influencerRatePercent?: number | null;
  config?: { payerRewardSar: number; influencerRatePercent: number };
}): number {
  const cfg = params.config ?? { payerRewardSar: referralConfig.payerRewardSar, influencerRatePercent: referralConfig.influencerRatePercent };
  if (params.referrerIsInfluencer) {
    const rate = params.influencerRatePercent ?? cfg.influencerRatePercent;
    return Math.round(params.orderAmount * rate) / 100;
  }
  return Math.min(cfg.payerRewardSar, params.orderAmount);
}
