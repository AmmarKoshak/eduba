import "server-only";
import { and, desc, eq, ne, sql } from "drizzle-orm";
import { getDb, schema } from "@/lib/db";
import type { Order, Settlement, User, Wallet } from "@/lib/db/schema";
import { computeCommission, generateReferralCode, normalizeReferralCode, referralConfig } from "./config";

type Db = ReturnType<typeof getDb>;
type Tx = Parameters<Parameters<Db["transaction"]>[0]>[0];

// ---------------------------------------------------------------------------
// Referral codes
// ---------------------------------------------------------------------------

/** Returns the user's referral code, creating one on first use. */
export async function ensureReferralCode(userId: string): Promise<string> {
  const db = getDb();
  const [user] = await db.select({ code: schema.users.referralCode }).from(schema.users).where(eq(schema.users.id, userId)).limit(1);
  if (!user) throw new Error("user not found");
  if (user.code) return user.code;
  for (let attempt = 0; attempt < 5; attempt++) {
    const code = generateReferralCode();
    try {
      await db.update(schema.users).set({ referralCode: code, updatedAt: new Date() }).where(and(eq(schema.users.id, userId), sql`${schema.users.referralCode} is null`));
      const [again] = await db.select({ code: schema.users.referralCode }).from(schema.users).where(eq(schema.users.id, userId)).limit(1);
      if (again?.code) return again.code;
    } catch {
      // unique collision → retry
    }
  }
  throw new Error("could not allocate a referral code");
}

export async function findReferrerByCode(code: string | null | undefined): Promise<User | undefined> {
  const normalized = normalizeReferralCode(code);
  if (!normalized) return undefined;
  const db = getDb();
  const rows = await db.select().from(schema.users).where(eq(schema.users.referralCode, normalized)).limit(1);
  return rows[0];
}

/**
 * Decides who (if anyone) gets credit for a checkout. Self-referrals are ignored.
 * Returns the referrer and the code to store on the order.
 */
export async function resolveReferrer(params: {
  cookieCode?: string | null;
  payerUserId?: string | null;
  payerEmail: string;
}): Promise<{ referrer: User; code: string } | null> {
  const db = getDb();
  let code = normalizeReferralCode(params.cookieCode);
  // Fall back to the code the user signed up with.
  if (!code && params.payerUserId) {
    const [u] = await db.select({ referredByCode: schema.users.referredByCode }).from(schema.users).where(eq(schema.users.id, params.payerUserId)).limit(1);
    code = normalizeReferralCode(u?.referredByCode);
  }
  if (!code) return null;
  const referrer = await findReferrerByCode(code);
  if (!referrer) return null;
  if (params.payerUserId && referrer.id === params.payerUserId) return null;
  if (referrer.email.toLowerCase() === params.payerEmail.toLowerCase()) return null;
  return { referrer, code };
}

/** Records a pending referral for a new order (idempotent per order). */
export async function attachReferralToOrder(params: {
  orderId: string;
  referrer: User;
  code: string;
  referredUserId?: string | null;
  referredCustomerId: string;
}) {
  const db = getDb();
  await db
    .insert(schema.referrals)
    .values({
      referrerUserId: params.referrer.id,
      referralCode: params.code,
      referredUserId: params.referredUserId ?? null,
      referredCustomerId: params.referredCustomerId,
      orderId: params.orderId,
      status: "pending",
    })
    .onConflictDoNothing({ target: schema.referrals.orderId });
}

// ---------------------------------------------------------------------------
// Wallets
// ---------------------------------------------------------------------------

export async function getOrCreateWallet(userId: string, tx?: Tx): Promise<Wallet> {
  const db = tx ?? getDb();
  const [w] = await db
    .insert(schema.wallets)
    .values({ userId })
    .onConflictDoUpdate({ target: schema.wallets.userId, set: { updatedAt: new Date() } })
    .returning();
  return w;
}

/**
 * Books a wallet movement atomically (row lock + balance update + ledger row).
 * The idempotency key makes repeated calls (webhook retries) harmless.
 */
export async function bookWalletTransaction(params: {
  userId: string;
  type: "commission" | "settlement" | "settlement_reversal" | "adjustment";
  amount: number; // + credit / - debit
  idempotencyKey: string;
  orderId?: string | null;
  settlementId?: string | null;
  description?: string;
}): Promise<{ booked: boolean; wallet: Wallet }> {
  const db = getDb();
  return db.transaction(async (tx) => {
    const wallet = await getOrCreateWallet(params.userId, tx);
    const [locked] = await tx.execute<{ balance: string; lifetime_earned: string }>(
      sql`select balance, lifetime_earned from wallets where id = ${wallet.id} for update`,
    ).then((r) => r.rows);
    const existing = await tx.select({ id: schema.walletTransactions.id }).from(schema.walletTransactions).where(eq(schema.walletTransactions.idempotencyKey, params.idempotencyKey)).limit(1);
    if (existing[0]) return { booked: false, wallet };

    const balance = Number(locked?.balance ?? wallet.balance);
    const lifetime = Number(locked?.lifetime_earned ?? wallet.lifetimeEarned);
    const next = Math.round((balance + params.amount) * 100) / 100;
    if (next < -0.001) throw new Error("insufficient wallet balance");
    const nextLifetime = params.type === "commission" ? Math.round((lifetime + params.amount) * 100) / 100 : lifetime;

    await tx.insert(schema.walletTransactions).values({
      walletId: wallet.id,
      type: params.type,
      amount: params.amount.toFixed(2),
      balanceAfter: next.toFixed(2),
      idempotencyKey: params.idempotencyKey,
      orderId: params.orderId ?? null,
      settlementId: params.settlementId ?? null,
      description: params.description ?? null,
    });
    const [updated] = await tx
      .update(schema.wallets)
      .set({ balance: next.toFixed(2), lifetimeEarned: nextLifetime.toFixed(2), updatedAt: new Date() })
      .where(eq(schema.wallets.id, wallet.id))
      .returning();
    return { booked: true, wallet: updated };
  });
}

/**
 * Called when an order becomes paid. Credits the referrer once, on the
 * referred customer's first successful payment. Safe to call repeatedly.
 */
export async function rewardReferralForOrder(order: Order): Promise<string> {
  if (!order.referrerUserId) return "no referrer";
  const db = getDb();
  const [ref] = await db.select().from(schema.referrals).where(eq(schema.referrals.orderId, order.id)).limit(1);
  if (!ref) return "no referral row";
  if (ref.status !== "pending") return `already ${ref.status}`;

  // First payment only: any earlier rewarded referral for the same customer voids this one.
  const earlier = await db
    .select({ id: schema.referrals.id })
    .from(schema.referrals)
    .where(and(eq(schema.referrals.referredCustomerId, ref.referredCustomerId), eq(schema.referrals.status, "rewarded"), ne(schema.referrals.id, ref.id)))
    .limit(1);
  if (earlier[0]) {
    await db.update(schema.referrals).set({ status: "void", voidReason: "customer already rewarded" }).where(eq(schema.referrals.id, ref.id));
    return "void: not the customer's first payment";
  }

  const [referrer] = await db.select().from(schema.users).where(eq(schema.users.id, order.referrerUserId)).limit(1);
  if (!referrer) return "referrer missing";

  const amount = computeCommission({
    orderAmount: Number(order.amount),
    referrerIsInfluencer: referrer.isInfluencer,
    influencerRatePercent: referrer.commissionRatePercent ? Number(referrer.commissionRatePercent) : null,
  });
  if (amount <= 0) {
    await db.update(schema.referrals).set({ status: "void", voidReason: "zero commission" }).where(eq(schema.referrals.id, ref.id));
    return "void: zero commission";
  }

  const { booked } = await bookWalletTransaction({
    userId: referrer.id,
    type: "commission",
    amount,
    idempotencyKey: `commission:${order.id}`,
    orderId: order.id,
    description: referrer.isInfluencer ? `عمولة إحالة (${order.productKey})` : `مكافأة إحالة (${order.productKey})`,
  });
  await db
    .update(schema.referrals)
    .set({ status: "rewarded", commissionAmount: amount.toFixed(2), rewardedAt: new Date() })
    .where(eq(schema.referrals.id, ref.id));
  return booked ? `rewarded ${amount} SAR to ${referrer.email}` : "already booked";
}

// ---------------------------------------------------------------------------
// Settlements (monthly payouts, paid by bank transfer outside the system)
// ---------------------------------------------------------------------------

export function currentPeriod(now = new Date()): string {
  const riyadh = new Date(now.getTime() + 3 * 3600 * 1000);
  return `${riyadh.getUTCFullYear()}-${String(riyadh.getUTCMonth() + 1).padStart(2, "0")}`;
}

/** Creates a pending settlement for one wallet and reserves (debits) the amount. */
export async function createSettlement(params: {
  walletId: string;
  period: string;
  amount?: number; // defaults to the full balance
  createdByEmail: string;
  note?: string;
}): Promise<Settlement | null> {
  const db = getDb();
  const [wallet] = await db.select().from(schema.wallets).where(eq(schema.wallets.id, params.walletId)).limit(1);
  if (!wallet) throw new Error("wallet not found");
  const amount = Math.round((params.amount ?? Number(wallet.balance)) * 100) / 100;
  if (amount <= 0 || amount > Number(wallet.balance) + 0.001) throw new Error("invalid settlement amount");

  const [settlement] = await db
    .insert(schema.settlements)
    .values({ walletId: wallet.id, period: params.period, amount: amount.toFixed(2), currency: wallet.currency, createdByEmail: params.createdByEmail, note: params.note ?? null })
    .returning();
  await bookWalletTransaction({
    userId: wallet.userId,
    type: "settlement",
    amount: -amount,
    idempotencyKey: `settlement:${settlement.id}`,
    settlementId: settlement.id,
    description: `تسوية ${params.period}`,
  });
  return settlement;
}

/** Monthly run: one pending settlement per wallet with balance ≥ the minimum. */
export async function createMonthlySettlements(params: { period: string; createdByEmail: string }): Promise<{ created: number; skipped: number }> {
  const db = getDb();
  const min = referralConfig.settlementMinSar;
  const candidates = await db.select().from(schema.wallets).where(sql`${schema.wallets.balance} >= ${min.toFixed(2)}`);
  let created = 0;
  let skipped = 0;
  for (const w of candidates) {
    const open = await db
      .select({ id: schema.settlements.id })
      .from(schema.settlements)
      .where(and(eq(schema.settlements.walletId, w.id), eq(schema.settlements.period, params.period), eq(schema.settlements.status, "pending")))
      .limit(1);
    if (open[0]) {
      skipped++;
      continue;
    }
    await createSettlement({ walletId: w.id, period: params.period, createdByEmail: params.createdByEmail });
    created++;
  }
  return { created, skipped };
}

export async function markSettlementPaid(params: { settlementId: string; reference: string; note?: string }) {
  const db = getDb();
  const [s] = await db
    .update(schema.settlements)
    .set({ status: "paid", reference: params.reference, note: params.note ?? undefined, paidAt: new Date(), updatedAt: new Date() })
    .where(and(eq(schema.settlements.id, params.settlementId), eq(schema.settlements.status, "pending")))
    .returning();
  return s ?? null;
}

/** Cancels a pending settlement and returns the money to the wallet. */
export async function cancelSettlement(params: { settlementId: string; note?: string }) {
  const db = getDb();
  const [s] = await db
    .update(schema.settlements)
    .set({ status: "canceled", note: params.note ?? undefined, updatedAt: new Date() })
    .where(and(eq(schema.settlements.id, params.settlementId), eq(schema.settlements.status, "pending")))
    .returning();
  if (!s) return null;
  const [wallet] = await db.select().from(schema.wallets).where(eq(schema.wallets.id, s.walletId)).limit(1);
  await bookWalletTransaction({
    userId: wallet.userId,
    type: "settlement_reversal",
    amount: Number(s.amount),
    idempotencyKey: `settlement-reversal:${s.id}`,
    settlementId: s.id,
    description: `إلغاء تسوية ${s.period}`,
  });
  return s;
}

export async function setInfluencer(params: { userId: string; isInfluencer: boolean; ratePercent?: number | null }) {
  const db = getDb();
  const [u] = await db
    .update(schema.users)
    .set({
      isInfluencer: params.isInfluencer,
      commissionRatePercent: params.isInfluencer && params.ratePercent != null ? params.ratePercent.toFixed(2) : null,
      updatedAt: new Date(),
    })
    .where(eq(schema.users.id, params.userId))
    .returning();
  if (u && params.isInfluencer) await getOrCreateWallet(u.id);
  return u ?? null;
}

// ---------------------------------------------------------------------------
// Read models
// ---------------------------------------------------------------------------

export async function walletOverviewForUser(userId: string) {
  const db = getDb();
  const code = await ensureReferralCode(userId);
  const wallet = await getOrCreateWallet(userId);
  const transactions = await db.select().from(schema.walletTransactions).where(eq(schema.walletTransactions.walletId, wallet.id)).orderBy(desc(schema.walletTransactions.createdAt)).limit(50);
  const refs = await db
    .select({ referral: schema.referrals, customer: { name: schema.customers.name }, order: { amount: schema.orders.amount, status: schema.orders.status, createdAt: schema.orders.createdAt } })
    .from(schema.referrals)
    .innerJoin(schema.customers, eq(schema.referrals.referredCustomerId, schema.customers.id))
    .innerJoin(schema.orders, eq(schema.referrals.orderId, schema.orders.id))
    .where(eq(schema.referrals.referrerUserId, userId))
    .orderBy(desc(schema.referrals.createdAt))
    .limit(50);
  const settlementRows = await db.select().from(schema.settlements).where(eq(schema.settlements.walletId, wallet.id)).orderBy(desc(schema.settlements.createdAt)).limit(24);
  return { code, wallet, transactions, referrals: refs, settlements: settlementRows };
}
