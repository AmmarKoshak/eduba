import type { SiteProduct } from "@/lib/products";
import { paymentMethodsFor } from "@/lib/products";
import type { PaymentLinkCreate } from "@/lib/stream/types";

/**
 * Builds the body for `POST /api/v2/payment_links` for exactly one product.
 * Pure function so the rules below are unit-tested:
 *  - one product per link → recurring and one-time are never mixed;
 *  - consumer-bound links use `max_number_of_payments: 1`;
 *  - installments are requested only for one-time products.
 */
export function buildPaymentLinkPayload(params: {
  product: SiteProduct;
  streamProductId: string;
  consumerId: string;
  orderId: string;
  userId?: string | null;
  appUrl: string;
  now?: Date;
  validForHours?: number;
}): PaymentLinkCreate {
  const { product, streamProductId, consumerId, orderId, appUrl } = params;
  const now = params.now ?? new Date();
  const validUntil = new Date(now.getTime() + (params.validForHours ?? 24) * 3600 * 1000);
  const base = appUrl.replace(/\/+$/, "");

  const payload: PaymentLinkCreate = {
    name: product.name,
    description: product.description,
    currency: product.currency,
    items: [{ product_id: streamProductId, quantity: 1 }],
    max_number_of_payments: 1,
    valid_until: validUntil.toISOString(),
    organization_consumer_id: consumerId,
    contact_information_type: "PHONE",
    success_redirect_url: `${base}/checkout/success?order=${encodeURIComponent(orderId)}`,
    failure_redirect_url: `${base}/checkout/failed?order=${encodeURIComponent(orderId)}`,
    confirmation_message: "شكراً لك! تم استلام دفعتك وسيتم تفعيل اشتراكك فوراً.",
    custom_metadata: {
      order_id: orderId,
      product_key: product.key,
      user_id: params.userId ?? null,
      source: "website",
    },
  };

  const methods = paymentMethodsFor(product);
  if (methods) payload.payment_methods = methods;
  return payload;
}

/** Hosted checkout URL with the Arabic UI forced (Stream supports ?language=ar|en). */
export function withCheckoutLanguage(url: string, language: "ar" | "en" = "ar"): string {
  try {
    const u = new URL(url);
    u.searchParams.set("language", language);
    return u.toString();
  } catch {
    return url;
  }
}
