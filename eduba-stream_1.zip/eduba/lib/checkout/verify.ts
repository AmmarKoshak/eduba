import type { Invoice, Subscription } from "@/lib/stream/types";

/**
 * Pure verification rules applied to an invoice fetched from Stream before an
 * order is considered paid. The redirect query string is never trusted: the
 * invoice must belong to the payment link *we* created for this order, for the
 * consumer we bound it to, with the amount and currency we expect.
 */
export interface OrderExpectation {
  paymentLinkId: string;
  streamConsumerId: string;
  amount: number;
  currency: string;
}

export type InvoiceVerdict =
  | { state: "paid"; subscriptionId: string | null; paymentId: string | null; paidAt: string | null }
  | { state: "pending"; reason: string }
  | { state: "failed"; reason: string }
  | { state: "mismatch"; reason: string };

const PAID_PAYMENT_STATUSES = new Set(["SUCCEEDED", "SETTLED"]);

export function evaluateInvoice(invoice: Invoice, expected: OrderExpectation): InvoiceVerdict {
  if (!invoice.payment_link_id || invoice.payment_link_id !== expected.paymentLinkId) {
    return { state: "mismatch", reason: "invoice does not belong to this order's payment link" };
  }
  if (invoice.organization_consumer_id && invoice.organization_consumer_id !== expected.streamConsumerId) {
    return { state: "mismatch", reason: "invoice belongs to a different customer" };
  }
  if ((invoice.currency ?? "").toUpperCase() !== expected.currency.toUpperCase()) {
    return { state: "mismatch", reason: `currency ${invoice.currency} != ${expected.currency}` };
  }
  const total = Number(invoice.total_amount);
  if (!Number.isFinite(total) || Math.abs(total - expected.amount) > 0.009) {
    return { state: "mismatch", reason: `amount ${invoice.total_amount} != ${expected.amount}` };
  }

  const status = invoice.status;
  if (status === "CANCELED" || status === "EXPIRED" || status === "REJECTED") {
    return { state: "failed", reason: `invoice ${status}` };
  }

  const paidAmount = Number(invoice.paid_amount ?? 0);
  const successfulPayment = (invoice.payments ?? []).find(
    (p) => p.current_status && PAID_PAYMENT_STATUSES.has(p.current_status),
  );
  const fullyPaid =
    status === "COMPLETED" || (Number.isFinite(paidAmount) && paidAmount + 0.009 >= total && total > 0);
  // Installment plans: Stream collects the remaining instalments itself; the
  // purchase is fulfilled once the first instalment has actually succeeded.
  const firstInstalmentPaid =
    invoice.type === "INSTALLMENTS" && !!successfulPayment && Number.isFinite(paidAmount) && paidAmount > 0;

  if (fullyPaid || firstInstalmentPaid) {
    return {
      state: "paid",
      subscriptionId: invoice.subscription_id ?? invoice.subscription?.id ?? null,
      paymentId: successfulPayment?.id ?? null,
      paidAt: successfulPayment?.payed_at ?? invoice.last_payment_paid_at ?? null,
    };
  }
  return { state: "pending", reason: `invoice ${status ?? "unknown"}, paid ${paidAmount}/${total}` };
}

export const ACTIVE_SUBSCRIPTION_STATUSES = new Set(["ACTIVE", "TRIALING"]);

export function subscriptionSnapshot(sub: Subscription) {
  return {
    status: sub.status ?? "INACTIVE",
    amount: sub.amount ?? null,
    currency: sub.currency ?? null,
    currentPeriodStart: sub.current_period_start ? new Date(sub.current_period_start) : null,
    currentPeriodEnd: sub.current_period_end ? new Date(sub.current_period_end) : null,
    cancelAtPeriodEnd: sub.cancel_at_period_end === true,
  };
}
