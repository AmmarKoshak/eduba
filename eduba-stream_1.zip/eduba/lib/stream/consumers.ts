import { StreamApiError, type StreamClient } from "./client";
import type { Consumer } from "./types";

export interface ConsumerInput {
  name: string;
  email: string; // already lower-cased
  phone: string; // E.164
  externalId?: string;
}

function sameEmail(a: string | null | undefined, b: string): boolean {
  return !!a && a.trim().toLowerCase() === b;
}

function samePhone(a: string | null | undefined, b: string): boolean {
  if (!a) return false;
  const digits = (s: string) => s.replace(/\D/g, "");
  return digits(a) === digits(b);
}

/**
 * Looks a consumer up by exact email, then by exact phone. Stream's
 * `search_term` is a partial match over several fields, so results are
 * filtered client-side to avoid attaching a payment to the wrong person.
 */
export async function findConsumer(
  client: StreamClient,
  input: Pick<ConsumerInput, "email" | "phone">,
): Promise<Consumer | undefined> {
  for (const [term, matcher] of [
    [input.email, (c: Consumer) => sameEmail(c.email, input.email)],
    [input.phone, (c: Consumer) => samePhone(c.phone_number, input.phone)],
  ] as const) {
    if (!term) continue;
    const res = await client.listConsumers({ search_term: term, limit: 50, page: 1 });
    const match = (res.data ?? []).find((c) => !c.is_deleted && matcher(c));
    if (match) return match;
  }
  return undefined;
}

/**
 * Find-or-create with no duplicates:
 * 1. search by email / phone;
 * 2. create if nothing matched;
 * 3. if Stream still answers DUPLICATE_CONSUMER (race or partial match on its
 *    side), search again and reuse the existing record.
 */
export async function findOrCreateConsumer(
  client: StreamClient,
  input: ConsumerInput,
): Promise<{ consumer: Consumer; created: boolean }> {
  const existing = await findConsumer(client, input);
  if (existing) return { consumer: existing, created: false };

  try {
    const consumer = await client.createConsumer({
      name: input.name,
      email: input.email,
      phone_number: input.phone,
      external_id: input.externalId,
      preferred_language: "AR",
      communication_methods: ["EMAIL", "SMS"],
    });
    return { consumer, created: true };
  } catch (err) {
    const isDuplicate =
      err instanceof StreamApiError &&
      (err.code === "DUPLICATE_CONSUMER" || err.code === "PHONE_ALREADY_REGISTERED" || err.status === 422);
    if (!isDuplicate) throw err;
    const again = await findConsumer(client, input);
    if (again) return { consumer: again, created: false };
    throw err;
  }
}
