/**
 * Minimal typings for the Stream API v2 responses we touch.
 * Field names follow https://stream-app-service.streampay.sa/openapi.json
 * (also published in the official `@streamsdk/typescript` package).
 */

export type CurrencyCode = "SAR" | "USD" | "EUR" | "GBP" | "AED" | "BHD" | "KWD" | "OMR" | "QAR";
export type ProductType = "RECURRING" | "ONE_OFF";
export type RecurringInterval = "WEEK" | "MONTH" | "SEMESTER" | "YEAR";

export type InvoiceStatus =
  | "DRAFT"
  | "CREATED"
  | "SENT"
  | "ACCEPTED"
  | "REJECTED"
  | "COMPLETED"
  | "CANCELED"
  | "EXPIRED";

export type PaymentStatus =
  | "PENDING"
  | "PROCESSING"
  | "FAILED_INITIATION"
  | "SUCCEEDED"
  | "FAILED"
  | "CANCELED"
  | "UNDER_REVIEW"
  | "EXPIRED"
  | "SETTLED"
  | "REFUNDED"
  | "PARTIALLY_REFUNDED";

export type SubscriptionStatus =
  | "INACTIVE"
  | "ACTIVE"
  | "EXPIRED"
  | "CANCELED"
  | "FROZEN"
  | "TRIALING"
  | "TRIAL_PENDING";

export type PaymentLinkStatus = "INACTIVE" | "ACTIVE" | "COMPLETED";

export type PaymentMethodName =
  | "MADA"
  | "MASTERCARD"
  | "VISA"
  | "APPLE_PAY"
  | "SAMSUNG_PAY"
  | "AMEX"
  | "CASH"
  | "PGW_CARD_UNSPECIFIED"
  | "BANK_TRANSFER"
  | "CARD"
  | "QURRAH";

export interface Pagination {
  total_count?: number;
  max_page?: number;
  current_page?: number;
  limit?: number;
  has_next_page?: boolean;
  has_previous_page?: boolean;
}

export interface ListResponse<T> {
  data: T[];
  pagination: Pagination;
}

export interface Consumer {
  id: string;
  name?: string;
  email?: string | null;
  phone_number?: string | null;
  external_id?: string | null;
  is_deleted?: boolean;
  created_at?: string;
  preferred_language?: "AR" | "EN";
}

export interface ConsumerCreate {
  name: string;
  email?: string;
  phone_number?: string;
  external_id?: string;
  preferred_language?: "AR" | "EN";
  communication_methods?: Array<"WHATSAPP" | "EMAIL" | "SMS">;
}

export interface ProductPrice {
  id?: string;
  currency?: CurrencyCode;
  amount?: string;
  is_active?: boolean;
}

export interface Product {
  id: string;
  name?: string;
  description?: string | null;
  type?: ProductType;
  recurring_interval?: RecurringInterval;
  recurring_interval_count?: number;
  price?: string;
  currency: string;
  prices?: ProductPrice[];
  is_active?: boolean;
  is_one_time?: boolean;
}

export interface ProductCreate {
  name: string;
  description?: string | null;
  prices: Array<{
    currency: CurrencyCode;
    amount: number | string;
    is_price_inclusive_of_vat: boolean;
    is_price_exempt_from_vat: boolean;
  }>;
  is_one_time: boolean;
  type: ProductType;
  recurring_interval?: RecurringInterval;
  recurring_interval_count: number;
}

/** `payment_methods` on a payment link. If omitted, the organisation defaults apply. */
export interface PaymentMethodsDto {
  visa: boolean;
  mastercard: boolean;
  amex: boolean;
  bank_transfer: boolean;
  installment: boolean;
}

export interface PaymentLinkCreate {
  name: string;
  description?: string | null;
  currency: CurrencyCode;
  items: Array<{ product_id: string; quantity: number }>;
  max_number_of_payments?: number | null;
  valid_until?: string | null;
  confirmation_message?: string | null;
  payment_methods?: PaymentMethodsDto;
  trial_period_days?: number | null;
  success_redirect_url?: string | null;
  failure_redirect_url?: string | null;
  organization_consumer_id?: string | null;
  custom_metadata?: Record<string, unknown> | null;
  contact_information_type?: "PHONE" | "EMAIL";
}

export interface PaymentLink {
  id: string;
  name?: string;
  url: string;
  status?: PaymentLinkStatus;
  amount?: string;
  currency?: CurrencyCode;
  organization_consumer_id?: string | null;
  success_redirect_url?: string | null;
  failure_redirect_url?: string | null;
  custom_metadata?: Record<string, unknown> | null;
  valid_until?: string | null;
  created_at?: string;
  items?: Array<{ product_id?: string; quantity?: number; product?: Product }>;
}

export interface PaymentSummary {
  id: string;
  amount?: string;
  currency?: CurrencyCode;
  scheduled_on?: string;
  type?: "INITIAL" | "INSTALLMENT" | "SPLIT_PREPAID";
  payment_method?: PaymentMethodName;
  current_status?: PaymentStatus;
  payed_at?: string | null;
  settled_at?: string | null;
  refunded_at?: string | null;
  amount_refunded?: string | null;
  latest_pgw_message?: string | null;
  invoice_payment_number?: number;
}

export interface Payment extends PaymentSummary {
  organization_id?: string;
  created_by_type?: string;
}

export interface OrganizationConsumerRef {
  id?: string;
  name?: string;
  email?: string | null;
  phone_number?: string | null;
}

export interface InvoiceSubscriptionRef {
  id?: string;
  status?: SubscriptionStatus;
}

export interface Invoice {
  id: string;
  created_at?: string;
  updated_at?: string | null;
  payment_link_id?: string | null;
  organization_consumer_id?: string;
  org_invoice_number?: number;
  invoice_number?: string | null;
  description?: string | null;
  total_amount?: string;
  original_amount?: string;
  paid_amount?: string;
  remaining_amount?: string | null;
  currency: CurrencyCode;
  status?: InvoiceStatus;
  type?: "ONE_OFF" | "ONE_OFF_FUTURE" | "RECURRING" | "INSTALLMENTS" | "PRORATION";
  period_start?: string | null;
  period_end?: string | null;
  organization_consumer?: OrganizationConsumerRef;
  subscription_id?: string | null;
  subscription?: InvoiceSubscriptionRef | null;
  payments?: PaymentSummary[] | null;
  total_number_of_payments?: number;
  last_payment_paid_at?: string | null;
  url?: string | null;
}

export interface SubscriptionItem {
  id?: string;
  product_id?: string;
  product?: Product;
  quantity?: number;
  amount?: string;
}

export interface Subscription {
  id: string;
  created_at?: string;
  updated_at?: string | null;
  description?: string | null;
  amount?: string;
  currency?: CurrencyCode;
  recurring_interval?: "WEEK" | "MONTH" | "QUARTER" | "YEAR";
  recurring_interval_count?: number;
  status?: SubscriptionStatus;
  current_period_start?: string;
  current_period_end?: string;
  current_cycle_number?: number;
  cancel_at_period_end?: boolean;
  started_at?: string | null;
  ended_at?: string | null;
  organization_consumer_id?: string;
  latest_invoice_id?: string | null;
  trial_end?: string | null;
  organization_consumer?: OrganizationConsumerRef;
  items?: SubscriptionItem[] | null;
}

export interface PortalSession {
  id: string;
  url: string;
  created_at?: string;
  expires_at?: string;
}

export interface WebhookRegistration {
  id: string;
  url: string;
  name?: string;
  enabled?: boolean;
  health_status?: string;
  event_subscriptions?: Array<{ event_type?: string } | string>;
}

export interface MeResponse {
  user?: { id?: string; email?: string; name?: string };
  organization?: { id?: string; name?: string; sandbox?: boolean };
}

/** Body of every webhook delivery. */
export interface StreamWebhookPayload {
  event_type: string;
  entity_type?: string;
  entity_id?: string;
  entity_url?: string;
  status?: string;
  timestamp?: string;
  data?: {
    invoice?: { id?: string; url?: string };
    payment?: { id?: string; url?: string };
    subscription?: { id?: string; url?: string };
    metadata?: Record<string, unknown>;
    [key: string]: unknown;
  };
}

export interface StreamErrorBody {
  error?: { code?: string; message?: string; additional_info?: unknown };
  detail?: unknown;
}
