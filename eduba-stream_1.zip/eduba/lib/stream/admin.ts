import "server-only";
import { currentMonthRange } from "@/lib/format";
import { stream, type Query } from "./client";
import type { Consumer, Invoice, ListResponse, Payment, Subscription } from "./types";
import { env } from "@/lib/env";

/** Filters shared by the admin list pages (all optional, from the URL query string). */
export interface AdminListFilters {
  page?: number;
  limit?: number;
  from?: string; // YYYY-MM-DD
  to?: string; // YYYY-MM-DD
  status?: string; // one status, or empty for all
  q?: string; // customer / free-text search
  consumerId?: string;
}

export const PAGE_SIZES = [10, 25, 50, 100] as const;

export function parseFilters(sp: Record<string, string | string[] | undefined>): AdminListFilters {
  const one = (k: string) => (Array.isArray(sp[k]) ? sp[k]?.[0] : sp[k]) ?? "";
  const page = Math.max(1, Number.parseInt(one("page") || "1", 10) || 1);
  const limitRaw = Number.parseInt(one("limit") || "25", 10);
  const limit = (PAGE_SIZES as readonly number[]).includes(limitRaw) ? limitRaw : 25;
  const date = (v: string) => (/^\d{4}-\d{2}-\d{2}$/.test(v) ? v : "");
  return {
    page,
    limit,
    from: date(one("from")),
    to: date(one("to")),
    status: one("status").toUpperCase().replace(/[^A-Z_]/g, "").slice(0, 40),
    q: one("q").slice(0, 100),
    consumerId: /^[0-9a-f-]{36}$/i.test(one("consumer")) ? one("consumer") : "",
  };
}

/** Riyadh-local day boundaries → ISO timestamps understood by Stream's from_date/to_date. */
function dayStartIso(d: string) {
  return `${d}T00:00:00+03:00`;
}
function dayEndIso(d: string) {
  return `${d}T23:59:59+03:00`;
}

function baseQuery(f: AdminListFilters): Query {
  return {
    page: f.page,
    limit: f.limit,
    from_date: f.from ? dayStartIso(f.from) : undefined,
    to_date: f.to ? dayEndIso(f.to) : undefined,
    search_term: f.q || undefined,
    sort_field: "created_at",
    sort_direction: "desc",
  };
}

export async function adminListInvoices(f: AdminListFilters): Promise<ListResponse<Invoice>> {
  return stream().listInvoices({
    ...baseQuery(f),
    include_payments: true,
    statuses: f.status ? [f.status] : undefined,
    organization_consumer_id: f.consumerId || undefined,
  });
}

export async function adminListPayments(f: AdminListFilters): Promise<ListResponse<Payment>> {
  return stream().listPayments({
    ...baseQuery(f),
    statuses: f.status ? [f.status] : undefined,
  });
}

export async function adminListSubscriptions(f: AdminListFilters): Promise<ListResponse<Subscription>> {
  return stream().listSubscriptions({
    ...baseQuery(f),
    statuses: f.status ? [f.status] : undefined,
    organization_consumer_id: f.consumerId || undefined,
  });
}

export async function adminListConsumers(f: AdminListFilters): Promise<ListResponse<Consumer>> {
  return stream().listConsumers({
    page: f.page,
    limit: f.limit,
    search_term: f.q || undefined,
    sort_field: "created_at",
    sort_direction: "desc",
  });
}

/** Iterates pages (max `maxPages` × 100 rows) and returns all rows. */
async function collectAll<T>(fetchPage: (page: number) => Promise<ListResponse<T>>, maxPages = 10): Promise<T[]> {
  const out: T[] = [];
  for (let page = 1; page <= maxPages; page++) {
    const res = await fetchPage(page);
    out.push(...(res.data ?? []));
    if (!res.pagination?.has_next_page) break;
  }
  return out;
}

export interface AdminSummary {
  revenueThisMonth: number;
  paymentsThisMonth: number;
  activeSubscriptions: number;
  failedPaymentsThisMonth: number;
  currency: string;
  monthFrom: string;
  monthTo: string;
  partial: boolean;
}

const PAID = new Set(["SUCCEEDED", "SETTLED"]);

/**
 * Summary cards. Revenue counts SUCCEEDED/SETTLED payments whose paid date
 * falls in the current month (Asia/Riyadh); failed = FAILED payments created
 * this month; active = ACTIVE + TRIALING subscriptions.
 */
export async function adminSummary(): Promise<AdminSummary> {
  const { from, to } = currentMonthRange();
  let partial = false;

  const [paid, failed, active] = await Promise.all([
    collectAll<Payment>((page) =>
      stream().listPayments({ statuses: ["SUCCEEDED", "SETTLED"], from_date: from, to_date: to, page, limit: 100 }),
    ).catch((e) => {
      console.error("[admin] revenue query failed", e);
      partial = true;
      return [] as Payment[];
    }),
    collectAll<Payment>((page) => stream().listPayments({ statuses: ["FAILED"], from_date: from, to_date: to, page, limit: 100 })).catch(
      (e) => {
        console.error("[admin] failed payments query failed", e);
        partial = true;
        return [] as Payment[];
      },
    ),
    collectAll<Subscription>((page) => stream().listSubscriptions({ statuses: ["ACTIVE", "TRIALING"], page, limit: 100 })).catch(
      (e) => {
        console.error("[admin] subscriptions query failed", e);
        partial = true;
        return [] as Subscription[];
      },
    ),
  ]);

  const fromMs = Date.parse(from);
  const toMs = Date.parse(to);
  const inMonth = (p: Payment) => {
    const t = Date.parse(p.payed_at ?? p.settled_at ?? p.scheduled_on ?? "");
    return Number.isFinite(t) ? t >= fromMs && t <= toMs : true;
  };
  const paidInMonth = paid.filter((p) => p.current_status && PAID.has(p.current_status) && inMonth(p));
  const revenue = paidInMonth.reduce((sum, p) => sum + (Number(p.amount) || 0) - (Number(p.amount_refunded) || 0), 0);

  return {
    revenueThisMonth: Math.round(revenue * 100) / 100,
    paymentsThisMonth: paidInMonth.length,
    activeSubscriptions: active.length,
    failedPaymentsThisMonth: failed.length,
    currency: "SAR",
    monthFrom: from,
    monthTo: to,
    partial,
  };
}

/** Deep links into the Stream dashboard (path pattern is an assumption; base is configurable). */
export const dashboardUrl = {
  invoice: (id: string) => `${env.streamDashboardUrl}/invoices/${encodeURIComponent(id)}`,
  payment: (id: string) => `${env.streamDashboardUrl}/payments/${encodeURIComponent(id)}`,
  subscription: (id: string) => `${env.streamDashboardUrl}/subscriptions/${encodeURIComponent(id)}`,
  consumer: (id: string) => `${env.streamDashboardUrl}/consumers/${encodeURIComponent(id)}`,
  paymentLink: (id: string) => `${env.streamDashboardUrl}/payment-links/${encodeURIComponent(id)}`,
};
