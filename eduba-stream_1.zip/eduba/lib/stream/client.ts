import { env } from "@/lib/env";
import type {
  Consumer,
  ConsumerCreate,
  Invoice,
  ListResponse,
  MeResponse,
  Payment,
  PaymentLink,
  PaymentLinkCreate,
  PortalSession,
  Product,
  ProductCreate,
  StreamErrorBody,
  Subscription,
  WebhookRegistration,
} from "./types";

/**
 * Thin, server-only wrapper around the Stream REST API.
 *
 * - Auth header `x-api-key: Base64("API_KEY:API_SECRET")` comes from env only.
 * - Never import this module from a client component.
 */

export type QueryValue = string | number | boolean | null | undefined | Array<string | number>;
export type Query = Record<string, QueryValue>;

export class StreamApiError extends Error {
  readonly status: number;
  readonly code?: string;
  readonly body?: StreamErrorBody | string;

  constructor(message: string, status: number, body?: StreamErrorBody | string) {
    super(message);
    this.name = "StreamApiError";
    this.status = status;
    this.body = body;
    if (body && typeof body === "object" && body.error?.code) this.code = body.error.code;
  }
}

export function buildQuery(query?: Query): string {
  if (!query) return "";
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(query)) {
    if (value === undefined || value === null || value === "") continue;
    if (Array.isArray(value)) {
      // Stream expects repeated keys for array filters: statuses=A&statuses=B
      for (const v of value) params.append(key, String(v));
    } else {
      params.append(key, String(value));
    }
  }
  const s = params.toString();
  return s ? `?${s}` : "";
}

type FetchLike = typeof fetch;

export interface StreamClientOptions {
  baseUrl?: string;
  authHeader?: string;
  fetchFn?: FetchLike;
}

export class StreamClient {
  private readonly baseUrl: string;
  private readonly authHeader: string;
  private readonly fetchFn: FetchLike;

  constructor(opts: StreamClientOptions = {}) {
    this.baseUrl = (opts.baseUrl ?? env.streamApiBaseUrl).replace(/\/+$/, "");
    this.authHeader = opts.authHeader ?? env.streamAuthHeader;
    this.fetchFn = opts.fetchFn ?? fetch;
  }

  async request<T>(
    method: "GET" | "POST" | "PUT" | "PATCH" | "DELETE",
    path: string,
    opts: { query?: Query; body?: unknown } = {},
  ): Promise<T> {
    const url = `${this.baseUrl}${path.startsWith("/") ? path : `/${path}`}${buildQuery(opts.query)}`;
    const res = await this.fetchFn(url, {
      method,
      headers: {
        "x-api-key": this.authHeader,
        Accept: "application/json",
        ...(opts.body !== undefined ? { "Content-Type": "application/json" } : {}),
      },
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
      cache: "no-store",
    });

    const text = await res.text();
    let parsed: unknown = text;
    if (text) {
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = text;
      }
    }

    if (!res.ok) {
      const body = parsed as StreamErrorBody | string;
      const msg =
        typeof body === "object" && body?.error?.message
          ? body.error.message
          : `Stream API ${method} ${path} failed with HTTP ${res.status}`;
      throw new StreamApiError(msg, res.status, body);
    }
    return parsed as T;
  }

  // --- Account ---------------------------------------------------------------
  me() {
    return this.request<MeResponse>("GET", "/me");
  }

  // --- Consumers -------------------------------------------------------------
  listConsumers(query: Query) {
    return this.request<ListResponse<Consumer>>("GET", "/consumers", { query });
  }
  getConsumer(id: string) {
    return this.request<Consumer>("GET", `/consumers/${encodeURIComponent(id)}`);
  }
  createConsumer(body: ConsumerCreate) {
    return this.request<Consumer>("POST", "/consumers", { body });
  }

  // --- Products --------------------------------------------------------------
  listProducts(query: Query) {
    return this.request<ListResponse<Product>>("GET", "/products", { query });
  }
  getProduct(id: string) {
    return this.request<Product>("GET", `/products/${encodeURIComponent(id)}`);
  }
  createProduct(body: ProductCreate) {
    return this.request<Product>("POST", "/products", { body });
  }

  // --- Payment links ---------------------------------------------------------
  createPaymentLink(body: PaymentLinkCreate) {
    return this.request<PaymentLink>("POST", "/payment_links", { body });
  }
  getPaymentLink(id: string) {
    return this.request<PaymentLink>("GET", `/payment_links/${encodeURIComponent(id)}`);
  }

  // --- Invoices / payments / subscriptions ----------------------------------
  getInvoice(id: string) {
    return this.request<Invoice>("GET", `/invoices/${encodeURIComponent(id)}`);
  }
  listInvoices(query: Query) {
    return this.request<ListResponse<Invoice>>("GET", "/invoices", { query });
  }
  getPayment(id: string) {
    return this.request<Payment>("GET", `/payments/${encodeURIComponent(id)}`);
  }
  listPayments(query: Query) {
    return this.request<ListResponse<Payment>>("GET", "/payments", { query });
  }
  getSubscription(id: string) {
    return this.request<Subscription>("GET", `/subscriptions/${encodeURIComponent(id)}`);
  }
  listSubscriptions(query: Query) {
    return this.request<ListResponse<Subscription>>("GET", "/subscriptions", { query });
  }

  // --- Customer portal -------------------------------------------------------
  createPortalSession(body: { organization_consumer_id: string; subscription_id?: string }) {
    return this.request<PortalSession>("POST", "/consumer_portal/sessions", { body });
  }

  // --- Webhooks (used by the setup script) ----------------------------------
  listWebhooks() {
    return this.request<ListResponse<WebhookRegistration> | WebhookRegistration[]>(
      "GET",
      "/webhooks",
    );
  }
  listWebhookEvents() {
    return this.request<unknown>("GET", "/webhooks/events");
  }
  createWebhook(body: {
    url: string;
    enabled: boolean;
    secret_key: string;
    name: string;
    subscriptions: string[];
  }) {
    return this.request<WebhookRegistration>("POST", "/webhooks", { body });
  }
}

let cached: StreamClient | undefined;

/** Shared client for server code. Reads credentials from env on first use. */
export function stream(): StreamClient {
  if (!cached) cached = new StreamClient();
  return cached;
}
