import { createHmac, timingSafeEqual } from "node:crypto";

/**
 * Verification of Stream's `X-Webhook-Signature` header.
 *
 * Header format:  t=<unix-seconds-or-iso>,v1=<hex hmac>
 * Signed string:  `${t}.${rawBody}`
 * Algorithm:      HMAC-SHA256 with the webhook's secret key, hex-encoded.
 *
 * Pure function (no env, no I/O) so it is easy to unit-test.
 */

export interface ParsedSignature {
  timestamp: string;
  signatures: string[];
}

export function parseSignatureHeader(header: string | null | undefined): ParsedSignature | null {
  if (!header) return null;
  let timestamp: string | undefined;
  const signatures: string[] = [];
  for (const part of header.split(",")) {
    const idx = part.indexOf("=");
    if (idx === -1) continue;
    const key = part.slice(0, idx).trim();
    const value = part.slice(idx + 1).trim();
    if (key === "t") timestamp = value;
    else if (key === "v1" && value) signatures.push(value);
  }
  if (!timestamp || signatures.length === 0) return null;
  return { timestamp, signatures };
}

export function computeSignature(secret: string, timestamp: string, rawBody: string | Buffer): string {
  const body = typeof rawBody === "string" ? Buffer.from(rawBody, "utf8") : rawBody;
  return createHmac("sha256", secret)
    .update(Buffer.concat([Buffer.from(`${timestamp}.`, "utf8"), body]))
    .digest("hex");
}

function safeEqualHex(a: string, b: string): boolean {
  const ab = Buffer.from(a.toLowerCase(), "utf8");
  const bb = Buffer.from(b.toLowerCase(), "utf8");
  if (ab.length !== bb.length) return false;
  return timingSafeEqual(ab, bb);
}

/** Accepts unix seconds, unix milliseconds or an ISO-8601 string. Returns ms since epoch or NaN. */
export function timestampToMillis(ts: string): number {
  if (/^\d+$/.test(ts)) {
    const n = Number(ts);
    return n > 1e12 ? n : n * 1000;
  }
  return Date.parse(ts);
}

export interface VerifyResult {
  ok: boolean;
  reason?: "missing_header" | "malformed_header" | "bad_signature" | "stale_timestamp";
}

export function verifyStreamSignature(params: {
  secret: string;
  rawBody: string | Buffer;
  signatureHeader: string | null | undefined;
  /** Max allowed skew in seconds. 0 disables the check. Default 300. */
  toleranceSeconds?: number;
  now?: number;
}): VerifyResult {
  const { secret, rawBody, signatureHeader } = params;
  const tolerance = params.toleranceSeconds ?? 300;
  if (!signatureHeader) return { ok: false, reason: "missing_header" };
  const parsed = parseSignatureHeader(signatureHeader);
  if (!parsed) return { ok: false, reason: "malformed_header" };

  const expected = computeSignature(secret, parsed.timestamp, rawBody);
  const matches = parsed.signatures.some((sig) => safeEqualHex(sig, expected));
  if (!matches) return { ok: false, reason: "bad_signature" };

  if (tolerance > 0) {
    const tsMs = timestampToMillis(parsed.timestamp);
    const now = params.now ?? Date.now();
    if (!Number.isFinite(tsMs) || Math.abs(now - tsMs) > tolerance * 1000) {
      return { ok: false, reason: "stale_timestamp" };
    }
  }
  return { ok: true };
}
