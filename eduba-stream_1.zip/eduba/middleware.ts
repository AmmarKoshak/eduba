import NextAuth from "next-auth";
import { NextResponse } from "next/server";
import { authConfig } from "./auth.config";

const REF_COOKIE = "eduba_ref";
const REF_RE = /^[A-Za-z0-9]{6,12}$/;
const PROTECTED = ["/admin", "/account"];

const { auth } = NextAuth(authConfig);

/**
 * - Protects /admin and /account: anonymous visitors go to /sign-in (logged-in
 *   non-admins get the 403 page from the admin layout).
 * - Remembers `?ref=CODE` on any page in the referral cookie (30 days).
 * Uses the edge-safe config only: no database access here.
 */
export default auth((req) => {
  const { pathname, search } = req.nextUrl;

  if (PROTECTED.some((p) => pathname === p || pathname.startsWith(`${p}/`)) && !req.auth?.user) {
    const signIn = new URL("/sign-in", req.nextUrl.origin);
    signIn.searchParams.set("callbackUrl", `${pathname}${search}`);
    return NextResponse.redirect(signIn);
  }

  const ref = req.nextUrl.searchParams.get("ref");
  if (ref && REF_RE.test(ref)) {
    const res = NextResponse.next();
    res.cookies.set(REF_COOKIE, ref.toUpperCase(), {
      httpOnly: true,
      sameSite: "lax",
      secure: req.nextUrl.protocol === "https:",
      path: "/",
      maxAge: 30 * 24 * 3600,
    });
    return res;
  }
  return NextResponse.next();
});

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|api/|.*\\.(?:png|jpg|jpeg|gif|svg|ico|txt|woff2?|css|js|map)$).*)"],
};
