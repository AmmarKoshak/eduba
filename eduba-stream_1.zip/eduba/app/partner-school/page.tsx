import Link from "next/link";
import { School } from "lucide-react";
import { Card, PageShell, primaryButtonClass } from "@/components/site/PageShell";

export const metadata = { title: "طالب في مدرسة شريكة | إيدوبا" };

export default function PartnerSchoolPage() {
  return (
    <PageShell width="min(92%,640px)">
      <Card className="p-8 sm:p-10 text-center">
        <School className="w-12 h-12 text-primary mx-auto mb-4" />
        <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-3">طالب في مدرسة شريكة؟</h1>
        <p className="text-sm sm:text-base text-muted-foreground mb-6">
          اطلب من مدرستك رمز الدخول (QR) أو الرابط السحري، ثم افتحه من جوالك لتبدأ مباشرة بدون تسجيل منفصل.
        </p>
        <Link href="/sign-in" className={primaryButtonClass}>
          لديّ حساب — تسجيل الدخول
        </Link>
      </Card>
    </PageShell>
  );
}
