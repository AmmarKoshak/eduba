import Link from "next/link";
import { XCircle } from "lucide-react";
import { Card, PageShell, primaryButtonClass, secondaryButtonClass } from "@/components/site/PageShell";
import { getOrder, recordOrderFailure } from "@/lib/checkout/service";

export const metadata = { title: "لم تكتمل عملية الدفع | إيدوبا" };
export const dynamic = "force-dynamic";

type Params = { order?: string; status?: string; message?: string };

const MESSAGES: Record<string, string> = {
  failed: "تم رفض عملية الدفع من البنك أو تم إلغاؤها. لم يتم خصم أي مبلغ.",
  failed_internal_error:
    "حدث خطأ أثناء معالجة الدفع. إذا ظهر لك خصم في كشف حسابك فتواصل معنا قبل إعادة المحاولة.",
};

export default async function CheckoutFailedPage({ searchParams }: { searchParams: Promise<Params> }) {
  const params = await searchParams;
  const orderId = params.order ?? "";
  const order = orderId ? await getOrder(orderId) : undefined;
  if (order && order.status === "pending") {
    await recordOrderFailure(order.id, `redirect:${params.status ?? "failed"}:${params.message ?? ""}`.slice(0, 200));
  }
  const text = MESSAGES[params.status ?? "failed"] ?? MESSAGES.failed;

  return (
    <PageShell width="min(92%,640px)">
      <Card className="p-8 sm:p-10 text-center">
        <XCircle className="w-16 h-16 text-red-500 mx-auto mb-5" strokeWidth={1.75} />
        <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">لم تكتمل عملية الدفع</h1>
        <p className="text-sm sm:text-base text-muted-foreground mb-6">{text}</p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link href={`/checkout?plan=${order?.productKey ?? "pro_monthly"}`} className={primaryButtonClass}>
            المحاولة مرة أخرى
          </Link>
          <Link href="/" className={secondaryButtonClass}>
            الصفحة الرئيسية
          </Link>
        </div>
      </Card>
    </PageShell>
  );
}
