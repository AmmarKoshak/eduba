import Link from "next/link";
import { AlertTriangle, CheckCircle2, Clock } from "lucide-react";
import { PaymentStatusPoller } from "@/components/checkout/PaymentStatusPoller";
import { Card, PageShell, primaryButtonClass, secondaryButtonClass } from "@/components/site/PageShell";
import { CheckoutError, verifyOrderPayment } from "@/lib/checkout/service";
import { formatMoney } from "@/lib/format";
import { getProduct } from "@/lib/products";

export const metadata = { title: "تأكيد الدفع | إيدوبا" };
export const dynamic = "force-dynamic";

type Params = { order?: string; invoice_id?: string; payment_id?: string; status?: string };

/**
 * Stream redirects here with ?order=<our id>&invoice_id=…&payment_id=…&status=paid.
 * The query string is only a hint: "paid" is shown exclusively after the
 * invoice has been fetched from Stream and verified against the order.
 */
export default async function CheckoutSuccessPage({ searchParams }: { searchParams: Promise<Params> }) {
  const params = await searchParams;
  const orderId = params.order ?? "";

  let outcome: Awaited<ReturnType<typeof verifyOrderPayment>> | null = null;
  let error: string | null = null;
  try {
    outcome = await verifyOrderPayment(orderId, {
      invoiceId: params.invoice_id ?? null,
      paymentId: params.payment_id ?? null,
    });
  } catch (err) {
    error =
      err instanceof CheckoutError && err.code === "order_not_found"
        ? "لم نعثر على هذا الطلب."
        : "تعذّر التحقق من حالة الدفع الآن.";
    console.error("[checkout/success]", err);
  }

  const product = outcome ? getProduct(outcome.order.productKey) : undefined;
  const state = outcome?.verdict.state ?? "error";

  return (
    <PageShell width="min(92%,640px)">
      <Card className="p-8 sm:p-10 text-center">
        {state === "paid" && (
          <>
            <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto mb-5" strokeWidth={1.75} />
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">تم الدفع بنجاح 🎉</h1>
            <p className="text-sm sm:text-base text-muted-foreground mb-6">
              تم تفعيل {product?.type === "RECURRING" ? "اشتراكك في إيدوبا Pro" : product?.name ?? "طلبك"}
              {outcome && ` بقيمة ${formatMoney(outcome.order.amount, outcome.order.currency)}`}. سيصلك تأكيد على بريدك
              الإلكتروني وجوالك.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link href="/account" className={primaryButtonClass}>
                الذهاب إلى حسابي
              </Link>
              <Link href="/" className={secondaryButtonClass}>
                الصفحة الرئيسية
              </Link>
            </div>
            {outcome?.order.invoiceId && (
              <p className="mt-6 text-[11px] text-muted-foreground" dir="ltr">
                رقم الفاتورة: {outcome.order.invoiceId}
              </p>
            )}
          </>
        )}

        {(state === "pending" || state === "unknown") && outcome && (
          <>
            <Clock className="w-16 h-16 text-primary mx-auto mb-5" strokeWidth={1.75} />
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">جارٍ تأكيد الدفع</h1>
            <p className="text-sm sm:text-base text-muted-foreground mb-6">
              استلمنا طلبك ونتحقق الآن من الدفع مع Stream. لا تغلق هذه الصفحة.
            </p>
            <PaymentStatusPoller orderId={outcome.order.id} invoiceId={params.invoice_id ?? outcome.order.invoiceId} />
          </>
        )}

        {(state === "failed" || state === "mismatch") && outcome && (
          <>
            <AlertTriangle className="w-16 h-16 text-amber-500 mx-auto mb-5" strokeWidth={1.75} />
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">
              {state === "failed" ? "لم تكتمل عملية الدفع" : "تعذّر التحقق من هذه الدفعة"}
            </h1>
            <p className="text-sm sm:text-base text-muted-foreground mb-6">
              {state === "failed"
                ? "لم يتم خصم أي مبلغ. يمكنك المحاولة مرة أخرى."
                : "بيانات الدفعة لا تطابق طلبك. إذا تم خصم مبلغ منك فتواصل معنا وسنراجعها فوراً."}
            </p>
            <Link href={`/checkout?plan=${outcome.order.productKey}`} className={primaryButtonClass}>
              المحاولة مرة أخرى
            </Link>
          </>
        )}

        {state === "error" && (
          <>
            <AlertTriangle className="w-16 h-16 text-amber-500 mx-auto mb-5" strokeWidth={1.75} />
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">تعذّر التحقق</h1>
            <p className="text-sm sm:text-base text-muted-foreground mb-6">{error}</p>
            <Link href="/" className={secondaryButtonClass}>
              الصفحة الرئيسية
            </Link>
          </>
        )}
      </Card>
    </PageShell>
  );
}
