import Link from "next/link";
import { Check } from "lucide-react";
import { auth } from "@/auth";
import { CheckoutForm } from "@/components/checkout/CheckoutForm";
import { Card, PageShell, SectionLabel } from "@/components/site/PageShell";
import { env } from "@/lib/env";
import { findUserById } from "@/lib/auth/users";
import { formatMoney } from "@/lib/format";
import { getProduct, resolveProductKey } from "@/lib/products";

export const metadata = { title: "الاشتراك في إيدوبا Pro | إيدوبا" };
export const dynamic = "force-dynamic";

const PRO_FEATURES = [
  "رسائل غير محدودة مع المعلّم الذكي",
  "جميع الاختبارات بلا حدود",
  "تحديات غير محدودة",
  "حساب الأهل الكامل",
  "تحليلات ذكاء اصطناعي متقدمة للطالب",
];

export default async function CheckoutPage({
  searchParams,
}: {
  searchParams: Promise<{ plan?: string }>;
}) {
  const { plan } = await searchParams;
  const productKey = resolveProductKey(plan) ?? "pro_monthly";
  const product = getProduct(productKey);
  const session = await auth();
  const user = session?.user?.id ? await findUserById(session.user.id) : undefined;

  if (!product) {
    return (
      <PageShell width="min(92%,640px)">
        <Card className="p-8 text-center">
          <h1 className="text-2xl font-bold mb-3">الباقة غير موجودة</h1>
          <Link href="/#pricing" className="text-primary font-bold hover:underline">
            العودة إلى الأسعار
          </Link>
        </Card>
      </PageShell>
    );
  }

  const isRecurring = product.type === "RECURRING";

  return (
    <PageShell>
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-8 lg:gap-12 items-start">
        <div className="order-2 lg:order-1">
          <SectionLabel>الدفع</SectionLabel>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-foreground mb-2">
            {isRecurring ? "اشترك في إيدوبا Pro" : product.name}
          </h1>
          <p className="text-sm sm:text-base text-muted-foreground mb-6">
            أدخل بياناتك ثم أكمل الدفع بأمان عبر Stream. {isRecurring && "يتجدد الاشتراك شهرياً ويمكنك إلغاؤه في أي وقت."}
          </p>
          <Card className="p-5 sm:p-7">
            <CheckoutForm
              productKey={product.key}
              defaults={{ name: user?.name, email: user?.email, phone: user?.phone }}
              embedScriptUrl={env.streamEmbedScriptUrl}
            />
          </Card>
        </div>

        <aside className="order-1 lg:order-2">
          <Card className="p-6 sm:p-7 lg:sticky lg:top-6">
            <div className="text-sm font-bold text-muted-foreground mb-3 text-start">ملخص الطلب</div>
            <div className="flex items-baseline justify-between gap-3 mb-1">
              <span className="text-lg font-bold text-foreground">{isRecurring ? "إيدوبا Pro" : product.name}</span>
              <span className="text-2xl font-black text-foreground">{formatMoney(product.amount, product.currency)}</span>
            </div>
            <div className="text-xs text-muted-foreground mb-5">
              {isRecurring ? "يُجدَّد شهرياً • شامل ضريبة القيمة المضافة" : "دفعة واحدة • يمكن التقسيط على 2-4 دفعات"}
            </div>
            <ul className="space-y-2.5 border-t border-border pt-5">
              {(isRecurring ? PRO_FEATURES : [product.description]).map((f) => (
                <li key={f} className="flex items-start gap-2.5 text-sm text-foreground">
                  <span className="shrink-0 mt-0.5 inline-flex w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 items-center justify-center">
                    <Check className="w-3 h-3" strokeWidth={3} />
                  </span>
                  <span className="flex-1 text-start">{f}</span>
                </li>
              ))}
            </ul>
          </Card>
        </aside>
      </div>
    </PageShell>
  );
}
