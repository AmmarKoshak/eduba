"use server";

import { cookies } from "next/headers";
import { auth } from "@/auth";
import { CheckoutError, createCheckout } from "@/lib/checkout/service";
import { referralConfig } from "@/lib/referrals/config";

export interface StartCheckoutState {
  ok: boolean;
  error?: string;
  orderId?: string;
  paymentLinkUrl?: string;
}

export async function startCheckout(_prev: StartCheckoutState | null, formData: FormData): Promise<StartCheckoutState> {
  const session = await auth();
  const cookieStore = await cookies();
  const referralCode = cookieStore.get(referralConfig.cookieName)?.value ?? null;
  const productKey = String(formData.get("productKey") ?? "");
  const name = String(formData.get("name") ?? "");
  const email = String(formData.get("email") ?? "");
  const phone = String(formData.get("phone") ?? "");

  try {
    const result = await createCheckout({
      productKey,
      name,
      email,
      phone,
      userId: session?.user?.id ?? null,
      referralCode,
    });
    return { ok: true, orderId: result.orderId, paymentLinkUrl: result.paymentLinkUrl };
  } catch (err) {
    if (err instanceof CheckoutError) {
      return { ok: false, error: err.message };
    }
    console.error("[checkout] unexpected error", err);
    return { ok: false, error: "حدث خطأ غير متوقع، حاول مرة أخرى." };
  }
}
