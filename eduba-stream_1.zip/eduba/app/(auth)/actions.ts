"use server";

import { cookies } from "next/headers";
import { AuthError } from "next-auth";
import { isRedirectError } from "next/dist/client/components/redirect-error";
import { z } from "zod";
import { signIn, signOut } from "@/auth";
import { createUser, UserExistsError } from "@/lib/auth/users";
import { normalizePhone } from "@/lib/phone";
import { normalizeReferralCode, referralConfig } from "@/lib/referrals/config";

export interface AuthFormState {
  error?: string;
  fieldErrors?: Record<string, string>;
}

function safeRedirect(target: string | null | undefined, fallback = "/account"): string {
  if (!target || !target.startsWith("/") || target.startsWith("//")) return fallback;
  return target;
}

export async function signInAction(_prev: AuthFormState | null, formData: FormData): Promise<AuthFormState> {
  const identifier = String(formData.get("identifier") ?? "").trim();
  const password = String(formData.get("password") ?? "");
  const redirectTo = safeRedirect(String(formData.get("callbackUrl") ?? ""));
  if (!identifier || !password) return { error: "يرجى إدخال اسم المستخدم/البريد وكلمة المرور" };

  try {
    await signIn("credentials", { identifier, password, redirectTo });
    return {};
  } catch (err) {
    if (isRedirectError(err)) throw err; // successful sign-in redirects
    if (err instanceof AuthError) {
      return { error: "بيانات الدخول غير صحيحة" };
    }
    throw err;
  }
}

const signUpSchema = z.object({
  name: z.string().trim().min(2, "يرجى إدخال الاسم الكامل").max(80),
  email: z.string().trim().toLowerCase().email("يرجى إدخال بريد إلكتروني صحيح"),
  username: z
    .string()
    .trim()
    .toLowerCase()
    .regex(/^[a-z0-9_.]{3,30}$/, "اسم المستخدم: 3-30 حرفاً لاتينياً أو أرقاماً")
    .optional()
    .or(z.literal("")),
  phone: z.string().trim().optional().or(z.literal("")),
  password: z.string().min(8, "كلمة المرور يجب أن تكون 8 أحرف على الأقل").max(128),
  role: z.enum(["student", "parent"]),
});

export async function signUpAction(_prev: AuthFormState | null, formData: FormData): Promise<AuthFormState> {
  const parsed = signUpSchema.safeParse({
    name: formData.get("name"),
    email: formData.get("email"),
    username: formData.get("username") ?? "",
    phone: formData.get("phone") ?? "",
    password: formData.get("password"),
    role: formData.get("role") ?? "student",
  });
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      const key = String(issue.path[0] ?? "form");
      if (!fieldErrors[key]) fieldErrors[key] = issue.message;
    }
    return { error: "يرجى تصحيح الحقول المحددة", fieldErrors };
  }

  const data = parsed.data;
  let phone: string | null = null;
  if (data.phone) {
    phone = normalizePhone(data.phone);
    if (!phone) return { error: "رقم الجوال غير صحيح", fieldErrors: { phone: "مثال: 05xxxxxxxx" } };
  }

  const cookieStore = await cookies();
  const referredByCode = normalizeReferralCode(cookieStore.get(referralConfig.cookieName)?.value);
  try {
    await createUser({
      name: data.name,
      email: data.email,
      username: data.username || null,
      phone,
      password: data.password,
      role: data.role,
      referredByCode,
    });
  } catch (err) {
    if (err instanceof UserExistsError) {
      return { error: err.message, fieldErrors: { [err.field]: err.message } };
    }
    throw err;
  }

  const plan = String(formData.get("plan") ?? "");
  const redirectTo = plan === "pro" || plan === "pro_monthly" ? "/checkout?plan=pro_monthly" : "/account";
  try {
    await signIn("credentials", { identifier: data.email, password: data.password, redirectTo });
    return {};
  } catch (err) {
    if (isRedirectError(err)) throw err;
    return { error: "تم إنشاء الحساب لكن تعذّر تسجيل الدخول تلقائياً، سجّل الدخول يدوياً." };
  }
}

export async function signOutAction() {
  await signOut({ redirectTo: "/" });
}
