import { aliasedTable, desc, eq } from "drizzle-orm";
import { Mono, Table, shortId } from "@/components/admin/ui";
import { getDb, schema } from "@/lib/db";
import { formatDateTime, formatMoney } from "@/lib/format";

export const dynamic = "force-dynamic";

const STATUS: Record<string, { label: string; cls: string }> = {
  pending: { label: "بانتظار الدفع", cls: "bg-amber-100 text-amber-700" },
  rewarded: { label: "تمت المكافأة", cls: "bg-emerald-100 text-emerald-700" },
  void: { label: "غير مؤهلة", cls: "bg-gray-200 text-gray-600" },
};

export default async function AdminReferralsPage() {
  const db = getDb();
  const referrer = aliasedTable(schema.users, "referrer");
  const rows = await db
    .select({
      r: schema.referrals,
      referrer: { name: referrer.name, email: referrer.email, isInfluencer: referrer.isInfluencer },
      customer: { name: schema.customers.name, email: schema.customers.email, phone: schema.customers.phone },
      order: { amount: schema.orders.amount, status: schema.orders.status, productKey: schema.orders.productKey },
    })
    .from(schema.referrals)
    .innerJoin(referrer, eq(schema.referrals.referrerUserId, referrer.id))
    .innerJoin(schema.customers, eq(schema.referrals.referredCustomerId, schema.customers.id))
    .innerJoin(schema.orders, eq(schema.referrals.orderId, schema.orders.id))
    .orderBy(desc(schema.referrals.createdAt))
    .limit(300);

  const rewarded = rows.filter((x) => x.r.status === "rewarded");
  const total = rewarded.reduce((a, x) => a + Number(x.r.commissionAmount ?? 0), 0);

  return (
    <div className="space-y-4">
      <div className="rounded-2xl bg-white border border-border p-4 text-sm text-muted-foreground">
        {rows.length} إحالة • {rewarded.length} مكافأة بقيمة <span className="font-bold text-foreground">{formatMoney(total)}</span>. تُمنح المكافأة مرة واحدة عند أول دفعة ناجحة للعميل المُحال.
      </div>
      <Table head={["المُحيل", "العميل المُحال", "الطلب", "الحالة", "العمولة", "التاريخ"]} empty={rows.length === 0}>
        {rows.map(({ r, referrer: ref, customer, order }) => {
          const st = STATUS[r.status];
          return (
            <tr key={r.id} className="hover:bg-secondary/40 align-top">
              <td className="px-4 py-3">
                <div className="font-bold">{ref.name}</div>
                <div className="text-xs text-muted-foreground" dir="ltr">{ref.email}</div>
                <div className="text-[11px] text-muted-foreground">{ref.isInfluencer ? "مؤثر" : "عميل"} • <span className="font-mono">{r.referralCode}</span></div>
              </td>
              <td className="px-4 py-3">
                <div className="font-medium">{customer.name}</div>
                <div className="text-xs text-muted-foreground" dir="ltr">{customer.phone}</div>
              </td>
              <td className="px-4 py-3">
                <div>{formatMoney(order.amount)} <span className="text-xs text-muted-foreground">({order.productKey})</span></div>
                <Mono>{shortId(r.orderId)}</Mono>
                <div className="text-[11px] text-muted-foreground">{order.status}</div>
              </td>
              <td className="px-4 py-3">
                <span className={`inline-block px-2 py-0.5 rounded-md text-[11px] font-bold ${st.cls}`}>{st.label}</span>
                {r.voidReason && <div className="text-[11px] text-muted-foreground mt-1">{r.voidReason}</div>}
              </td>
              <td className="px-4 py-3 font-bold whitespace-nowrap">{r.commissionAmount ? formatMoney(r.commissionAmount) : "—"}</td>
              <td className="px-4 py-3 whitespace-nowrap text-muted-foreground text-xs">
                {formatDateTime(r.createdAt)}
                {r.rewardedAt && <div>مكافأة: {formatDateTime(r.rewardedAt)}</div>}
              </td>
            </tr>
          );
        })}
      </Table>
    </div>
  );
}
