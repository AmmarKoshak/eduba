"use server";

import { requireAdmin } from "@/auth";
import { cancelSettlement, createMonthlySettlements, createSettlement, currentPeriod, markSettlementPaid, setInfluencer } from "@/lib/referrals/service";

export interface AdminActionState {
  ok: boolean;
  message: string;
}

/**
 * Write actions of the admin panel. Each one is triggered from a confirmation
 * dialog in the UI and re-checks the admin allow-list on the server. They do
 * not call revalidatePath: the dialog refreshes the page itself after showing
 * the result (otherwise the row that owns the dialog could unmount first).
 */
async function guard(): Promise<{ email: string } | AdminActionState> {
  const admin = await requireAdmin();
  if (!admin?.email) return { ok: false, message: "غير مصرّح" };
  return { email: admin.email };
}

export async function runMonthlySettlements(_prev: AdminActionState | null, formData: FormData): Promise<AdminActionState> {
  const g = await guard();
  if ("ok" in g) return g;
  const period = String(formData.get("period") ?? currentPeriod()).trim();
  if (!/^\d{4}-\d{2}$/.test(period)) return { ok: false, message: "صيغة الشهر غير صحيحة (YYYY-MM)" };
  try {
    const { created, skipped } = await createMonthlySettlements({ period, createdByEmail: g.email });
    return { ok: true, message: `تم إنشاء ${created} تسوية لشهر ${period}${skipped ? ` (تم تخطي ${skipped} محفظة لديها تسوية مفتوحة)` : ""}.` };
  } catch (err) {
    return { ok: false, message: err instanceof Error ? err.message : "فشل إنشاء التسويات" };
  }
}

export async function settleWallet(_prev: AdminActionState | null, formData: FormData): Promise<AdminActionState> {
  const g = await guard();
  if ("ok" in g) return g;
  const walletId = String(formData.get("walletId") ?? "");
  const amountRaw = String(formData.get("amount") ?? "").trim();
  const period = String(formData.get("period") ?? currentPeriod()).trim();
  const amount = amountRaw ? Number(amountRaw) : undefined;
  if (amountRaw && (!Number.isFinite(amount) || (amount ?? 0) <= 0)) return { ok: false, message: "المبلغ غير صحيح" };
  try {
    const s = await createSettlement({ walletId, period, amount, createdByEmail: g.email, note: String(formData.get("note") ?? "") || undefined });
    return { ok: true, message: s ? `تم إنشاء تسوية بقيمة ${s.amount} ريال (قيد التحويل).` : "لم يتم إنشاء تسوية" };
  } catch (err) {
    return { ok: false, message: err instanceof Error ? err.message : "فشل إنشاء التسوية" };
  }
}

export async function markPaid(_prev: AdminActionState | null, formData: FormData): Promise<AdminActionState> {
  const g = await guard();
  if ("ok" in g) return g;
  const settlementId = String(formData.get("settlementId") ?? "");
  const reference = String(formData.get("reference") ?? "").trim();
  if (reference.length < 3) return { ok: false, message: "أدخل مرجع التحويل البنكي" };
  const s = await markSettlementPaid({ settlementId, reference, note: String(formData.get("note") ?? "") || undefined });
  return s ? { ok: true, message: "تم تسجيل التسوية كمدفوعة." } : { ok: false, message: "التسوية غير موجودة أو ليست قيد التحويل" };
}

export async function cancelPending(_prev: AdminActionState | null, formData: FormData): Promise<AdminActionState> {
  const g = await guard();
  if ("ok" in g) return g;
  const settlementId = String(formData.get("settlementId") ?? "");
  const s = await cancelSettlement({ settlementId, note: String(formData.get("note") ?? "") || undefined });
  return s ? { ok: true, message: "تم إلغاء التسوية وإعادة المبلغ إلى المحفظة." } : { ok: false, message: "التسوية غير موجودة أو ليست قيد التحويل" };
}

export async function updateInfluencer(_prev: AdminActionState | null, formData: FormData): Promise<AdminActionState> {
  const g = await guard();
  if ("ok" in g) return g;
  const userId = String(formData.get("userId") ?? "");
  const enable = String(formData.get("enable") ?? "") === "1";
  const rateRaw = String(formData.get("rate") ?? "").trim();
  const rate = rateRaw ? Number(rateRaw) : null;
  if (enable && rate !== null && (!Number.isFinite(rate) || rate < 0 || rate > 100)) return { ok: false, message: "النسبة يجب أن تكون بين 0 و 100" };
  const u = await setInfluencer({ userId, isInfluencer: enable, ratePercent: rate });
  return u ? { ok: true, message: enable ? `تم تعيين ${u.email} كمؤثر${rate !== null ? ` بنسبة ${rate}%` : ""}.` : `تمت إزالة صفة المؤثر عن ${u.email}.` } : { ok: false, message: "المستخدم غير موجود" };
}
