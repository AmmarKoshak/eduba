import { desc, eq, sql } from "drizzle-orm";
import { ConfirmActionDialog } from "@/components/admin/ConfirmActionDialog";
import { Mono, StatCard, Table, shortId } from "@/components/admin/ui";
import { getDb, schema } from "@/lib/db";
import { formatDateTime, formatMoney } from "@/lib/format";
import { referralConfig } from "@/lib/referrals/config";
import { currentPeriod } from "@/lib/referrals/service";
import { runMonthlySettlements, settleWallet, updateInfluencer } from "./actions";

export const dynamic = "force-dynamic";

export default async function AdminWalletsPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q = "" } = await searchParams;
  const db = getDb();
  const period = currentPeriod();

  const rows = await db
    .select({
      wallet: schema.wallets,
      user: { id: schema.users.id, name: schema.users.name, email: schema.users.email, isInfluencer: schema.users.isInfluencer, rate: schema.users.commissionRatePercent, code: schema.users.referralCode },
      referrals: sql<number>`(select count(*) from referrals r where r.referrer_user_id = ${schema.users.id} and r.status = 'rewarded')`.mapWith(Number),
      pending: sql<string>`coalesce((select sum(s.amount) from settlements s where s.wallet_id = ${schema.wallets.id} and s.status = 'pending'), 0)`,
    })
    .from(schema.wallets)
    .innerJoin(schema.users, eq(schema.wallets.userId, schema.users.id))
    .where(q ? sql`(${schema.users.email} ilike ${"%" + q + "%"} or ${schema.users.name} ilike ${"%" + q + "%"})` : undefined)
    .orderBy(desc(schema.wallets.balance))
    .limit(200);

  const totals = rows.reduce(
    (acc, r) => {
      acc.balance += Number(r.wallet.balance);
      acc.lifetime += Number(r.wallet.lifetimeEarned);
      acc.pending += Number(r.pending);
      if (r.user.isInfluencer) acc.influencers += 1;
      return acc;
    },
    { balance: 0, lifetime: 0, pending: 0, influencers: 0 },
  );
  const eligible = rows.filter((r) => Number(r.wallet.balance) >= referralConfig.settlementMinSar).length;

  // Users without a wallet yet can still be made influencers.
  const candidates = q
    ? await db
        .select({ id: schema.users.id, name: schema.users.name, email: schema.users.email, isInfluencer: schema.users.isInfluencer })
        .from(schema.users)
        .where(sql`(${schema.users.email} ilike ${"%" + q + "%"} or ${schema.users.name} ilike ${"%" + q + "%"}) and ${schema.users.id} not in (select user_id from wallets)`)
        .limit(20)
    : [];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="أرصدة مستحقة" value={formatMoney(totals.balance)} tone="text-emerald-600" hint="مجموع أرصدة المحافظ" />
        <StatCard label="قيد التحويل" value={formatMoney(totals.pending)} tone="text-amber-600" hint="تسويات لم تُدفع بعد" />
        <StatCard label="إجمالي العمولات" value={formatMoney(totals.lifetime)} hint="منذ البداية" />
        <StatCard label="المؤثرون" value={String(totals.influencers)} tone="text-primary" hint={`النسبة الافتراضية ${referralConfig.influencerRatePercent}% • مكافأة الطالب ${formatMoney(referralConfig.payerRewardSar)}`} />
      </div>

      <div className="rounded-2xl bg-white border border-border p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <form method="get" action="/admin/wallets" className="flex gap-2">
          <input type="search" name="q" defaultValue={q} placeholder="بحث بالاسم أو البريد" className="rounded-lg border border-input px-3 py-2 text-sm" />
          <button type="submit" className="px-4 py-2 rounded-lg bg-primary text-white text-sm font-bold">بحث</button>
        </form>
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span>{eligible} محفظة مؤهلة للتسوية (≥ {formatMoney(referralConfig.settlementMinSar)})</span>
          <ConfirmActionDialog
            action={runMonthlySettlements}
            trigger={`إنشاء تسويات شهر ${period}`}
            title="إنشاء التسويات الشهرية"
            description={`سيتم إنشاء تسوية "قيد التحويل" لكل محفظة رصيدها ${formatMoney(referralConfig.settlementMinSar)} أو أكثر، وخصم المبلغ من رصيدها. بعد تنفيذ التحويلات البنكية سجّل كل تسوية كمدفوعة من صفحة التسويات.`}
            confirmLabel="إنشاء التسويات"
            fields={[{ name: "period", label: "الشهر", type: "month", defaultValue: period, required: true }]}
          />
        </div>
      </div>

      <Table head={["المستخدم", "النوع", "الرصيد", "قيد التحويل", "إجمالي الأرباح", "إحالات ناجحة", "آخر تحديث", ""]} empty={rows.length === 0}>
        {rows.map((r) => (
          <tr key={r.wallet.id} className="hover:bg-secondary/40 align-top">
            <td className="px-4 py-3">
              <div className="font-bold">{r.user.name}</div>
              <div className="text-xs text-muted-foreground" dir="ltr">{r.user.email}</div>
              {r.user.code && <Mono>/r/{r.user.code}</Mono>}
            </td>
            <td className="px-4 py-3 whitespace-nowrap">
              {r.user.isInfluencer ? (
                <span className="inline-block px-2 py-0.5 rounded-md text-[11px] font-bold bg-violet-100 text-violet-700">
                  مؤثر {r.user.rate ? `${Number(r.user.rate)}%` : `${referralConfig.influencerRatePercent}%`}
                </span>
              ) : (
                <span className="inline-block px-2 py-0.5 rounded-md text-[11px] font-bold bg-sky-100 text-sky-700">عميل</span>
              )}
            </td>
            <td className="px-4 py-3 font-black whitespace-nowrap text-emerald-600">{formatMoney(r.wallet.balance)}</td>
            <td className="px-4 py-3 whitespace-nowrap">{formatMoney(r.pending)}</td>
            <td className="px-4 py-3 whitespace-nowrap">{formatMoney(r.wallet.lifetimeEarned)}</td>
            <td className="px-4 py-3">{r.referrals}</td>
            <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">{formatDateTime(r.wallet.updatedAt)}</td>
            <td className="px-4 py-3">
              <div className="flex flex-wrap gap-2 justify-end">
                {(
                  <ConfirmActionDialog
                    action={settleWallet}
                    trigger="تسوية"
                    disabled={Number(r.wallet.balance) <= 0}
                    title={`تسوية محفظة ${r.user.name}`}
                    description="سيُخصم المبلغ من المحفظة وتُنشأ تسوية قيد التحويل. نفّذ التحويل البنكي ثم سجّلها كمدفوعة."
                    confirmLabel="إنشاء التسوية"
                    hidden={{ walletId: r.wallet.id }}
                    fields={[
                      { name: "amount", label: "المبلغ (ريال)", type: "number", defaultValue: Number(r.wallet.balance).toFixed(2), step: "0.01", min: "0.01", required: true },
                      { name: "period", label: "الشهر", type: "month", defaultValue: period, required: true },
                      { name: "note", label: "ملاحظة (اختياري)" },
                    ]}
                  />
                )}
                {r.user.isInfluencer ? (
                  <ConfirmActionDialog
                    action={updateInfluencer}
                    trigger="إزالة صفة المؤثر"
                    tone="danger"
                    title="إزالة صفة المؤثر"
                    description={`سيعود ${r.user.name} إلى مكافأة العميل العادية (${formatMoney(referralConfig.payerRewardSar)} لكل إحالة). الرصيد الحالي لا يتأثر.`}
                    confirmLabel="تأكيد الإزالة"
                    hidden={{ userId: r.user.id, enable: "0" }}
                  />
                ) : (
                  <ConfirmActionDialog
                    action={updateInfluencer}
                    trigger="تعيين كمؤثر"
                    title={`تعيين ${r.user.name} كمؤثر`}
                    description="سيكسب نسبة من أول دفعة لكل مشترك يأتي عبر رابطه بدلاً من المكافأة الثابتة."
                    confirmLabel="تعيين"
                    hidden={{ userId: r.user.id, enable: "1" }}
                    fields={[{ name: "rate", label: "نسبة العمولة %", type: "number", defaultValue: String(referralConfig.influencerRatePercent), step: "0.5", min: "0", max: "100", required: true }]}
                  />
                )}
              </div>
            </td>
          </tr>
        ))}
      </Table>

      {candidates.length > 0 && (
        <div>
          <h2 className="text-sm font-bold text-muted-foreground mb-2">مستخدمون بدون محفظة بعد</h2>
          <Table head={["المستخدم", "البريد", "المعرّف", ""]} empty={false}>
            {candidates.map((u) => (
              <tr key={u.id}>
                <td className="px-4 py-3 font-bold">{u.name}</td>
                <td className="px-4 py-3" dir="ltr">{u.email}</td>
                <td className="px-4 py-3"><Mono>{shortId(u.id)}</Mono></td>
                <td className="px-4 py-3 text-end">
                  <ConfirmActionDialog
                    action={updateInfluencer}
                    trigger="تعيين كمؤثر"
                    title={`تعيين ${u.name} كمؤثر`}
                    description="سيتم إنشاء محفظة له وسيكسب نسبة من أول دفعة لكل مشترك يأتي عبر رابطه."
                    confirmLabel="تعيين"
                    hidden={{ userId: u.id, enable: "1" }}
                    fields={[{ name: "rate", label: "نسبة العمولة %", type: "number", defaultValue: String(referralConfig.influencerRatePercent), step: "0.5", min: "0", max: "100", required: true }]}
                  />
                </td>
              </tr>
            ))}
          </Table>
        </div>
      )}
    </div>
  );
}
