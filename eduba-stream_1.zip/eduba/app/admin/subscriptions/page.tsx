import Link from "next/link";
import { Filters } from "@/components/admin/Filters";
import { DashboardLink, ErrorNotice, Mono, Pagination, StatusBadge, Table, shortId } from "@/components/admin/ui";
import { formatDate, formatDateTime, formatMoney } from "@/lib/format";
import { adminListSubscriptions, dashboardUrl, parseFilters } from "@/lib/stream/admin";

const SUB_STATUSES = ["ACTIVE", "TRIALING", "TRIAL_PENDING", "INACTIVE", "FROZEN", "CANCELED", "EXPIRED"] as const;

const INTERVAL_AR: Record<string, string> = { WEEK: "أسبوعي", MONTH: "شهري", QUARTER: "ربع سنوي", SEMESTER: "نصف سنوي", YEAR: "سنوي" };

export default async function AdminSubscriptionsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const filters = parseFilters(await searchParams);
  let data: Awaited<ReturnType<typeof adminListSubscriptions>> | null = null;
  let error: string | null = null;
  try {
    data = await adminListSubscriptions(filters);
  } catch (err) {
    error = err instanceof Error ? err.message : String(err);
  }

  return (
    <div>
      <Filters basePath="/admin/subscriptions" filters={filters} statuses={SUB_STATUSES} searchPlaceholder="بحث باسم الخطة" />
      {error ? (
        <ErrorNotice message={error} />
      ) : (
        <>
          <Table head={["الاشتراك", "العميل", "الخطة", "المبلغ", "الحالة", "الفوترة القادمة", "بدأ في", ""]} empty={(data?.data?.length ?? 0) === 0}>
            {(data?.data ?? []).map((s) => {
              const plan = (s.items ?? []).map((i) => i.product?.name).filter(Boolean).join(" + ") || s.description || "—";
              const interval = s.recurring_interval ? INTERVAL_AR[s.recurring_interval] ?? s.recurring_interval : "";
              return (
                <tr key={s.id} className="hover:bg-secondary/40 align-top">
                  <td className="px-4 py-3">
                    <Mono>{shortId(s.id)}</Mono>
                  </td>
                  <td className="px-4 py-3">
                    <div className="font-medium">{s.organization_consumer?.name ?? "—"}</div>
                    <div className="text-xs text-muted-foreground" dir="ltr">
                      {s.organization_consumer?.phone_number ?? s.organization_consumer?.email ?? ""}
                    </div>
                    {s.organization_consumer_id && (
                      <Link href={`/admin/subscriptions?consumer=${s.organization_consumer_id}`} className="text-[11px] font-bold text-primary hover:underline">
                        اشتراكات هذا العميل
                      </Link>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <div className="font-medium">{plan}</div>
                    <div className="text-xs text-muted-foreground">
                      {interval}
                      {s.recurring_interval_count && s.recurring_interval_count > 1 ? ` ×${s.recurring_interval_count}` : ""}
                    </div>
                  </td>
                  <td className="px-4 py-3 font-bold whitespace-nowrap">{formatMoney(s.amount, s.currency ?? "SAR")}</td>
                  <td className="px-4 py-3">
                    <StatusBadge status={s.status} />
                    {s.cancel_at_period_end && <div className="text-[11px] text-amber-700 mt-1">يُلغى نهاية الفترة</div>}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">{formatDate(s.current_period_end)}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">{formatDateTime(s.started_at ?? s.created_at)}</td>
                  <td className="px-4 py-3 text-end">
                    <DashboardLink href={dashboardUrl.subscription(s.id)} />
                  </td>
                </tr>
              );
            })}
          </Table>
          <Pagination
            pagination={data?.pagination}
            basePath="/admin/subscriptions"
            params={{ q: filters.q, from: filters.from, to: filters.to, status: filters.status, limit: filters.limit, consumer: filters.consumerId }}
          />
        </>
      )}
    </div>
  );
}
