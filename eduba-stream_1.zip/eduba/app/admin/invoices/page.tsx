import Link from "next/link";
import { Filters } from "@/components/admin/Filters";
import { DashboardLink, ErrorNotice, Mono, Pagination, StatusBadge, Table, shortId } from "@/components/admin/ui";
import { formatDateTime, formatMoney } from "@/lib/format";
import { adminListInvoices, dashboardUrl, parseFilters } from "@/lib/stream/admin";

const INVOICE_STATUSES = ["COMPLETED", "ACCEPTED", "SENT", "CREATED", "REJECTED", "CANCELED", "EXPIRED", "DRAFT"] as const;

export default async function AdminInvoicesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const filters = parseFilters(await searchParams);
  let data: Awaited<ReturnType<typeof adminListInvoices>> | null = null;
  let error: string | null = null;
  try {
    data = await adminListInvoices(filters);
  } catch (err) {
    error = err instanceof Error ? err.message : String(err);
  }

  return (
    <div>
      <Filters basePath="/admin/invoices" filters={filters} statuses={INVOICE_STATUSES} />
      {error ? (
        <ErrorNotice message={error} />
      ) : (
        <>
          <Table
            head={["الفاتورة", "العميل", "المبلغ", "المدفوع", "الحالة", "عمليات الدفع", "التاريخ", ""]}
            empty={(data?.data?.length ?? 0) === 0}
          >
            {(data?.data ?? []).map((inv) => (
              <tr key={inv.id} className="hover:bg-secondary/40 align-top">
                <td className="px-4 py-3">
                  <div className="font-bold">#{inv.org_invoice_number ?? inv.invoice_number ?? shortId(inv.id)}</div>
                  <Mono>{shortId(inv.id)}</Mono>
                  {inv.type && <div className="text-[11px] text-muted-foreground mt-0.5">{inv.type}</div>}
                </td>
                <td className="px-4 py-3">
                  <div className="font-medium">{inv.organization_consumer?.name ?? "—"}</div>
                  <div className="text-xs text-muted-foreground" dir="ltr">
                    {inv.organization_consumer?.phone_number ?? ""}
                  </div>
                  <div className="text-xs text-muted-foreground" dir="ltr">
                    {inv.organization_consumer?.email ?? ""}
                  </div>
                  {inv.organization_consumer_id && (
                    <Link href={`/admin/invoices?consumer=${inv.organization_consumer_id}`} className="text-[11px] font-bold text-primary hover:underline">
                      فواتير هذا العميل
                    </Link>
                  )}
                </td>
                <td className="px-4 py-3 font-bold whitespace-nowrap">{formatMoney(inv.total_amount, inv.currency)}</td>
                <td className="px-4 py-3 whitespace-nowrap">{formatMoney(inv.paid_amount, inv.currency)}</td>
                <td className="px-4 py-3">
                  <StatusBadge status={inv.status} />
                </td>
                <td className="px-4 py-3">
                  {(inv.payments ?? []).length === 0 ? (
                    <span className="text-muted-foreground">—</span>
                  ) : (
                    <ul className="space-y-1">
                      {(inv.payments ?? []).map((p) => (
                        <li key={p.id} className="flex items-center gap-2 text-xs whitespace-nowrap">
                          <StatusBadge status={p.current_status} />
                          <span>{formatMoney(p.amount, p.currency ?? inv.currency)}</span>
                          <span className="text-muted-foreground">{p.payment_method ?? ""}</span>
                          {p.type === "INSTALLMENT" && <span className="text-muted-foreground">قسط {p.invoice_payment_number ?? ""}</span>}
                        </li>
                      ))}
                    </ul>
                  )}
                </td>
                <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">{formatDateTime(inv.created_at)}</td>
                <td className="px-4 py-3 text-end">
                  <DashboardLink href={dashboardUrl.invoice(inv.id)} />
                </td>
              </tr>
            ))}
          </Table>
          <Pagination
            pagination={data?.pagination}
            basePath="/admin/invoices"
            params={{ q: filters.q, from: filters.from, to: filters.to, status: filters.status, limit: filters.limit, consumer: filters.consumerId }}
          />
        </>
      )}
    </div>
  );
}
