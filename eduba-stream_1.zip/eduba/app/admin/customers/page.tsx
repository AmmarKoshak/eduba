import Link from "next/link";
import { Filters } from "@/components/admin/Filters";
import { DashboardLink, ErrorNotice, Mono, Pagination, Table, shortId } from "@/components/admin/ui";
import { formatDateTime } from "@/lib/format";
import { adminListConsumers, dashboardUrl, parseFilters } from "@/lib/stream/admin";

export default async function AdminCustomersPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const filters = parseFilters(await searchParams);
  let data: Awaited<ReturnType<typeof adminListConsumers>> | null = null;
  let error: string | null = null;
  try {
    data = await adminListConsumers(filters);
  } catch (err) {
    error = err instanceof Error ? err.message : String(err);
  }

  return (
    <div>
      <Filters basePath="/admin/customers" filters={filters} showDates={false} />
      {error ? (
        <ErrorNotice message={error} />
      ) : (
        <>
          <Table head={["الاسم", "الجوال", "البريد الإلكتروني", "المعرّف", "أُنشئ في", "", ""]} empty={(data?.data?.length ?? 0) === 0}>
            {(data?.data ?? []).map((c) => (
              <tr key={c.id} className="hover:bg-secondary/40">
                <td className="px-4 py-3 font-medium">{c.name ?? "—"}</td>
                <td className="px-4 py-3 whitespace-nowrap" dir="ltr">
                  {c.phone_number ?? "—"}
                </td>
                <td className="px-4 py-3" dir="ltr">
                  {c.email ?? "—"}
                </td>
                <td className="px-4 py-3">
                  <Mono>{shortId(c.id)}</Mono>
                </td>
                <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">{formatDateTime(c.created_at)}</td>
                <td className="px-4 py-3 whitespace-nowrap text-xs">
                  <Link href={`/admin/invoices?consumer=${c.id}`} className="font-bold text-primary hover:underline">
                    الفواتير
                  </Link>
                  <span className="mx-1 text-muted-foreground">•</span>
                  <Link href={`/admin/subscriptions?consumer=${c.id}`} className="font-bold text-primary hover:underline">
                    الاشتراكات
                  </Link>
                </td>
                <td className="px-4 py-3 text-end">
                  <DashboardLink href={dashboardUrl.consumer(c.id)} />
                </td>
              </tr>
            ))}
          </Table>
          <Pagination pagination={data?.pagination} basePath="/admin/customers" params={{ q: filters.q, limit: filters.limit }} />
        </>
      )}
    </div>
  );
}
