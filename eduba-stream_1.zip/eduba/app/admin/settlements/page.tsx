import { desc, eq } from "drizzle-orm";
import { ConfirmActionDialog } from "@/components/admin/ConfirmActionDialog";
import { Mono, Table, shortId } from "@/components/admin/ui";
import { getDb, schema } from "@/lib/db";
import { formatDateTime, formatMoney } from "@/lib/format";
import { cancelPending, markPaid } from "@/app/admin/wallets/actions";

export const dynamic = "force-dynamic";

const STATUS: Record<string, { label: string; cls: string }> = {
  pending: { label: "قيد التحويل", cls: "bg-amber-100 text-amber-700" },
  paid: { label: "مدفوعة", cls: "bg-emerald-100 text-emerald-700" },
  canceled: { label: "ملغاة", cls: "bg-gray-200 text-gray-600" },
};

export default async function AdminSettlementsPage({ searchParams }: { searchParams: Promise<{ status?: string }> }) {
  const { status = "" } = await searchParams;
  const db = getDb();
  const rows = await db
    .select({ s: schema.settlements, user: { name: schema.users.name, email: schema.users.email, isInfluencer: schema.users.isInfluencer } })
    .from(schema.settlements)
    .innerJoin(schema.wallets, eq(schema.settlements.walletId, schema.wallets.id))
    .innerJoin(schema.users, eq(schema.wallets.userId, schema.users.id))
    .where(status === "pending" || status === "paid" || status === "canceled" ? eq(schema.settlements.status, status) : undefined)
    .orderBy(desc(schema.settlements.createdAt))
    .limit(300);

  const pendingTotal = rows.filter((r) => r.s.status === "pending").reduce((a, r) => a + Number(r.s.amount), 0);

  return (
    <div className="space-y-4">
      <div className="rounded-2xl bg-white border border-border p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <form method="get" action="/admin/settlements" className="flex items-center gap-2 text-sm">
          <select name="status" defaultValue={status} className="rounded-lg border border-input px-3 py-2 text-sm">
            <option value="">كل الحالات</option>
            <option value="pending">قيد التحويل</option>
            <option value="paid">مدفوعة</option>
            <option value="canceled">ملغاة</option>
          </select>
          <button type="submit" className="px-4 py-2 rounded-lg bg-primary text-white text-sm font-bold">تطبيق</button>
        </form>
        <div className="text-xs text-muted-foreground">
          قيد التحويل في هذه القائمة: <span className="font-bold text-amber-700">{formatMoney(pendingTotal)}</span> — نفّذ التحويل البنكي ثم سجّل المرجع هنا.
        </div>
      </div>

      <Table head={["التسوية", "المستفيد", "الشهر", "المبلغ", "الحالة", "المرجع", "أُنشئت", ""]} empty={rows.length === 0}>
        {rows.map(({ s, user }) => {
          const st = STATUS[s.status];
          return (
            <tr key={s.id} className="hover:bg-secondary/40 align-top">
              <td className="px-4 py-3"><Mono>{shortId(s.id)}</Mono></td>
              <td className="px-4 py-3">
                <div className="font-bold">{user.name}</div>
                <div className="text-xs text-muted-foreground" dir="ltr">{user.email}</div>
                <div className="text-[11px] text-muted-foreground">{user.isInfluencer ? "مؤثر" : "عميل"}</div>
              </td>
              <td className="px-4 py-3 whitespace-nowrap">{s.period}</td>
              <td className="px-4 py-3 font-black whitespace-nowrap">{formatMoney(s.amount, s.currency)}</td>
              <td className="px-4 py-3"><span className={`inline-block px-2 py-0.5 rounded-md text-[11px] font-bold ${st.cls}`}>{st.label}</span></td>
              <td className="px-4 py-3 text-xs" dir="ltr">
                {s.reference ?? "—"}
                {s.paidAt && <div className="text-muted-foreground">{formatDateTime(s.paidAt)}</div>}
                {s.note && <div className="text-muted-foreground" dir="rtl">{s.note}</div>}
              </td>
              <td className="px-4 py-3 whitespace-nowrap text-muted-foreground text-xs">
                {formatDateTime(s.createdAt)}
                {s.createdByEmail && <div dir="ltr">{s.createdByEmail}</div>}
              </td>
              <td className="px-4 py-3">
                {s.status === "pending" && (
                  <div className="flex flex-wrap gap-2 justify-end">
                    <ConfirmActionDialog
                      action={markPaid}
                      trigger="تسجيل كمدفوعة"
                      title={`تأكيد دفع ${formatMoney(s.amount)} إلى ${user.name}`}
                      description="سجّل مرجع التحويل البنكي بعد تنفيذه. لا يمكن التراجع عن هذه الخطوة من هنا."
                      confirmLabel="تم التحويل"
                      hidden={{ settlementId: s.id }}
                      fields={[
                        { name: "reference", label: "مرجع التحويل", placeholder: "رقم العملية البنكية", required: true },
                        { name: "note", label: "ملاحظة (اختياري)" },
                      ]}
                    />
                    <ConfirmActionDialog
                      action={cancelPending}
                      tone="danger"
                      trigger="إلغاء"
                      title="إلغاء التسوية"
                      description={`سيُعاد مبلغ ${formatMoney(s.amount)} إلى محفظة ${user.name}.`}
                      confirmLabel="إلغاء التسوية"
                      hidden={{ settlementId: s.id }}
                      fields={[{ name: "note", label: "سبب الإلغاء (اختياري)" }]}
                    />
                  </div>
                )}
              </td>
            </tr>
          );
        })}
      </Table>
    </div>
  );
}
