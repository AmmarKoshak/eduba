import Link from "next/link";
import { DashboardLink, ErrorNotice, Mono, StatCard, StatusBadge, Table, shortId } from "@/components/admin/ui";
import { formatDate, formatDateTime, formatMoney } from "@/lib/format";
import { adminListInvoices, adminSummary, dashboardUrl } from "@/lib/stream/admin";

export default async function AdminOverviewPage() {
  let summary: Awaited<ReturnType<typeof adminSummary>> | null = null;
  let recent: Awaited<ReturnType<typeof adminListInvoices>> | null = null;
  let error: string | null = null;

  try {
    [summary, recent] = await Promise.all([adminSummary(), adminListInvoices({ page: 1, limit: 10 })]);
  } catch (err) {
    error = err instanceof Error ? err.message : String(err);
  }

  if (error) return <ErrorNotice message={error} />;

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard
          label="إيرادات هذا الشهر"
          value={formatMoney(summary?.revenueThisMonth ?? 0)}
          hint={`${summary?.paymentsThisMonth ?? 0} عملية ناجحة • ${formatDate(summary?.monthFrom)} – ${formatDate(summary?.monthTo)}`}
          tone="text-emerald-600"
        />
        <StatCard label="الاشتراكات النشطة" value={String(summary?.activeSubscriptions ?? 0)} hint="ACTIVE + TRIALING" tone="text-primary" />
        <StatCard label="المدفوعات الفاشلة هذا الشهر" value={String(summary?.failedPaymentsThisMonth ?? 0)} hint="حالة FAILED" tone="text-red-600" />
      </div>
      {summary?.partial && (
        <p className="text-xs text-amber-700 bg-amber-50 border border-amber-100 rounded-xl px-4 py-2">
          بعض الأرقام أعلاه غير مكتملة بسبب خطأ مؤقت من Stream. حدّث الصفحة.
        </p>
      )}

      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-base font-bold text-foreground">آخر الفواتير</h2>
          <Link href="/admin/invoices" className="text-sm font-bold text-primary hover:underline">
            عرض الكل
          </Link>
        </div>
        <Table head={["الفاتورة", "العميل", "المبلغ", "الحالة", "التاريخ", ""]} empty={(recent?.data?.length ?? 0) === 0}>
          {(recent?.data ?? []).map((inv) => (
            <tr key={inv.id} className="hover:bg-secondary/40">
              <td className="px-4 py-3">
                <div className="font-bold">#{inv.org_invoice_number ?? inv.invoice_number ?? shortId(inv.id)}</div>
                <Mono>{shortId(inv.id)}</Mono>
              </td>
              <td className="px-4 py-3">
                <div className="font-medium">{inv.organization_consumer?.name ?? "—"}</div>
                <div className="text-xs text-muted-foreground" dir="ltr">
                  {inv.organization_consumer?.phone_number ?? inv.organization_consumer?.email ?? ""}
                </div>
              </td>
              <td className="px-4 py-3 font-bold whitespace-nowrap">{formatMoney(inv.total_amount, inv.currency)}</td>
              <td className="px-4 py-3">
                <StatusBadge status={inv.status} />
              </td>
              <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">{formatDateTime(inv.created_at)}</td>
              <td className="px-4 py-3 text-end">
                <DashboardLink href={dashboardUrl.invoice(inv.id)} />
              </td>
            </tr>
          ))}
        </Table>
      </section>
    </div>
  );
}
