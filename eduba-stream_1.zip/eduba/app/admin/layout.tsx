import Link from "next/link";
import { ShieldAlert } from "lucide-react";
import { auth, requireAdmin } from "@/auth";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { AdminNav } from "@/components/admin/AdminNav";
import { AdminToaster } from "@/components/admin/AdminToaster";
import { Card, secondaryButtonClass } from "@/components/site/PageShell";

export const metadata = { title: "لوحة الإدارة | إيدوبا" };
export const dynamic = "force-dynamic";

/**
 * Every /admin page is wrapped here: the middleware already redirects
 * anonymous users, and this layout re-validates the allow-list on the server
 * (so revoking an admin in ADMIN_EMAILS takes effect immediately).
 */
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const admin = await requireAdmin();
  if (!admin) {
    const session = await auth();
    return (
      <>
        <Header variant="solid" />
        <main className="bg-background py-16 min-h-[60vh]">
          <div className="mx-auto w-[min(92%,560px)]">
            <Card className="p-8 text-center">
              <ShieldAlert className="w-12 h-12 text-amber-500 mx-auto mb-4" />
              <h1 className="text-2xl font-bold mb-2">غير مصرّح</h1>
              <p className="text-sm text-muted-foreground mb-6">
                {session?.user
                  ? `الحساب ${session.user.email} ليس ضمن قائمة المشرفين.`
                  : "يجب تسجيل الدخول بحساب مشرف للوصول إلى هذه الصفحة."}
              </p>
              <Link href={session?.user ? "/" : "/sign-in?callbackUrl=/admin"} className={secondaryButtonClass}>
                {session?.user ? "الصفحة الرئيسية" : "تسجيل الدخول"}
              </Link>
            </Card>
          </div>
        </main>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Header variant="solid" />
      <main className="bg-background py-8 sm:py-10 min-h-[70vh]">
        <div className="mx-auto w-[min(94%,1280px)]">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-6">
            <div>
              <div className="text-xs sm:text-sm font-bold text-primary mb-1">لوحة الإدارة</div>
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-foreground">المدفوعات والاشتراكات</h1>
            </div>
            <div className="text-xs text-muted-foreground">
              بيانات حية من Stream • للقراءة فقط • {admin.email}
            </div>
          </div>
          <AdminNav />
          {children}
        </div>
      </main>
      <AdminToaster />
      <Footer />
    </>
  );
}
