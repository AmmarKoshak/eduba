import { Filters } from "@/components/admin/Filters";
import { DashboardLink, ErrorNotice, Mono, Pagination, StatusBadge, Table, shortId } from "@/components/admin/ui";
import { formatDateTime, formatMoney } from "@/lib/format";
import { adminListPayments, dashboardUrl, parseFilters } from "@/lib/stream/admin";

const PAYMENT_STATUSES = [
  "SUCCEEDED",
  "SETTLED",
  "PENDING",
  "PROCESSING",
  "UNDER_REVIEW",
  "FAILED",
  "FAILED_INITIATION",
  "CANCELED",
  "EXPIRED",
  "REFUNDED",
  "PARTIALLY_REFUNDED",
] as const;

export default async function AdminPaymentsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const filters = parseFilters(await searchParams);
  let data: Awaited<ReturnType<typeof adminListPayments>> | null = null;
  let error: string | null = null;
  try {
    data = await adminListPayments(filters);
  } catch (err) {
    error = err instanceof Error ? err.message : String(err);
  }

  return (
    <div>
      <p className="text-xs text-muted-foreground mb-3">
        قائمة Stream للمدفوعات لا تتضمن اسم العميل؛ لعرض العميل مع كل دفعة استخدم تبويب «الفواتير والمدفوعات».
      </p>
      <Filters basePath="/admin/payments" filters={filters} statuses={PAYMENT_STATUSES} searchPlaceholder="بحث" />
      {error ? (
        <ErrorNotice message={error} />
      ) : (
        <>
          <Table head={["الدفعة", "المبلغ", "الوسيلة", "النوع", "الحالة", "تاريخ الدفع", "رسالة البوابة", ""]} empty={(data?.data?.length ?? 0) === 0}>
            {(data?.data ?? []).map((p) => (
              <tr key={p.id} className="hover:bg-secondary/40">
                <td className="px-4 py-3">
                  <Mono>{shortId(p.id)}</Mono>
                </td>
                <td className="px-4 py-3 font-bold whitespace-nowrap">
                  {formatMoney(p.amount, p.currency)}
                  {p.amount_refunded && Number(p.amount_refunded) > 0 && (
                    <div className="text-[11px] text-violet-700 font-medium">مسترجع {formatMoney(p.amount_refunded, p.currency)}</div>
                  )}
                </td>
                <td className="px-4 py-3 whitespace-nowrap">{p.payment_method ?? "—"}</td>
                <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">{p.type ?? "—"}</td>
                <td className="px-4 py-3">
                  <StatusBadge status={p.current_status} />
                </td>
                <td className="px-4 py-3 whitespace-nowrap text-muted-foreground">{formatDateTime(p.payed_at ?? p.scheduled_on)}</td>
                <td className="px-4 py-3 text-xs text-muted-foreground max-w-[220px] truncate" title={p.latest_pgw_message ?? ""}>
                  {p.latest_pgw_message ?? "—"}
                </td>
                <td className="px-4 py-3 text-end">
                  <DashboardLink href={dashboardUrl.payment(p.id)} />
                </td>
              </tr>
            ))}
          </Table>
          <Pagination
            pagination={data?.pagination}
            basePath="/admin/payments"
            params={{ q: filters.q, from: filters.from, to: filters.to, status: filters.status, limit: filters.limit }}
          />
        </>
      )}
    </div>
  );
}
