import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { AuthShell } from "@/components/auth/AuthShell";
import { SignInForm } from "@/components/auth/SignInForm";

export const metadata = { title: "تسجيل الدخول | إيدوبا" };

export default async function SignInPage({ searchParams }: { searchParams: Promise<{ callbackUrl?: string }> }) {
  const { callbackUrl } = await searchParams;
  const session = await auth();
  if (session?.user) redirect(callbackUrl && callbackUrl.startsWith("/") ? callbackUrl : "/account");

  return (
    <AuthShell title="تسجيل الدخول" subtitle="أدخل اسم المستخدم أو بريدك الإلكتروني وكلمة المرور">
      <SignInForm callbackUrl={callbackUrl} />
    </AuthShell>
  );
}
