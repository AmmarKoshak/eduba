"use server";

import { redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { auth } from "@/auth";
import { getDb, schema } from "@/lib/db";
import { stream } from "@/lib/stream/client";

/**
 * Opens Stream's hosted Customer Portal for the signed-in user's own customer
 * record (server-side session creation; the API key never reaches the browser).
 */
export async function openCustomerPortal(formData: FormData) {
  const session = await auth();
  if (!session?.user?.id) redirect("/sign-in?callbackUrl=/account");

  const customerId = String(formData.get("customerId") ?? "");
  const subscriptionId = String(formData.get("subscriptionId") ?? "");
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.customers)
    .where(and(eq(schema.customers.id, customerId), eq(schema.customers.userId, session.user.id)))
    .limit(1);
  const customer = rows[0];
  if (!customer) redirect("/account?error=portal");

  let url: string | undefined;
  try {
    const portal = await stream().createPortalSession({
      organization_consumer_id: customer.streamConsumerId,
      ...(subscriptionId ? { subscription_id: subscriptionId } : {}),
    });
    url = portal.url;
  } catch (err) {
    console.error("[account] portal session failed", err);
  }
  if (!url) redirect("/account?error=portal");
  redirect(url);
}
