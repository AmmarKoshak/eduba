import Link from "next/link";
import { redirect } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { CreditCard, Gift, LogOut, Sparkles } from "lucide-react";
import { auth } from "@/auth";
import { signOutAction } from "@/app/(auth)/actions";
import { openCustomerPortal } from "./actions";
import { Card, PageShell, SectionLabel, primaryButtonClass, secondaryButtonClass } from "@/components/site/PageShell";
import { getDb, schema } from "@/lib/db";
import { formatDate, formatMoney } from "@/lib/format";
import { getProduct } from "@/lib/products";
import { ACTIVE_SUBSCRIPTION_STATUSES } from "@/lib/checkout/verify";

export const metadata = { title: "حسابي | إيدوبا" };
export const dynamic = "force-dynamic";

const STATUS_AR: Record<string, string> = {
  ACTIVE: "نشط",
  TRIALING: "فترة تجريبية",
  TRIAL_PENDING: "بانتظار بدء التجربة",
  INACTIVE: "غير نشط",
  FROZEN: "مجمّد",
  CANCELED: "ملغي",
  EXPIRED: "منتهي",
};

export default async function AccountPage() {
  const session = await auth();
  if (!session?.user?.id) redirect("/sign-in?callbackUrl=/account");
  const db = getDb();

  const customers = await db
    .select()
    .from(schema.customers)
    .where(eq(schema.customers.userId, session.user.id))
    .orderBy(desc(schema.customers.createdAt));

  const customerIds = customers.map((c) => c.id);
  const subs =
    customerIds.length === 0
      ? []
      : (
          await db
            .select()
            .from(schema.subscriptions)
            .orderBy(desc(schema.subscriptions.updatedAt))
        ).filter((s) => customerIds.includes(s.customerId));
  const orders =
    customerIds.length === 0
      ? []
      : (await db.select().from(schema.orders).orderBy(desc(schema.orders.createdAt))).filter((o) =>
          customerIds.includes(o.customerId),
        );

  const activeSub = subs.find((s) => ACTIVE_SUBSCRIPTION_STATUSES.has(s.status));
  const primaryCustomer = customers[0];

  return (
    <PageShell width="min(92%,900px)">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <SectionLabel>حسابي</SectionLabel>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-foreground">مرحباً {session.user.name} 👋</h1>
          <p className="text-sm text-muted-foreground mt-1">{session.user.email}</p>
        </div>
        <form action={signOutAction}>
          <button type="submit" className="inline-flex items-center gap-2 text-sm font-bold text-muted-foreground hover:text-foreground transition">
            <LogOut className="w-4 h-4" />
            تسجيل الخروج
          </button>
        </form>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6 items-start">
        <Card className="p-6 sm:p-8">
          <div className="flex items-center gap-3 mb-5">
            <span className="inline-flex w-10 h-10 rounded-xl bg-primary/10 text-primary items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </span>
            <h2 className="text-lg font-bold text-foreground">الاشتراك</h2>
          </div>

          {activeSub ? (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center gap-3">
                <span className="text-xl font-bold text-foreground">
                  {getProduct(activeSub.productKey ?? "")?.name ?? "إيدوبا Pro"}
                </span>
                <span className="inline-block px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-xs font-bold">
                  {STATUS_AR[activeSub.status] ?? activeSub.status}
                </span>
              </div>
              <dl className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <dt className="text-muted-foreground">المبلغ</dt>
                  <dd className="font-bold">{formatMoney(activeSub.amount, activeSub.currency ?? "SAR")} / شهر</dd>
                </div>
                <div>
                  <dt className="text-muted-foreground">{activeSub.cancelAtPeriodEnd ? "ينتهي في" : "التجديد القادم"}</dt>
                  <dd className="font-bold">{formatDate(activeSub.currentPeriodEnd)}</dd>
                </div>
              </dl>
              <form action={openCustomerPortal}>
                <input type="hidden" name="customerId" value={activeSub.customerId} />
                <input type="hidden" name="subscriptionId" value={activeSub.streamSubscriptionId} />
                <button type="submit" className={secondaryButtonClass}>
                  <CreditCard className="w-4 h-4" />
                  إدارة الاشتراك والفواتير
                </button>
              </form>
              <p className="text-xs text-muted-foreground">
                تُفتح بوابة Stream الآمنة حيث يمكنك تحديث البطاقة، عرض الفواتير أو إلغاء الاشتراك.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                أنت على الخطة الأساسية المجانية. اشترك في Pro للحصول على رسائل واختبارات وتحديات غير محدودة.
              </p>
              <Link href="/checkout?plan=pro_monthly" className={primaryButtonClass}>
                الترقية إلى Pro — {formatMoney(getProduct("pro_monthly")!.amount)} / شهر
              </Link>
              {primaryCustomer && (
                <form action={openCustomerPortal}>
                  <input type="hidden" name="customerId" value={primaryCustomer.id} />
                  <button type="submit" className="text-sm font-bold text-primary hover:underline">
                    عرض فواتيري السابقة
                  </button>
                </form>
              )}
            </div>
          )}
        </Card>

        <div className="space-y-6">
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-2">
            <Gift className="w-5 h-5 text-primary" />
            <h2 className="text-base font-bold text-foreground">ادعُ أصدقاءك واكسب</h2>
          </div>
          <p className="text-sm text-muted-foreground mb-4">رابط إحالة خاص بك، ورصيدك يظهر في محفظتك.</p>
          <Link href="/account/wallet" className={secondaryButtonClass}>
            محفظتي والإحالات
          </Link>
        </Card>
        <Card className="p-6">
          <h2 className="text-base font-bold text-foreground mb-4">آخر الطلبات</h2>
          {orders.length === 0 ? (
            <p className="text-sm text-muted-foreground">لا توجد طلبات بعد.</p>
          ) : (
            <ul className="space-y-3">
              {orders.slice(0, 6).map((o) => (
                <li key={o.id} className="flex items-center justify-between gap-3 text-sm">
                  <div>
                    <div className="font-bold text-foreground">{getProduct(o.productKey)?.name ?? o.productKey}</div>
                    <div className="text-xs text-muted-foreground">{formatDate(o.createdAt)}</div>
                  </div>
                  <div className="text-end">
                    <div className="font-bold">{formatMoney(o.amount, o.currency)}</div>
                    <div
                      className={`text-[11px] font-bold ${
                        o.status === "paid" ? "text-emerald-600" : o.status === "pending" ? "text-amber-600" : "text-red-600"
                      }`}
                    >
                      {o.status === "paid" ? "مدفوع" : o.status === "pending" ? "بانتظار الدفع" : o.status === "refunded" ? "مسترجع" : "لم يكتمل"}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>
        </div>
      </div>
    </PageShell>
  );
}
