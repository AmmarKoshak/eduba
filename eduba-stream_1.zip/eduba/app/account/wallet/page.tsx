import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowRight, Gift, Star, Users, Wallet } from "lucide-react";
import { auth } from "@/auth";
import { CopyLink } from "@/components/wallet/CopyLink";
import { Card, PageShell, SectionLabel } from "@/components/site/PageShell";
import { findUserById } from "@/lib/auth/users";
import { env } from "@/lib/env";
import { formatDate, formatDateTime, formatMoney } from "@/lib/format";
import { referralConfig } from "@/lib/referrals/config";
import { walletOverviewForUser } from "@/lib/referrals/service";

export const metadata = { title: "محفظتي والإحالات | إيدوبا" };
export const dynamic = "force-dynamic";

const TX_AR: Record<string, string> = {
  commission: "عمولة إحالة",
  settlement: "تسوية (تحويل بنكي)",
  settlement_reversal: "إلغاء تسوية",
  adjustment: "تعديل",
};
const SETTLEMENT_AR: Record<string, { label: string; cls: string }> = {
  pending: { label: "قيد التحويل", cls: "bg-amber-100 text-amber-700" },
  paid: { label: "مدفوعة", cls: "bg-emerald-100 text-emerald-700" },
  canceled: { label: "ملغاة", cls: "bg-gray-200 text-gray-600" },
};
const REF_AR: Record<string, { label: string; cls: string }> = {
  pending: { label: "بانتظار الدفع", cls: "bg-amber-100 text-amber-700" },
  rewarded: { label: "تمت المكافأة", cls: "bg-emerald-100 text-emerald-700" },
  void: { label: "غير مؤهلة", cls: "bg-gray-200 text-gray-600" },
};

function maskName(name: string) {
  const parts = name.trim().split(/\s+/);
  return parts.map((p, i) => (i === 0 ? p : `${p.slice(0, 1)}.`)).join(" ");
}

export default async function WalletPage() {
  const session = await auth();
  if (!session?.user?.id) redirect("/sign-in?callbackUrl=/account/wallet");
  const user = await findUserById(session.user.id);
  if (!user) redirect("/sign-in");
  const { code, wallet, transactions, referrals, settlements } = await walletOverviewForUser(user.id);
  const link = `${env.appUrl}/r/${code}`;
  const rate = user.commissionRatePercent ? Number(user.commissionRatePercent) : referralConfig.influencerRatePercent;
  const rewarded = referrals.filter((r) => r.referral.status === "rewarded").length;

  return (
    <PageShell width="min(92%,1000px)">
      <Link href="/account" className="inline-flex items-center gap-1 text-sm font-bold text-primary hover:underline mb-4">
        <ArrowRight className="w-4 h-4" />
        حسابي
      </Link>
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-8">
        <div>
          <SectionLabel>{user.isInfluencer ? "محفظة المؤثر" : "محفظتي والإحالات"}</SectionLabel>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-foreground">
            {user.isInfluencer ? "أرباحك من الإحالات" : "ادعُ أصدقاءك واكسب"}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            {user.isInfluencer
              ? `تكسب ${rate}% من أول دفعة لكل مشترك يأتي عبر رابطك، وتُحوَّل أرباحك شهرياً.`
              : `تحصل على ${formatMoney(referralConfig.payerRewardSar)} عن كل صديق يشترك في Pro عبر رابطك.`}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <Card className="p-5">
          <div className="flex items-center gap-2 text-xs font-bold text-muted-foreground mb-2">
            <Wallet className="w-4 h-4" /> الرصيد الحالي
          </div>
          <div className="text-3xl font-black text-emerald-600">{formatMoney(wallet.balance, wallet.currency)}</div>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-2 text-xs font-bold text-muted-foreground mb-2">
            <Star className="w-4 h-4" /> إجمالي الأرباح
          </div>
          <div className="text-3xl font-black text-foreground">{formatMoney(wallet.lifetimeEarned, wallet.currency)}</div>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-2 text-xs font-bold text-muted-foreground mb-2">
            <Users className="w-4 h-4" /> الإحالات الناجحة
          </div>
          <div className="text-3xl font-black text-primary">{rewarded}</div>
          <div className="text-[11px] text-muted-foreground mt-1">من أصل {referrals.length} إحالة</div>
        </Card>
      </div>

      <Card className="p-6 mb-6">
        <div className="flex items-center gap-2 mb-3">
          <Gift className="w-5 h-5 text-primary" />
          <h2 className="text-base font-bold">رابط الإحالة الخاص بك</h2>
        </div>
        <CopyLink value={link} />
        <p className="text-xs text-muted-foreground mt-3">
          رمزك: <span className="font-mono font-bold" dir="ltr">{code}</span> • يُحتسب للمُحال عند أول دفعة ناجحة فقط، ولا تُحتسب الإحالات الذاتية.
        </p>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6">
          <h2 className="text-base font-bold mb-4">الإحالات</h2>
          {referrals.length === 0 ? (
            <p className="text-sm text-muted-foreground">لا توجد إحالات بعد. شارك رابطك!</p>
          ) : (
            <ul className="divide-y divide-border">
              {referrals.map(({ referral, customer, order }) => {
                const st = REF_AR[referral.status];
                return (
                  <li key={referral.id} className="py-3 flex items-center justify-between gap-3 text-sm">
                    <div>
                      <div className="font-bold">{maskName(customer.name)}</div>
                      <div className="text-xs text-muted-foreground">{formatDate(order.createdAt)} • {formatMoney(order.amount)}</div>
                    </div>
                    <div className="text-end">
                      <span className={`inline-block px-2 py-0.5 rounded-md text-[11px] font-bold ${st.cls}`}>{st.label}</span>
                      {referral.commissionAmount && <div className="text-xs font-bold text-emerald-600 mt-1">+{formatMoney(referral.commissionAmount)}</div>}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>

        <Card className="p-6">
          <h2 className="text-base font-bold mb-4">حركات المحفظة</h2>
          {transactions.length === 0 ? (
            <p className="text-sm text-muted-foreground">لا توجد حركات بعد.</p>
          ) : (
            <ul className="divide-y divide-border">
              {transactions.map((t) => {
                const amt = Number(t.amount);
                return (
                  <li key={t.id} className="py-3 flex items-center justify-between gap-3 text-sm">
                    <div>
                      <div className="font-bold">{t.description ?? TX_AR[t.type] ?? t.type}</div>
                      <div className="text-xs text-muted-foreground">{formatDateTime(t.createdAt)}</div>
                    </div>
                    <div className={`font-black whitespace-nowrap ${amt >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                      {amt >= 0 ? "+" : "−"}{formatMoney(Math.abs(amt))}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </Card>
      </div>

      <Card className="p-6 mt-6">
        <h2 className="text-base font-bold mb-1">التسويات الشهرية</h2>
        <p className="text-xs text-muted-foreground mb-4">
          في بداية كل شهر تُجمَّع الأرصدة التي تبلغ {formatMoney(referralConfig.settlementMinSar)} أو أكثر وتُحوَّل إلى حسابك البنكي.
        </p>
        {settlements.length === 0 ? (
          <p className="text-sm text-muted-foreground">لا توجد تسويات بعد.</p>
        ) : (
          <ul className="divide-y divide-border">
            {settlements.map((s) => {
              const st = SETTLEMENT_AR[s.status];
              return (
                <li key={s.id} className="py-3 flex items-center justify-between gap-3 text-sm">
                  <div>
                    <div className="font-bold">تسوية {s.period}</div>
                    <div className="text-xs text-muted-foreground">
                      {s.status === "paid" ? `حُوّلت في ${formatDate(s.paidAt)}${s.reference ? ` • مرجع ${s.reference}` : ""}` : `أُنشئت ${formatDate(s.createdAt)}`}
                    </div>
                  </div>
                  <div className="text-end">
                    <div className="font-black">{formatMoney(s.amount, s.currency)}</div>
                    <span className={`inline-block px-2 py-0.5 rounded-md text-[11px] font-bold ${st.cls}`}>{st.label}</span>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </PageShell>
  );
}
