import Link from "next/link";
import { Sparkles } from "lucide-react";
import { Card, PageShell, primaryButtonClass } from "@/components/site/PageShell";

export const metadata = { title: "اختبر نفسك مجاناً | إيدوبا" };

export default function MarketingQuizPage() {
  return (
    <PageShell width="min(92%,640px)">
      <Card className="p-8 sm:p-10 text-center">
        <Sparkles className="w-12 h-12 text-amber-400 mx-auto mb-4" />
        <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-3">الاختبار السريع قادم قريباً</h1>
        <p className="text-sm sm:text-base text-muted-foreground mb-6">
          نجهّز لك اختباراً قصيراً يحدد مستواك خلال دقائق. حتى ذلك الحين يمكنك إنشاء حسابك المجاني والبدء فوراً.
        </p>
        <Link href="/role-select" className={primaryButtonClass}>
          ابدأ مجاناً
        </Link>
      </Card>
    </PageShell>
  );
}
