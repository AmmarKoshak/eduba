import { NextResponse } from "next/server";
import { normalizeReferralCode, referralConfig } from "@/lib/referrals/config";
import { findReferrerByCode } from "@/lib/referrals/service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Referral landing: /r/<CODE> → remembers the code in a cookie and sends the
 * visitor to the pricing section. Unknown codes just redirect without a cookie.
 */
export async function GET(req: Request, ctx: { params: Promise<{ code: string }> }) {
  const { code } = await ctx.params;
  const url = new URL(req.url);
  const target = new URL("/#pricing", url.origin);
  const res = NextResponse.redirect(target, 302);
  const normalized = normalizeReferralCode(code);
  if (normalized && (await findReferrerByCode(normalized))) {
    res.cookies.set(referralConfig.cookieName, normalized, {
      httpOnly: true,
      sameSite: "lax",
      secure: url.protocol === "https:",
      path: "/",
      maxAge: referralConfig.cookieDays * 24 * 3600,
    });
  }
  return res;
}
