import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { AuthShell } from "@/components/auth/AuthShell";
import { RoleSelect } from "@/components/auth/RoleSelect";

export const metadata = { title: "ابدأ رحلتك | إيدوبا" };

export default async function RoleSelectPage({ searchParams }: { searchParams: Promise<{ plan?: string }> }) {
  const { plan } = await searchParams;
  const session = await auth();
  if (session?.user) {
    redirect(plan === "pro" || plan === "pro_monthly" ? "/checkout?plan=pro_monthly" : "/account");
  }
  return (
    <AuthShell title="مرحباً بك في إيدوبا! 👋" subtitle="أخبرنا كيف ستستخدم المنصة" maxWidth="max-w-2xl">
      <RoleSelect plan={plan} />
    </AuthShell>
  );
}
