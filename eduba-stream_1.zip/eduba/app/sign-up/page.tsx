import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { AuthShell } from "@/components/auth/AuthShell";
import { SignUpForm } from "@/components/auth/SignUpForm";

export const metadata = { title: "إنشاء حساب | إيدوبا" };

export default async function SignUpPage({ searchParams }: { searchParams: Promise<{ role?: string; plan?: string }> }) {
  const { role, plan } = await searchParams;
  const session = await auth();
  if (session?.user) redirect(plan === "pro" || plan === "pro_monthly" ? "/checkout?plan=pro_monthly" : "/account");
  if (role !== "student" && role !== "parent") redirect(`/role-select${plan ? `?plan=${encodeURIComponent(plan)}` : ""}`);

  return (
    <AuthShell
      title={role === "parent" ? "حساب ولي الأمر" : "حساب الطالب"}
      subtitle={role === "parent" ? "تابع تقدم أبنائك من مكان واحد" : "ابدأ رحلتك مع المعلم الذكي"}
      maxWidth="max-w-lg"
    >
      <SignUpForm role={role} plan={plan} />
    </AuthShell>
  );
}
