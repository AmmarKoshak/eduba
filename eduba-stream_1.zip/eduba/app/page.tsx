import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Hero } from "@/components/site/sections/Hero";
import { Problem } from "@/components/site/sections/Problem";
import { Features } from "@/components/site/sections/Features";
import { Students } from "@/components/site/sections/Students";
import { Rewards } from "@/components/site/sections/Rewards";
import { Parents } from "@/components/site/sections/Parents";
import { Pricing } from "@/components/site/sections/Pricing";
import { Faq } from "@/components/site/sections/Faq";
import { Story } from "@/components/site/sections/Story";
import { FinalCta } from "@/components/site/sections/FinalCta";

export default function HomePage() {
  return (
    <>
      <Header variant="overlay" />
      <main>
        <Hero />
        <Problem />
        <Features />
        <Students />
        <Rewards />
        <Parents />
        <Pricing />
        <Faq />
        <Story />
        <FinalCta />
      </main>
      <Footer />
    </>
  );
}
