import { NextResponse } from "next/server";
import { env } from "@/lib/env";
import { verifyStreamSignature } from "@/lib/stream/signature";
import type { StreamWebhookPayload } from "@/lib/stream/types";
import { eventKeyFor, handleStreamEvent, markDelivery, registerDelivery } from "@/lib/stream/webhook-handlers";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Stream webhook receiver.
 * 1. Read the RAW body (the signature covers the exact bytes).
 * 2. Verify `X-Webhook-Signature` (HMAC-SHA256 over "timestamp.rawBody") and the timestamp age.
 * 3. Deduplicate (Stream retries up to 5 times) and process.
 * 4. 2xx = done; 5xx = please retry; 4xx = rejected (bad signature / body).
 */
export async function POST(req: Request) {
  const rawBody = await req.text();
  const signatureHeader = req.headers.get("x-webhook-signature");

  let secret: string;
  try {
    secret = env.streamWebhookSecret;
  } catch {
    console.error("[webhook] STREAM_WEBHOOK_SECRET is not configured");
    return NextResponse.json({ error: "webhook not configured" }, { status: 500 });
  }

  const verification = verifyStreamSignature({
    secret,
    rawBody,
    signatureHeader,
    toleranceSeconds: env.streamWebhookTolerance,
  });
  if (!verification.ok) {
    console.warn("[webhook] rejected delivery:", verification.reason);
    return NextResponse.json({ error: `invalid signature (${verification.reason})` }, { status: 401 });
  }

  let payload: StreamWebhookPayload;
  try {
    payload = JSON.parse(rawBody) as StreamWebhookPayload;
    if (!payload || typeof payload.event_type !== "string") throw new Error("missing event_type");
  } catch {
    return NextResponse.json({ error: "invalid JSON body" }, { status: 400 });
  }

  const eventKey = eventKeyFor(payload, {
    event: req.headers.get("x-webhook-event"),
    entityId: req.headers.get("x-webhook-entity-id"),
    timestamp: req.headers.get("x-webhook-timestamp"),
  });

  let delivery: { id: string; duplicate: boolean; attempts: number };
  try {
    delivery = await registerDelivery(eventKey, payload);
  } catch (err) {
    console.error("[webhook] could not record delivery", err);
    return NextResponse.json({ error: "storage unavailable" }, { status: 500 });
  }
  if (delivery.duplicate) {
    return NextResponse.json({ received: true, duplicate: true });
  }

  try {
    const result = await handleStreamEvent(payload);
    await markDelivery(delivery.id, { ok: true });
    return NextResponse.json({ received: true, result });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error(`[webhook] ${payload.event_type} failed:`, message);
    await markDelivery(delivery.id, { ok: false, error: message }).catch(() => undefined);
    // Non-2xx → Stream retries later; the event row keeps processed_at = null so it is re-processed.
    return NextResponse.json({ error: "handler failed, retry later" }, { status: 500 });
  }
}

export function GET() {
  return NextResponse.json({ ok: true, service: "stream-webhook" });
}
