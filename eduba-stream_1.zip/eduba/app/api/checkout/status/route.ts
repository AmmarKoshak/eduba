import { NextResponse } from "next/server";
import { CheckoutError, verifyOrderPayment } from "@/lib/checkout/service";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Polled by the success page while Stream finishes settling. Re-runs the same
 * server-side verification; never returns `paid` without a verified invoice.
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const orderId = url.searchParams.get("order") ?? "";
  const invoiceId = url.searchParams.get("invoice_id");
  if (!/^[0-9a-f-]{36}$/i.test(orderId)) {
    return NextResponse.json({ state: "unknown", reason: "bad order id" }, { status: 400 });
  }
  try {
    const { verdict } = await verifyOrderPayment(orderId, { invoiceId });
    return NextResponse.json({ state: verdict.state }, { headers: { "Cache-Control": "no-store" } });
  } catch (err) {
    if (err instanceof CheckoutError && err.code === "order_not_found") {
      return NextResponse.json({ state: "unknown", reason: "order not found" }, { status: 404 });
    }
    console.error("[checkout/status]", err);
    return NextResponse.json({ state: "unknown", reason: "verification error" }, { status: 500 });
  }
}
