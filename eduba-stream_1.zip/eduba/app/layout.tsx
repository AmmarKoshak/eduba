import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "إيدوبا - Eduba | Your Smart Private Tutor",
  description:
    "إيدوبا: معلم خصوصي ذكي متاح 24 ساعة، يشرح ويختبر ويتابع تقدم الطالب في جميع مواد وزارة التعليم.",
  icons: { icon: "/brand/eduba-mark.png" },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl">
      <body className="antialiased font-sans">
        <div className="min-h-screen bg-background text-foreground font-sans">
          {children}
        </div>
      </body>
    </html>
  );
}
