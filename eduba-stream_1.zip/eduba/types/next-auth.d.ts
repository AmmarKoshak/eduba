import type { DefaultSession } from "next-auth";

declare module "next-auth" {
  interface User {
    role?: "student" | "parent";
    isAdmin?: boolean;
  }
  interface Session {
    user: {
      id: string;
      role: "student" | "parent";
      isAdmin: boolean;
    } & DefaultSession["user"];
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    role?: "student" | "parent";
    isAdmin?: boolean;
  }
}
