/**
 * Creates (or updates the password of) a site user from the command line.
 * Use it to create your admin login — admin rights come from ADMIN_EMAILS.
 *
 *   npm run user:create -- --email admin@example.com --name "Admin" --password "strong-password" [--role parent] [--phone 05xxxxxxxx]
 */
import "dotenv/config";
import { eq } from "drizzle-orm";
import { getDb, schema } from "../lib/db";
import { hashPassword } from "../lib/auth/users";
import { normalizePhone } from "../lib/phone";

function arg(name: string): string | undefined {
  const i = process.argv.indexOf(`--${name}`);
  return i === -1 ? undefined : process.argv[i + 1];
}

async function main() {
  const email = arg("email")?.trim().toLowerCase();
  const password = arg("password");
  const name = arg("name") ?? "Admin";
  const role = (arg("role") ?? "parent") as "student" | "parent";
  const phoneRaw = arg("phone");
  if (!email || !password) {
    console.error("Usage: npm run user:create -- --email <email> --password <password> [--name <name>] [--role student|parent] [--phone 05xxxxxxxx] [--influencer --rate 20]");
    process.exit(1);
  }
  if (password.length < 8) {
    console.error("Password must be at least 8 characters.");
    process.exit(1);
  }
  const phone = phoneRaw ? normalizePhone(phoneRaw) : null;
  const influencer = process.argv.includes("--influencer");
  const rateRaw = arg("rate");
  const rate = rateRaw !== undefined ? Number(rateRaw) : null;
  const db = getDb();
  const passwordHash = await hashPassword(password);
  const existing = await db.select({ id: schema.users.id }).from(schema.users).where(eq(schema.users.email, email)).limit(1);
  if (existing[0]) {
    await db
      .update(schema.users)
      .set({ passwordHash, name, phone, updatedAt: new Date(), ...(influencer ? { isInfluencer: true, commissionRatePercent: rate !== null ? rate.toFixed(2) : null } : {}) })
      .where(eq(schema.users.id, existing[0].id));
    console.log(`✓ updated ${email}${influencer ? " (influencer)" : ""}`);
  } else {
    await db.insert(schema.users).values({ email, name, passwordHash, role, phone, isInfluencer: influencer, commissionRatePercent: influencer && rate !== null ? rate.toFixed(2) : null });
    console.log(`✓ created ${email} (${role}${influencer ? ", influencer" : ""})`);
  }
  const admins = (process.env.ADMIN_EMAILS ?? "").split(",").map((s) => s.trim().toLowerCase());
  console.log(admins.includes(email) ? "  → this email is in ADMIN_EMAILS: /admin is enabled for it." : "  → not in ADMIN_EMAILS (no /admin access).");
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
