/**
 * One-time Stream setup (run against the SANDBOX key pair first):
 *
 *   npm run stream:setup                 # products + webhook
 *   npm run stream:setup -- --no-webhook # products only
 *   npm run stream:setup -- --with-test-product   # also a 300 SAR one-time product for installment tests
 *
 * It is idempotent: existing products/webhooks with the same name/url are reused.
 * At the end it prints the env lines to paste into .env / Vercel.
 */
import "dotenv/config";
import { randomBytes } from "node:crypto";
import { env } from "../lib/env";
import { PRODUCTS, type SiteProduct } from "../lib/products";
import { StreamApiError, StreamClient } from "../lib/stream/client";
import type { Product, WebhookRegistration } from "../lib/stream/types";

const WEBHOOK_EVENTS = [
  "PAYMENT_SUCCEEDED",
  "PAYMENT_FAILED",
  "PAYMENT_CANCELED",
  "PAYMENT_REFUNDED",
  "PAYMENT_PARTIALLY_REFUNDED",
  "PAYMENT_MARKED_AS_PAID",
  "PAYMENT_EXPIRED",
  "PAYMENT_LINK_PAY_ATTEMPT_FAILED",
  "INVOICE_COMPLETED",
  "INVOICE_CANCELED",
  "INVOICE_REJECTED",
  "INVOICE_EXPIRED",
  "SUBSCRIPTION_CREATED",
  "SUBSCRIPTION_ACTIVATED",
  "SUBSCRIPTION_INACTIVATED",
  "SUBSCRIPTION_CANCELED",
  "SUBSCRIPTION_FROZEN",
  "SUBSCRIPTION_CYCLE_RENEWED_SUCCESSFULLY",
  "SUBSCRIPTION_CYCLE_RENEWAL_FAILED",
  "SUBSCRIPTION_CANCEL_AT_PERIOD_END",
  "SUBSCRIPTION_PLAN_CHANGED",
];

const args = new Set(process.argv.slice(2));
const withTestProduct = args.has("--with-test-product");
const noWebhook = args.has("--no-webhook");

async function findProductByName(client: StreamClient, name: string): Promise<Product | undefined> {
  const res = await client.listProducts({ search_term: name, limit: 50, active: true });
  return (res.data ?? []).find((p) => p.name === name);
}

async function ensureProduct(client: StreamClient, def: SiteProduct): Promise<Product> {
  const existing = await findProductByName(client, def.name);
  if (existing) {
    console.log(`• product exists: ${def.name} → ${existing.id}`);
    return existing;
  }
  const created = await client.createProduct({
    name: def.name,
    description: def.description,
    prices: [{ currency: def.currency, amount: def.amount, is_price_inclusive_of_vat: true, is_price_exempt_from_vat: false }],
    is_one_time: def.type === "ONE_OFF",
    type: def.type,
    recurring_interval: def.type === "RECURRING" ? def.recurringInterval : undefined,
    recurring_interval_count: def.recurringIntervalCount ?? 1,
  });
  console.log(`✓ product created: ${def.name} → ${created.id}`);
  return created;
}

function webhookList(res: unknown): WebhookRegistration[] {
  if (Array.isArray(res)) return res as WebhookRegistration[];
  if (res && typeof res === "object" && Array.isArray((res as { data?: unknown }).data)) {
    return (res as { data: WebhookRegistration[] }).data;
  }
  return [];
}

async function ensureWebhook(client: StreamClient, url: string): Promise<{ secret?: string; existing: boolean }> {
  const existing = webhookList(await client.listWebhooks()).find((w) => w.url === url);
  if (existing) {
    console.log(`• webhook exists for ${url} (id ${existing.id}, enabled=${existing.enabled}).`);
    console.log("  Stream does not return the secret of an existing webhook: keep the STREAM_WEBHOOK_SECRET you saved,");
    console.log("  or delete the webhook in the dashboard and run this script again to get a new one.");
    return { existing: true };
  }
  const secret = randomBytes(32).toString("hex");
  const created = await client.createWebhook({
    url,
    enabled: true,
    name: "Eduba website",
    secret_key: secret,
    subscriptions: WEBHOOK_EVENTS,
  });
  console.log(`✓ webhook created: ${created.id} → ${url}`);
  return { secret, existing: false };
}

async function main() {
  const client = new StreamClient();
  const me = await client.me();
  const org = me.organization ?? {};
  console.log(`Connected to Stream as ${me.user?.email ?? "?"} — organisation "${org.name ?? "?"}" (sandbox: ${org.sandbox ?? "unknown"})`);
  if (org.sandbox === false && !args.has("--allow-production")) {
    console.error("\n✗ This key pair belongs to a LIVE organisation. Use sandbox keys for setup/testing,");
    console.error("  or pass --allow-production once you are deploying for real.");
    process.exit(1);
  }

  const envLines: string[] = [];
  const pro = await ensureProduct(client, PRODUCTS.pro_monthly);
  envLines.push(`STREAM_PRODUCT_PRO_MONTHLY_ID=${pro.id}`);

  if (withTestProduct) {
    const test = await ensureProduct(client, PRODUCTS.test_one_time);
    envLines.push(`STREAM_PRODUCT_TEST_ONE_TIME_ID=${test.id}`);
  }

  if (!noWebhook) {
    const url = `${env.appUrl}/api/webhooks/stream`;
    if (!url.startsWith("https://")) {
      console.log(`\n• Skipping webhook: ${url} is not HTTPS. Stream needs a public https URL (deploy first, or use a tunnel),`);
      console.log("  then run: NEXT_PUBLIC_APP_URL=https://your-domain npm run stream:setup");
    } else {
      try {
        const wh = await ensureWebhook(client, url);
        if (wh.secret) envLines.push(`STREAM_WEBHOOK_SECRET=${wh.secret}`);
      } catch (err) {
        if (err instanceof StreamApiError) console.error(`✗ webhook registration failed (${err.status}):`, err.body);
        else throw err;
      }
    }
  }

  console.log("\nAdd these to .env (and to your host's environment variables):\n");
  for (const line of envLines) console.log(`  ${line}`);
  console.log("");
}

main().catch((err) => {
  if (err instanceof StreamApiError) {
    console.error(`✗ Stream API error ${err.status} ${err.code ?? ""}:`, err.body);
  } else {
    console.error("✗", err);
  }
  process.exit(1);
});
