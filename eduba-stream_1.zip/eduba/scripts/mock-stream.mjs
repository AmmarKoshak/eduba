#!/usr/bin/env node
/**
 * Local stand-in for the Stream API + hosted checkout, for development and
 * automated tests WITHOUT touching the real sandbox.
 *
 *   node scripts/mock-stream.mjs            # listens on http://127.0.0.1:4567
 *
 * Point the app at it with:
 *   STREAM_API_BASE_URL=http://127.0.0.1:4567/api/v2
 *   STREAM_PRODUCT_PRO_MONTHLY_ID=mock-pro-monthly
 *   STREAM_WEBHOOK_SECRET=<same value as MOCK_WEBHOOK_SECRET below>
 *
 * The fake hosted checkout (/ds/<link id>) offers "pay" / "fail" buttons; "pay"
 * creates invoice + payment + subscription, POSTs a signed webhook to
 * MOCK_WEBHOOK_URL (default http://127.0.0.1:3000/api/webhooks/stream) and then
 * redirects to the link's success URL exactly like Stream does.
 */
import { createHmac, randomUUID } from "node:crypto";
import http from "node:http";

const PORT = Number(process.env.MOCK_STREAM_PORT ?? 4567);
const WEBHOOK_URL = process.env.MOCK_WEBHOOK_URL ?? "http://127.0.0.1:3000/api/webhooks/stream";
const WEBHOOK_SECRET = process.env.MOCK_WEBHOOK_SECRET ?? process.env.STREAM_WEBHOOK_SECRET ?? "mock-webhook-secret";
const SANDBOX = process.env.MOCK_SANDBOX !== "false";

const db = {
  consumers: new Map(),
  products: new Map(),
  links: new Map(),
  invoices: new Map(),
  payments: new Map(),
  subscriptions: new Map(),
  webhooks: new Map(),
};

// Seed the two site products so `npm run stream:setup` is not required for local dev.
for (const p of [
  { id: "mock-pro-monthly", name: "إيدوبا Pro – اشتراك شهري", type: "RECURRING", is_one_time: false, recurring_interval: "MONTH", recurring_interval_count: 1, price: "115.00", currency: "SAR", is_active: true, prices: [{ currency: "SAR", amount: "115.00", is_active: true }] },
  { id: "mock-test-one-time", name: "باقة تجريبية (اختبار الأقساط)", type: "ONE_OFF", is_one_time: true, price: "300.00", currency: "SAR", is_active: true, prices: [{ currency: "SAR", amount: "300.00", is_active: true }] },
]) db.products.set(p.id, { ...p, created_at: new Date().toISOString() });

const now = () => new Date().toISOString();
const paginate = (rows, q) => {
  const page = Math.max(1, Number(q.get("page") ?? 1));
  const limit = Math.min(100, Math.max(1, Number(q.get("limit") ?? 10)));
  const start = (page - 1) * limit;
  const data = rows.slice(start, start + limit);
  const max_page = Math.max(1, Math.ceil(rows.length / limit));
  return { data, pagination: { total_count: data.length, max_page, current_page: page, limit, has_next_page: page < max_page, has_previous_page: page > 1 } };
};
const json = (res, status, body) => {
  res.writeHead(status, { "content-type": "application/json" });
  res.end(JSON.stringify(body));
};
const html = (res, status, body) => {
  res.writeHead(status, { "content-type": "text/html; charset=utf-8" });
  res.end(body);
};
const readBody = (req) =>
  new Promise((resolve) => {
    let data = "";
    req.on("data", (c) => (data += c));
    req.on("end", () => resolve(data ? JSON.parse(data) : {}));
  });
const inRange = (iso, q) => {
  const t = Date.parse(iso ?? "");
  const from = q.get("from_date") ? Date.parse(q.get("from_date")) : -Infinity;
  const to = q.get("to_date") ? Date.parse(q.get("to_date")) : Infinity;
  return Number.isFinite(t) ? t >= from && t <= to : true;
};
const matchesStatus = (status, q) => {
  const wanted = q.getAll("statuses");
  return wanted.length === 0 || wanted.includes(status);
};

async function sendWebhook(eventType, entityType, entityId, status, data) {
  const payload = { event_type: eventType, entity_type: entityType, entity_id: entityId, entity_url: `http://127.0.0.1:${PORT}/api/v2/${entityType.toLowerCase()}s/${entityId}`, status, timestamp: now(), data };
  const raw = JSON.stringify(payload);
  const t = String(Math.floor(Date.now() / 1000));
  const sig = createHmac("sha256", WEBHOOK_SECRET).update(`${t}.${raw}`).digest("hex");
  try {
    const res = await fetch(WEBHOOK_URL, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "user-agent": "StreamApp-Webhook/1.0",
        "x-webhook-event": eventType,
        "x-webhook-entity-type": entityType,
        "x-webhook-entity-id": entityId,
        "x-webhook-timestamp": t,
        "x-webhook-signature": `t=${t},v1=${sig}`,
      },
      body: raw,
    });
    console.log(`[mock-stream] webhook ${eventType} → ${res.status}`);
  } catch (err) {
    console.log(`[mock-stream] webhook ${eventType} failed: ${err.message}`);
  }
}

function completePayment(link, outcome, method = "VISA", installments = 1) {
  const consumer = db.consumers.get(link.organization_consumer_id);
  const product = db.products.get(link.items[0].product_id);
  const amount = Number(product.price) * (link.items[0].quantity ?? 1);
  const invoiceId = randomUUID();
  const paymentId = randomUUID();
  const ts = now();
  let subscriptionId = null;
  if (outcome === "paid" && product.type === "RECURRING") {
    subscriptionId = randomUUID();
    const periodEnd = new Date(Date.now() + 30 * 86400000).toISOString();
    db.subscriptions.set(subscriptionId, {
      id: subscriptionId,
      status: "ACTIVE",
      amount: amount.toFixed(2),
      currency: link.currency,
      recurring_interval: "MONTH",
      recurring_interval_count: 1,
      current_period_start: ts,
      current_period_end: periodEnd,
      cancel_at_period_end: false,
      started_at: ts,
      created_at: ts,
      organization_consumer_id: consumer?.id,
      organization_consumer: consumer && { id: consumer.id, name: consumer.name, email: consumer.email, phone_number: consumer.phone_number },
      items: [{ product_id: product.id, product, quantity: 1, amount: amount.toFixed(2) }],
      latest_invoice_id: invoiceId,
    });
  }
  const perInstallment = amount / installments;
  const payments = Array.from({ length: installments }, (_, i) => ({
    id: i === 0 ? paymentId : randomUUID(),
    amount: perInstallment.toFixed(2),
    currency: link.currency,
    scheduled_on: new Date(Date.now() + i * 30 * 86400000).toISOString(),
    type: installments > 1 ? "INSTALLMENT" : "INITIAL",
    invoice_payment_number: i + 1,
    payment_method: method,
    current_status: outcome === "paid" ? (i === 0 ? "SUCCEEDED" : "PENDING") : "FAILED",
    payed_at: outcome === "paid" && i === 0 ? ts : null,
    latest_pgw_message: outcome === "paid" ? "APPROVED" : "DECLINED",
    invoice_id: invoiceId,
  }));
  for (const p of payments) db.payments.set(p.id, p);
  const paid = outcome === "paid" ? payments.filter((p) => p.current_status === "SUCCEEDED").reduce((s, p) => s + Number(p.amount), 0) : 0;
  const invoice = {
    id: invoiceId,
    created_at: ts,
    payment_link_id: link.id,
    organization_consumer_id: consumer?.id,
    organization_consumer: consumer && { id: consumer.id, name: consumer.name, email: consumer.email, phone_number: consumer.phone_number },
    org_invoice_number: db.invoices.size + 1,
    currency: link.currency,
    total_amount: amount.toFixed(2),
    paid_amount: paid.toFixed(2),
    remaining_amount: (amount - paid).toFixed(2),
    status: outcome === "paid" ? (paid >= amount ? "COMPLETED" : "ACCEPTED") : "REJECTED",
    type: product.type === "RECURRING" ? "RECURRING" : installments > 1 ? "INSTALLMENTS" : "ONE_OFF",
    subscription_id: subscriptionId,
    subscription: subscriptionId ? { id: subscriptionId, status: "ACTIVE" } : null,
    payments,
    total_number_of_payments: installments,
    last_payment_paid_at: outcome === "paid" ? ts : null,
  };
  db.invoices.set(invoiceId, invoice);
  link.status = outcome === "paid" ? "COMPLETED" : "ACTIVE";
  return { invoice, payment: payments[0], subscriptionId };
}

function hostedCheckoutPage(link) {
  const product = db.products.get(link.items[0].product_id);
  const consumer = db.consumers.get(link.organization_consumer_id);
  const installmentsAllowed = product.type === "ONE_OFF" && (link.payment_methods?.installment ?? false);
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>Mock Stream Checkout</title>
<style>body{font-family:system-ui;background:#f6f7fb;margin:0;padding:24px}.card{max-width:420px;margin:0 auto;background:#fff;border-radius:16px;padding:24px;box-shadow:0 10px 30px rgba(0,0,0,.08)}h1{font-size:18px;margin:0 0 8px}.amt{font-size:32px;font-weight:800;margin:8px 0 16px}a.btn{display:block;text-align:center;padding:12px;border-radius:10px;margin:8px 0;text-decoration:none;font-weight:700}.pay{background:#0d0d0d;color:#fff}.fail{background:#fee2e2;color:#991b1b}.inst{background:#e0f2fe;color:#075985}.muted{color:#6b7280;font-size:12px}</style></head>
<body><div class="card"><div class="muted">MOCK STREAM — بيئة محاكاة محلية</div><h1>${product.name}</h1>
<div class="muted">${consumer ? `${consumer.name} • ${consumer.phone_number ?? ""}` : "عميل غير محدد"}</div>
<div class="amt">${product.price} ${link.currency}</div>
<a class="btn pay" href="/ds/${link.id}/pay?outcome=paid">ادفع الآن (بطاقة ناجحة 4111…)</a>
<a class="btn pay" href="/ds/${link.id}/pay?outcome=paid&method=APPLE_PAY">ادفع عبر Apple Pay</a>
${installmentsAllowed ? `<a class="btn inst" href="/ds/${link.id}/pay?outcome=paid&installments=3">قسّطها على 3 دفعات</a>` : ""}
<a class="btn fail" href="/ds/${link.id}/pay?outcome=failed">بطاقة مرفوضة (DECLINED)</a>
<p class="muted">embed=${link._embed ? "true" : "false"}</p></div></body></html>`;
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://127.0.0.1:${PORT}`);
  const path = url.pathname.replace(/\/+$/, "");
  const q = url.searchParams;

  // ---- hosted checkout -----------------------------------------------------
  let m = path.match(/^\/ds\/([^/]+)$/);
  if (m) {
    const link = db.links.get(m[1]);
    if (!link) return html(res, 404, "<h1>Payment link not found</h1>");
    link._embed = q.get("embed") === "true";
    return html(res, 200, hostedCheckoutPage(link));
  }
  m = path.match(/^\/ds\/([^/]+)\/pay$/);
  if (m) {
    const link = db.links.get(m[1]);
    if (!link) return html(res, 404, "<h1>Payment link not found</h1>");
    const outcome = q.get("outcome") === "failed" ? "failed" : "paid";
    const { invoice, payment, subscriptionId } = completePayment(link, outcome, q.get("method") ?? "VISA", Number(q.get("installments") ?? 1));
    const meta = link.custom_metadata ?? {};
    if (outcome === "paid") {
      await sendWebhook("PAYMENT_SUCCEEDED", "PAYMENT", payment.id, "SUCCEEDED", { invoice: { id: invoice.id }, payment: { id: payment.id }, metadata: meta });
      if (subscriptionId) await sendWebhook("SUBSCRIPTION_ACTIVATED", "SUBSCRIPTION", subscriptionId, "ACTIVE", { subscription: { id: subscriptionId }, invoice: { id: invoice.id }, metadata: meta });
      const target = new URL(link.success_redirect_url ?? `http://127.0.0.1:${PORT}/done`);
      target.searchParams.set("id", randomUUID());
      target.searchParams.set("invoice_id", invoice.id);
      target.searchParams.set("payment_id", payment.id);
      target.searchParams.set("organization_consumer_id", link.organization_consumer_id ?? "");
      target.searchParams.set("status", "paid");
      target.searchParams.set("message", "APPROVED");
      res.writeHead(302, { location: target.toString() });
      return res.end();
    }
    await sendWebhook("PAYMENT_LINK_PAY_ATTEMPT_FAILED", "PAYMENT_LINK", link.id, "FAILED", { invoice: { id: invoice.id }, metadata: meta });
    const target = new URL(link.failure_redirect_url ?? `http://127.0.0.1:${PORT}/done`);
    target.searchParams.set("payment_link_id", link.id);
    target.searchParams.set("id", randomUUID());
    target.searchParams.set("status", "failed");
    target.searchParams.set("message", "DECLINED");
    res.writeHead(302, { location: target.toString() });
    return res.end();
  }
  if (path === "/done") return html(res, 200, "<h1>Mock Stream: done</h1>");
  if (path === "/portal") return html(res, 200, `<h1>Mock customer portal</h1><p>consumer ${q.get("c")}</p>`);

  // ---- API -----------------------------------------------------------------
  if (!path.startsWith("/api/v2/")) return json(res, 404, { error: { code: "NOT_FOUND", message: "not found" } });
  if (!req.headers["x-api-key"]) return json(res, 401, { error: { code: "UNAUTHORIZED", message: "missing x-api-key" } });
  const p = path.slice("/api/v2".length);
  const method = req.method;

  if (p === "/me") return json(res, 200, { user: { id: "u1", email: "mock@streampay.sa", name: "Mock" }, organization: { id: "org1", name: "Mock Org", sandbox: SANDBOX } });

  if (p === "/consumers" && method === "GET") {
    const term = (q.get("search_term") ?? "").toLowerCase().replace(/\s/g, "");
    const rows = [...db.consumers.values()].filter((c) => !term || [c.name, c.email, c.phone_number, c.external_id].some((v) => (v ?? "").toLowerCase().replace(/\s/g, "").includes(term)));
    return json(res, 200, paginate(rows.sort((a, b) => b.created_at.localeCompare(a.created_at)), q));
  }
  if (p === "/consumers" && method === "POST") {
    const body = await readBody(req);
    if (!body.name) return json(res, 422, { detail: [{ loc: ["body", "name"], msg: "Field required", type: "missing" }] });
    const dup = [...db.consumers.values()].find((c) => (body.email && c.email === body.email) || (body.phone_number && c.phone_number === body.phone_number));
    if (dup) return json(res, 422, { error: { code: "DUPLICATE_CONSUMER", message: "Consumer already exists." } });
    const c = { id: randomUUID(), is_deleted: false, created_at: now(), ...body };
    db.consumers.set(c.id, c);
    return json(res, 200, c);
  }
  m = p.match(/^\/consumers\/([^/]+)$/);
  if (m && method === "GET") return db.consumers.has(m[1]) ? json(res, 200, db.consumers.get(m[1])) : json(res, 404, { error: { code: "NOT_FOUND", message: "consumer not found" } });

  if (p === "/products" && method === "GET") {
    const term = (q.get("search_term") ?? "").toLowerCase();
    const rows = [...db.products.values()].filter((x) => !term || x.name.toLowerCase().includes(term));
    return json(res, 200, paginate(rows, q));
  }
  if (p === "/products" && method === "POST") {
    const body = await readBody(req);
    const price = body.prices?.[0];
    const prod = { id: randomUUID(), created_at: now(), is_active: true, name: body.name, description: body.description, type: body.type, is_one_time: body.is_one_time, recurring_interval: body.recurring_interval, recurring_interval_count: body.recurring_interval_count, price: Number(price?.amount ?? body.price).toFixed(2), currency: price?.currency ?? "SAR", prices: price ? [{ ...price, amount: Number(price.amount).toFixed(2), is_active: true }] : [] };
    db.products.set(prod.id, prod);
    return json(res, 200, prod);
  }

  if (p === "/payment_links" && method === "POST") {
    const body = await readBody(req);
    const product = db.products.get(body.items?.[0]?.product_id);
    if (!product) return json(res, 422, { error: { code: "INVALID_PARAMETERS", message: "unknown product" } });
    const types = new Set(body.items.map((i) => db.products.get(i.product_id)?.type));
    if (types.size > 1) return json(res, 422, { error: { code: "INVALID_PARAMETERS", message: "cannot mix one-time and recurring products" } });
    const id = randomUUID();
    const link = { id, created_at: now(), status: "ACTIVE", amount: product.price, ...body, url: `http://127.0.0.1:${PORT}/ds/${id}` };
    db.links.set(id, link);
    return json(res, 200, link);
  }
  m = p.match(/^\/payment_links\/([^/]+)$/);
  if (m && method === "GET") return db.links.has(m[1]) ? json(res, 200, db.links.get(m[1])) : json(res, 404, { error: { code: "NOT_FOUND", message: "link not found" } });

  if (p === "/invoices" && method === "GET") {
    let rows = [...db.invoices.values()];
    if (q.get("payment_link_id")) rows = rows.filter((i) => i.payment_link_id === q.get("payment_link_id"));
    if (q.get("organization_consumer_id")) rows = rows.filter((i) => i.organization_consumer_id === q.get("organization_consumer_id"));
    rows = rows.filter((i) => matchesStatus(i.status, q) && inRange(i.created_at, q));
    const term = (q.get("search_term") ?? "").toLowerCase();
    if (term) rows = rows.filter((i) => [i.organization_consumer?.name, i.organization_consumer?.email, i.organization_consumer?.phone_number, i.id].some((v) => (v ?? "").toLowerCase().includes(term)));
    return json(res, 200, paginate(rows.sort((a, b) => b.created_at.localeCompare(a.created_at)), q));
  }
  m = p.match(/^\/invoices\/([^/]+)$/);
  if (m && method === "GET") return db.invoices.has(m[1]) ? json(res, 200, db.invoices.get(m[1])) : json(res, 404, { error: { code: "NOT_FOUND", message: "invoice not found" } });

  if (p === "/payments" && method === "GET") {
    let rows = [...db.payments.values()].filter((x) => matchesStatus(x.current_status, q) && inRange(x.payed_at ?? x.scheduled_on, q));
    if (q.getAll("invoice_id").length) rows = rows.filter((x) => q.getAll("invoice_id").includes(x.invoice_id));
    return json(res, 200, paginate(rows.sort((a, b) => (b.payed_at ?? b.scheduled_on).localeCompare(a.payed_at ?? a.scheduled_on)), q));
  }
  m = p.match(/^\/payments\/([^/]+)$/);
  if (m && method === "GET") return db.payments.has(m[1]) ? json(res, 200, db.payments.get(m[1])) : json(res, 404, { error: { code: "NOT_FOUND", message: "payment not found" } });

  if (p === "/subscriptions" && method === "GET") {
    let rows = [...db.subscriptions.values()].filter((s) => matchesStatus(s.status, q) && inRange(s.created_at, q));
    if (q.get("organization_consumer_id")) rows = rows.filter((s) => s.organization_consumer_id === q.get("organization_consumer_id"));
    return json(res, 200, paginate(rows.sort((a, b) => b.created_at.localeCompare(a.created_at)), q));
  }
  m = p.match(/^\/subscriptions\/([^/]+)$/);
  if (m && method === "GET") return db.subscriptions.has(m[1]) ? json(res, 200, db.subscriptions.get(m[1])) : json(res, 404, { error: { code: "NOT_FOUND", message: "subscription not found" } });
  m = p.match(/^\/subscriptions\/([^/]+)\/cancel$/);
  if (m && method === "POST") {
    const s = db.subscriptions.get(m[1]);
    if (!s) return json(res, 404, { error: { code: "NOT_FOUND", message: "subscription not found" } });
    s.status = "CANCELED";
    s.ended_at = now();
    await sendWebhook("SUBSCRIPTION_CANCELED", "SUBSCRIPTION", s.id, "CANCELED", { subscription: { id: s.id } });
    return json(res, 200, s);
  }

  if (p === "/consumer_portal/sessions" && method === "POST") {
    const body = await readBody(req);
    if (!db.consumers.has(body.organization_consumer_id)) return json(res, 404, { error: { code: "NOT_FOUND", message: "consumer not found" } });
    return json(res, 201, { id: randomUUID(), url: `http://127.0.0.1:${PORT}/portal?c=${body.organization_consumer_id}`, created_at: now(), expires_at: new Date(Date.now() + 3600000).toISOString() });
  }

  if (p === "/webhooks" && method === "GET") return json(res, 200, { data: [...db.webhooks.values()], pagination: {} });
  if (p === "/webhooks" && method === "POST") {
    const body = await readBody(req);
    const w = { id: randomUUID(), url: body.url, name: body.name, enabled: body.enabled, health_status: "ENABLED", event_subscriptions: (body.subscriptions ?? []).map((e) => ({ event_type: e })) };
    db.webhooks.set(w.id, w);
    return json(res, 200, w);
  }
  if (p === "/webhooks/events") return json(res, 200, ["PAYMENT_SUCCEEDED", "PAYMENT_FAILED", "INVOICE_COMPLETED", "SUBSCRIPTION_ACTIVATED", "SUBSCRIPTION_CANCELED"]);

  return json(res, 404, { error: { code: "NOT_FOUND", message: `no mock for ${method} ${p}` } });
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`[mock-stream] listening on http://127.0.0.1:${PORT} (sandbox=${SANDBOX}); webhooks → ${WEBHOOK_URL}`);
});
