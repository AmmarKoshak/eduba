#!/usr/bin/env node
/**
 * Copies the brand images from the live site into public/ (same paths, so no
 * code changes are needed). Run once on your machine:
 *
 *   node scripts/download-assets.mjs            # from https://eduba.tech
 *   node scripts/download-assets.mjs https://staging.example.com
 *
 * Only run this against a site you own.
 */
import { mkdir, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const origin = (process.argv[2] ?? "https://eduba.tech").replace(/\/+$/, "");
const root = join(dirname(fileURLToPath(import.meta.url)), "..", "public");

const FILES = [
  "/brand/eduba-mark.png",
  "/landing/hero/bg.png",
  "/landing/hero/mascots.png",
  "/landing/mascots/robot-curious.png",
  "/landing/mascots/robot-winking.png",
  "/landing/mascots/robot-cta.png",
  "/landing/rewards/treasure.png",
  "/landing/coins/pink.png",
  "/landing/coins/green.png",
  "/landing/coins/gold.png",
  "/landing/story/bg.png",
];

let failed = 0;
for (const path of FILES) {
  const url = `${origin}${path}`;
  try {
    const res = await fetch(url, { headers: { accept: "image/*" } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const type = res.headers.get("content-type") ?? "";
    if (!type.startsWith("image/")) throw new Error(`unexpected content-type ${type}`);
    const buf = Buffer.from(await res.arrayBuffer());
    const target = join(root, path);
    await mkdir(dirname(target), { recursive: true });
    await writeFile(target, buf);
    console.log(`✓ ${path} (${(buf.length / 1024).toFixed(0)} KB)`);
  } catch (err) {
    failed++;
    console.error(`✗ ${path}: ${err.message}`);
  }
}
if (failed) {
  console.error(`\n${failed} file(s) failed; placeholders stay in place for those.`);
  process.exit(1);
}
console.log("\nAll assets copied into public/.");
