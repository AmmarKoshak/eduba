# Apple Pay domain association

`apple-developer-merchantid-domain-association` is Stream's Apple Pay domain
verification file, copied verbatim from
https://streampay.sa/.well-known/apple-developer-merchantid-domain-association
on 2026-11-09. Apple fetches it from
`https://<your-domain>/.well-known/apple-developer-merchantid-domain-association`
once Stream support registers your domain. Keep it byte-identical (no trailing
newline) and re-download it if Stream rotates their file.
