"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, X } from "lucide-react";
import type { AdminActionState } from "@/app/admin/wallets/actions";
import { pushAdminToast } from "./AdminToaster";

export interface DialogField {
  name: string;
  label: string;
  type?: "text" | "number" | "month";
  defaultValue?: string;
  placeholder?: string;
  required?: boolean;
  step?: string;
  min?: string;
  max?: string;
}

/**
 * Generic "are you sure?" dialog around a server action. Every write action in
 * the admin panel goes through it: the user sees what will happen, fills any
 * required fields (amount, bank reference…) and confirms explicitly.
 */
export function ConfirmActionDialog({
  action,
  trigger,
  title,
  description,
  confirmLabel,
  hidden = {},
  fields = [],
  tone = "primary",
  disabled = false,
}: {
  action: (prev: AdminActionState | null, formData: FormData) => Promise<AdminActionState>;
  trigger: string;
  title: string;
  description: string;
  confirmLabel: string;
  hidden?: Record<string, string>;
  fields?: DialogField[];
  tone?: "primary" | "danger";
  disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [state, formAction, pending] = useActionState<AdminActionState | null, FormData>(action, null);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const router = useRouter();

  useEffect(() => {
    if (!state) return;
    pushAdminToast(state);
    if (state.ok) router.refresh(); // re-fetch the server component after the result is on screen
  }, [state, router]);

  useEffect(() => {
    const d = dialogRef.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);

  const btn =
    tone === "danger"
      ? "bg-red-600 text-white hover:bg-red-700"
      : "bg-primary text-white hover:opacity-95";

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        disabled={disabled}
        className={`inline-flex items-center px-3 py-1.5 rounded-lg text-xs font-bold border transition disabled:opacity-40 disabled:cursor-not-allowed ${
          tone === "danger" ? "border-red-200 text-red-700 hover:bg-red-50" : "border-primary/40 text-primary hover:bg-primary/5"
        }`}
      >
        {trigger}
      </button>

      <dialog
        ref={dialogRef}
        onClose={() => setOpen(false)}
        className="rounded-2xl p-0 w-[min(92vw,440px)] backdrop:bg-black/40 text-foreground"
        dir="rtl"
      >
        <form action={formAction} className="p-6 space-y-4">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 className="text-lg font-bold">{title}</h3>
              <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{description}</p>
            </div>
            <button type="button" onClick={() => setOpen(false)} aria-label="إغلاق" className="text-muted-foreground hover:text-foreground">
              <X className="w-5 h-5" />
            </button>
          </div>

          {Object.entries(hidden).map(([k, v]) => (
            <input key={k} type="hidden" name={k} value={v} />
          ))}

          {fields.map((f) => (
            <label key={f.name} className="block text-sm">
              <span className="block font-bold mb-1">{f.label}</span>
              <input
                name={f.name}
                type={f.type ?? "text"}
                defaultValue={f.defaultValue}
                placeholder={f.placeholder}
                required={f.required}
                step={f.step}
                min={f.min}
                max={f.max}
                dir="ltr"
                className="w-full rounded-xl border border-input bg-white px-3 py-2 text-sm text-left focus:outline-none focus:ring-2 focus:ring-primary/30"
              />
            </label>
          ))}

          {state && (
            <div className={`text-sm rounded-xl px-4 py-3 border ${state.ok ? "bg-emerald-50 border-emerald-100 text-emerald-700" : "bg-red-50 border-red-100 text-red-700"}`}>
              {state.message}
            </div>
          )}

          <div className="flex items-center justify-end gap-2 pt-2">
            {state?.ok ? (
              <button type="button" onClick={() => setOpen(false)} className={`px-4 py-2 rounded-xl text-sm font-bold transition ${btn}`}>
                إغلاق
              </button>
            ) : (
              <>
                <button type="button" onClick={() => setOpen(false)} className="px-4 py-2 rounded-xl text-sm font-bold text-muted-foreground hover:text-foreground">
                  إلغاء
                </button>
                <button type="submit" disabled={pending} className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold transition disabled:opacity-60 ${btn}`}>
                  {pending && <Loader2 className="w-4 h-4 animate-spin" />}
                  {confirmLabel}
                </button>
              </>
            )}
          </div>
        </form>
      </dialog>
    </>
  );
}
