import Link from "next/link";
import { ExternalLink } from "lucide-react";
import type { Pagination as StreamPagination } from "@/lib/stream/types";

const TONES: Record<string, string> = {
  // payments
  SUCCEEDED: "bg-emerald-100 text-emerald-700",
  SETTLED: "bg-emerald-100 text-emerald-700",
  PENDING: "bg-amber-100 text-amber-700",
  PROCESSING: "bg-amber-100 text-amber-700",
  UNDER_REVIEW: "bg-amber-100 text-amber-700",
  FAILED: "bg-red-100 text-red-700",
  FAILED_INITIATION: "bg-red-100 text-red-700",
  CANCELED: "bg-gray-200 text-gray-600",
  EXPIRED: "bg-gray-200 text-gray-600",
  REFUNDED: "bg-violet-100 text-violet-700",
  PARTIALLY_REFUNDED: "bg-violet-100 text-violet-700",
  // invoices
  COMPLETED: "bg-emerald-100 text-emerald-700",
  CREATED: "bg-sky-100 text-sky-700",
  SENT: "bg-sky-100 text-sky-700",
  ACCEPTED: "bg-amber-100 text-amber-700",
  REJECTED: "bg-red-100 text-red-700",
  DRAFT: "bg-gray-200 text-gray-600",
  // subscriptions
  ACTIVE: "bg-emerald-100 text-emerald-700",
  TRIALING: "bg-sky-100 text-sky-700",
  TRIAL_PENDING: "bg-sky-100 text-sky-700",
  INACTIVE: "bg-gray-200 text-gray-600",
  FROZEN: "bg-amber-100 text-amber-700",
};

export const STATUS_AR: Record<string, string> = {
  SUCCEEDED: "ناجحة",
  SETTLED: "مسوّاة",
  PENDING: "معلّقة",
  PROCESSING: "قيد المعالجة",
  UNDER_REVIEW: "قيد المراجعة",
  FAILED: "فاشلة",
  FAILED_INITIATION: "فشل البدء",
  CANCELED: "ملغاة",
  EXPIRED: "منتهية",
  REFUNDED: "مسترجعة",
  PARTIALLY_REFUNDED: "مسترجعة جزئياً",
  COMPLETED: "مكتملة",
  CREATED: "أُنشئت",
  SENT: "مرسلة",
  ACCEPTED: "مقبولة",
  REJECTED: "مرفوضة",
  DRAFT: "مسودة",
  ACTIVE: "نشط",
  TRIALING: "تجريبي",
  TRIAL_PENDING: "تجربة معلّقة",
  INACTIVE: "غير نشط",
  FROZEN: "مجمّد",
};

export function StatusBadge({ status }: { status?: string | null }) {
  if (!status) return <span className="text-muted-foreground">—</span>;
  const tone = TONES[status] ?? "bg-gray-100 text-gray-700";
  return (
    <span className={`inline-block px-2 py-0.5 rounded-md text-[11px] font-bold whitespace-nowrap ${tone}`} title={status}>
      {STATUS_AR[status] ?? status}
    </span>
  );
}

export function StatCard({ label, value, hint, tone = "text-foreground" }: { label: string; value: string; hint?: string; tone?: string }) {
  return (
    <div className="rounded-2xl bg-white border border-border p-5">
      <div className="text-xs font-bold text-muted-foreground mb-2">{label}</div>
      <div className={`text-2xl sm:text-3xl font-black leading-none ${tone}`}>{value}</div>
      {hint && <div className="text-[11px] text-muted-foreground mt-2">{hint}</div>}
    </div>
  );
}

export function DashboardLink({ href, label = "فتح في Stream" }: { href: string; label?: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="inline-flex items-center gap-1 text-xs font-bold text-primary hover:underline whitespace-nowrap"
    >
      <ExternalLink className="w-3.5 h-3.5" />
      {label}
    </a>
  );
}

export function Mono({ children }: { children: React.ReactNode }) {
  return (
    <span className="font-mono text-[11px] text-muted-foreground" dir="ltr">
      {children}
    </span>
  );
}

export function shortId(id?: string | null) {
  if (!id) return "—";
  return id.length > 12 ? `${id.slice(0, 8)}…` : id;
}

export function Table({ head, children, empty }: { head: string[]; children: React.ReactNode; empty: boolean }) {
  return (
    <div className="rounded-2xl bg-white border border-border overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-[#fafafa] text-xs text-muted-foreground">
            <tr>
              {head.map((h) => (
                <th key={h} className="px-4 py-3 text-start font-bold whitespace-nowrap">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {empty ? (
              <tr>
                <td colSpan={head.length} className="px-4 py-10 text-center text-muted-foreground">
                  لا توجد نتائج مطابقة.
                </td>
              </tr>
            ) : (
              children
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function Pagination({
  pagination,
  basePath,
  params,
}: {
  pagination?: StreamPagination;
  basePath: string;
  params: Record<string, string | number | undefined>;
}) {
  const current = pagination?.current_page ?? 1;
  const max = pagination?.max_page ?? current;
  const link = (page: number) => {
    const q = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== "") q.set(k, String(v));
    q.set("page", String(page));
    return `${basePath}?${q.toString()}`;
  };
  const btn = "inline-flex items-center px-3 py-1.5 rounded-lg border border-border text-xs font-bold hover:bg-secondary transition";
  const disabled = "opacity-40 pointer-events-none";
  return (
    <div className="flex items-center justify-between gap-3 mt-4 text-xs text-muted-foreground">
      <span>
        صفحة {current} من {max}
        {pagination?.limit ? ` • ${pagination.limit} لكل صفحة` : ""}
      </span>
      <div className="flex items-center gap-2">
        <Link href={link(current - 1)} className={`${btn} ${pagination?.has_previous_page ? "" : disabled}`} aria-disabled={!pagination?.has_previous_page}>
          السابق
        </Link>
        <Link href={link(current + 1)} className={`${btn} ${pagination?.has_next_page ? "" : disabled}`} aria-disabled={!pagination?.has_next_page}>
          التالي
        </Link>
      </div>
    </div>
  );
}

export function ErrorNotice({ message }: { message: string }) {
  return (
    <div className="rounded-2xl border border-red-200 bg-red-50 text-red-800 px-5 py-4 text-sm">
      <div className="font-bold mb-1">تعذّر جلب البيانات من Stream</div>
      <div className="text-xs" dir="ltr">
        {message}
      </div>
    </div>
  );
}
