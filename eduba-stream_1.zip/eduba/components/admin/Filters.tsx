import Link from "next/link";
import type { AdminListFilters } from "@/lib/stream/admin";
import { PAGE_SIZES } from "@/lib/stream/admin";
import { STATUS_AR } from "./ui";

/**
 * GET form: every filter lives in the URL, so views are shareable and the
 * server component re-fetches from Stream on each change.
 */
export function Filters({
  basePath,
  filters,
  statuses,
  showDates = true,
  searchPlaceholder = "بحث بالاسم أو الجوال أو البريد",
}: {
  basePath: string;
  filters: AdminListFilters;
  statuses?: readonly string[];
  showDates?: boolean;
  searchPlaceholder?: string;
}) {
  const input = "rounded-lg border border-input bg-white px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30";
  return (
    <form method="get" action={basePath} className="rounded-2xl bg-white border border-border p-4 mb-4">
      <div className="flex flex-wrap items-end gap-3">
        <label className="flex flex-col gap-1 text-xs font-bold text-muted-foreground grow min-w-[200px]">
          بحث
          <input type="search" name="q" defaultValue={filters.q} placeholder={searchPlaceholder} className={input} />
        </label>
        {showDates && (
          <>
            <label className="flex flex-col gap-1 text-xs font-bold text-muted-foreground">
              من تاريخ
              <input type="date" name="from" defaultValue={filters.from} className={input} dir="ltr" />
            </label>
            <label className="flex flex-col gap-1 text-xs font-bold text-muted-foreground">
              إلى تاريخ
              <input type="date" name="to" defaultValue={filters.to} className={input} dir="ltr" />
            </label>
          </>
        )}
        {statuses && (
          <label className="flex flex-col gap-1 text-xs font-bold text-muted-foreground">
            الحالة
            <select name="status" defaultValue={filters.status} className={input}>
              <option value="">الكل</option>
              {statuses.map((s) => (
                <option key={s} value={s}>
                  {STATUS_AR[s] ?? s}
                </option>
              ))}
            </select>
          </label>
        )}
        <label className="flex flex-col gap-1 text-xs font-bold text-muted-foreground">
          لكل صفحة
          <select name="limit" defaultValue={String(filters.limit)} className={input}>
            {PAGE_SIZES.map((n) => (
              <option key={n} value={n}>
                {n}
              </option>
            ))}
          </select>
        </label>
        {filters.consumerId && <input type="hidden" name="consumer" value={filters.consumerId} />}
        <button type="submit" className="px-4 py-2 rounded-lg bg-primary text-white text-sm font-bold hover:opacity-95 transition">
          تطبيق
        </button>
        <Link href={basePath} className="px-3 py-2 text-sm font-bold text-muted-foreground hover:text-foreground">
          مسح
        </Link>
      </div>
      {filters.consumerId && (
        <div className="mt-3 text-xs text-muted-foreground">
          مفلتر حسب العميل <span className="font-mono" dir="ltr">{filters.consumerId}</span>
        </div>
      )}
    </form>
  );
}
