"use client";

import { useEffect, useState } from "react";
import { CheckCircle2, XCircle } from "lucide-react";

export interface ToastDetail {
  ok: boolean;
  message: string;
}

export const ADMIN_TOAST_EVENT = "eduba:admin-toast";

export function pushAdminToast(detail: ToastDetail) {
  if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent<ToastDetail>(ADMIN_TOAST_EVENT, { detail }));
}

/** Page-level notifications for admin actions (survive the row/dialog that triggered them being re-rendered away). */
export function AdminToaster() {
  const [toasts, setToasts] = useState<Array<ToastDetail & { id: number }>>([]);

  useEffect(() => {
    const onToast = (e: Event) => {
      const detail = (e as CustomEvent<ToastDetail>).detail;
      const id = Date.now() + Math.random();
      setToasts((t) => [...t, { ...detail, id }]);
      setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 6000);
    };
    window.addEventListener(ADMIN_TOAST_EVENT, onToast);
    return () => window.removeEventListener(ADMIN_TOAST_EVENT, onToast);
  }, []);

  if (toasts.length === 0) return null;
  return (
    <div className="fixed bottom-4 start-4 z-[200] space-y-2 w-[min(92vw,380px)]" role="status" aria-live="polite">
      {toasts.map((t) => (
        <div
          key={t.id}
          data-testid="admin-toast"
          className={`flex items-start gap-2 rounded-xl border px-4 py-3 text-sm shadow-lg bg-white ${t.ok ? "border-emerald-200 text-emerald-800" : "border-red-200 text-red-800"}`}
        >
          {t.ok ? <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" /> : <XCircle className="w-4 h-4 mt-0.5 shrink-0" />}
          <span>{t.message}</span>
        </div>
      ))}
    </div>
  );
}
