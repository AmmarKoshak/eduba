"use client";

import { useActionState } from "react";
import { Loader2, Lock } from "lucide-react";
import { startCheckout, type StartCheckoutState } from "@/app/checkout/actions";
import { inputClass, primaryButtonClass } from "@/components/ui/classes";
import { StreamEmbed } from "./StreamEmbed";

export function CheckoutForm({
  productKey,
  defaults,
  embedScriptUrl,
}: {
  productKey: string;
  defaults: { name?: string | null; email?: string | null; phone?: string | null };
  embedScriptUrl: string;
}) {
  const [state, action, pending] = useActionState<StartCheckoutState | null, FormData>(startCheckout, null);

  if (state?.ok && state.paymentLinkUrl) {
    return (
      <div>
        <div className="mb-5 flex items-center gap-2 text-sm text-emerald-700 bg-emerald-50 border border-emerald-100 rounded-xl px-4 py-3">
          <Lock className="w-4 h-4" />
          تم تجهيز طلبك. أكمل الدفع أدناه.
        </div>
        <StreamEmbed paymentLink={state.paymentLinkUrl} scriptUrl={embedScriptUrl} />
      </div>
    );
  }

  return (
    <form action={action} className="space-y-4" noValidate>
      <input type="hidden" name="productKey" value={productKey} />

      <div>
        <label htmlFor="name" className="block text-sm font-bold text-foreground mb-1.5">
          الاسم الكامل
        </label>
        <input id="name" name="name" required autoComplete="name" defaultValue={defaults.name ?? ""} className={inputClass} placeholder="مثال: أحمد العلي" />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label htmlFor="phone" className="block text-sm font-bold text-foreground mb-1.5">
            رقم الجوال
          </label>
          <input
            id="phone"
            name="phone"
            type="tel"
            inputMode="tel"
            dir="ltr"
            required
            autoComplete="tel"
            defaultValue={defaults.phone ?? ""}
            className={`${inputClass} text-left`}
            placeholder="05xxxxxxxx"
          />
        </div>
        <div>
          <label htmlFor="email" className="block text-sm font-bold text-foreground mb-1.5">
            البريد الإلكتروني
          </label>
          <input
            id="email"
            name="email"
            type="email"
            dir="ltr"
            required
            autoComplete="email"
            defaultValue={defaults.email ?? ""}
            className={`${inputClass} text-left`}
            placeholder="name@example.com"
          />
        </div>
      </div>

      {state && !state.ok && state.error && (
        <div className="text-sm text-red-700 bg-red-50 border border-red-100 rounded-xl px-4 py-3">{state.error}</div>
      )}

      <button type="submit" disabled={pending} className={`${primaryButtonClass} w-full`}>
        {pending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
        {pending ? "جارٍ تجهيز الدفع…" : "متابعة إلى الدفع الآمن"}
      </button>

      <p className="text-[11px] sm:text-xs text-muted-foreground text-center leading-relaxed">
        بالمتابعة توافق على شروط الاستخدام. يمكنك إلغاء الاشتراك في أي وقت من حسابك.
      </p>
    </form>
  );
}
