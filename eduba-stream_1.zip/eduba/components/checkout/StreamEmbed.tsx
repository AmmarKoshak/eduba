"use client";

import { useEffect, useRef, useState } from "react";
import Script from "next/script";
import { ExternalLink, Loader2 } from "lucide-react";

interface StreamCheckoutHandle {
  destroy?: () => void;
  getIframe?: () => HTMLIFrameElement;
}

declare global {
  interface Window {
    Stream?: {
      Checkout: (opts: {
        paymentLink: string;
        container: string | HTMLElement;
        minHeightPx?: number;
        maxHeightPx?: number;
        vhCapPx?: number;
        vhFraction?: number;
      }) => StreamCheckoutHandle | void;
    };
  }
}

/**
 * Renders Stream's hosted checkout inside the page with the official embed
 * script, plus a fallback link that opens the same checkout in a new tab
 * (used when the script is blocked, slow, or the wallet needs a top-level page).
 */
export function StreamEmbed({ paymentLink, scriptUrl }: { paymentLink: string; scriptUrl: string }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const handle = useRef<StreamCheckoutHandle | null>(null);
  const mounted = useRef(false);
  const [state, setState] = useState<"loading" | "ready" | "error">("loading");

  const mount = () => {
    if (mounted.current || !containerRef.current || !window.Stream?.Checkout) return;
    try {
      // The SDK injects an <iframe allow="payment *"> and, when the payer finishes,
      // navigates the top window to our success/failure redirect URL.
      const h = window.Stream.Checkout({
        paymentLink,
        container: containerRef.current,
        minHeightPx: 520,
        maxHeightPx: 980,
      });
      handle.current = h ?? null;
      mounted.current = true;
      setState("ready");
    } catch (err) {
      console.error("Stream.Checkout failed", err);
      setState("error");
    }
  };

  useEffect(() => {
    // The script may already be cached from a previous visit.
    mount();
    const timeout = window.setTimeout(() => {
      if (!mounted.current) setState((s) => (s === "loading" ? "error" : s));
    }, 15000);
    return () => {
      window.clearTimeout(timeout);
      handle.current?.destroy?.();
      handle.current = null;
      mounted.current = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paymentLink]);

  return (
    <div className="space-y-4">
      <Script src={scriptUrl} strategy="afterInteractive" onLoad={mount} onError={() => setState("error")} />

      <div className="relative rounded-2xl border border-border bg-white overflow-hidden min-h-[520px]">
        {state === "loading" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-muted-foreground text-sm">
            <Loader2 className="w-6 h-6 animate-spin text-primary" />
            جارٍ تحميل صفحة الدفع الآمنة…
          </div>
        )}
        {state === "error" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center text-sm text-muted-foreground">
            <p>تعذّر عرض صفحة الدفع داخل الموقع.</p>
            <p>يمكنك إكمال الدفع بأمان من خلال الرابط أدناه.</p>
          </div>
        )}
        <div ref={containerRef} id="stream-checkout" className="w-full" />
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs sm:text-sm text-muted-foreground">
        <span>الدفع يتم عبر منصة Stream الآمنة. لن نحتفظ ببيانات بطاقتك.</span>
        <a
          href={paymentLink}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1.5 font-bold text-primary hover:underline"
        >
          <ExternalLink className="w-4 h-4" />
          افتح صفحة الدفع في نافذة جديدة
        </a>
      </div>
    </div>
  );
}
