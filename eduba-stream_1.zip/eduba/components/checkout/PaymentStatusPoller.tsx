"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";

/**
 * Shown while the invoice is not COMPLETED yet. Re-checks with the server
 * every few seconds and reloads the page once the payment is verified.
 */
export function PaymentStatusPoller({
  orderId,
  invoiceId,
  maxSeconds = 90,
}: {
  orderId: string;
  invoiceId?: string | null;
  maxSeconds?: number;
}) {
  const router = useRouter();
  const [elapsed, setElapsed] = useState(0);
  const [gaveUp, setGaveUp] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const started = Date.now();

    const tick = async () => {
      if (cancelled) return;
      try {
        const q = new URLSearchParams({ order: orderId });
        if (invoiceId) q.set("invoice_id", invoiceId);
        const res = await fetch(`/api/checkout/status?${q.toString()}`, { cache: "no-store" });
        const data = (await res.json()) as { state?: string };
        if (data.state === "paid" || data.state === "failed" || data.state === "mismatch") {
          router.refresh();
          return;
        }
      } catch {
        // network hiccup: keep polling
      }
      const secs = Math.round((Date.now() - started) / 1000);
      setElapsed(secs);
      if (secs >= maxSeconds) {
        setGaveUp(true);
        return;
      }
      window.setTimeout(tick, 3000);
    };

    const t = window.setTimeout(tick, 2000);
    return () => {
      cancelled = true;
      window.clearTimeout(t);
    };
  }, [orderId, invoiceId, maxSeconds, router]);

  if (gaveUp) {
    return (
      <div className="text-sm text-muted-foreground">
        لم نتمكن من تأكيد الدفع بعد. إذا تم خصم المبلغ، سيُفعَّل اشتراكك تلقائياً خلال دقائق وسيصلك تأكيد.
        <button type="button" onClick={() => router.refresh()} className="ms-2 font-bold text-primary hover:underline">
          تحديث
        </button>
      </div>
    );
  }

  return (
    <div className="inline-flex items-center gap-2 text-sm text-muted-foreground">
      <Loader2 className="w-4 h-4 animate-spin text-primary" />
      جارٍ تأكيد الدفع مع Stream… ({elapsed} ث)
    </div>
  );
}
