"use client";

import { useState } from "react";
import { Check, Copy, Share2 } from "lucide-react";

export function CopyLink({ value }: { value: string }) {
  const [copied, setCopied] = useState(false);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // older browsers: select the text so the user can copy manually
      const el = document.getElementById("referral-link") as HTMLInputElement | null;
      el?.select();
    }
  };

  const share = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title: "إيدوبا", text: "جرّب إيدوبا — معلم خصوصي ذكي متاح 24 ساعة", url: value });
      } catch {
        /* user cancelled */
      }
    } else {
      void copy();
    }
  };

  return (
    <div className="flex flex-col sm:flex-row gap-2">
      <input
        id="referral-link"
        readOnly
        value={value}
        dir="ltr"
        onFocus={(e) => e.currentTarget.select()}
        className="flex-1 rounded-xl border border-input bg-secondary/50 px-4 py-3 text-sm font-mono text-left text-foreground"
      />
      <button type="button" onClick={copy} className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-primary text-white text-sm font-bold hover:opacity-95 transition">
        {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
        {copied ? "تم النسخ" : "نسخ الرابط"}
      </button>
      <button type="button" onClick={share} className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl border-2 border-primary text-primary text-sm font-bold hover:bg-primary/5 transition">
        <Share2 className="w-4 h-4" />
        مشاركة
      </button>
    </div>
  );
}
