import Image from "next/image";
import Link from "next/link";
import { auth } from "@/auth";
import { MobileMenu } from "./MobileMenu";

export const NAV_LINKS = [
  { href: "/#students", label: "للطلاب" },
  { href: "/#parents", label: "للأهل" },
  { href: "/#pricing", label: "الأسعار" },
  { href: "/marketing-quiz", label: "اختبر نفسك مجاناً" },
];

/**
 * Site header. `variant="overlay"` floats over the blue hero (home page);
 * `variant="solid"` draws its own blue background for inner pages.
 */
export async function Header({ variant = "overlay" }: { variant?: "overlay" | "solid" }) {
  const session = await auth();
  const user = session?.user;

  return (
    <header
      className={
        variant === "overlay"
          ? "absolute top-0 inset-x-0 z-[100] pt-4 sm:pt-6"
          : "relative z-[100] bg-[#0a3aa8] py-4 sm:py-5"
      }
    >
      <div className="w-full px-6 sm:px-10 lg:px-14">
        <div className="flex items-center justify-between h-14 sm:h-16">
          <Link href="/" className="flex items-center gap-2 shrink-0">
            <Image
              src="/brand/eduba-mark.png"
              alt="Eduba"
              width={36}
              height={36}
              className="w-8 h-8 sm:w-9 sm:h-9 rounded-lg"
            />
            <span className="text-white font-normal text-lg sm:text-xl tracking-tight">إيدوبا</span>
          </Link>

          <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-white/85">
            {NAV_LINKS.map((l) => (
              <Link key={l.href} href={l.href} className="hover:text-white transition-colors">
                {l.label}
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-3">
            {user ? (
              <>
                {user.isAdmin && (
                  <Link
                    href="/admin"
                    className="inline-flex items-center px-5 py-2.5 rounded-full text-sm font-medium text-white border border-white/50 hover:bg-white/10 transition"
                  >
                    لوحة الإدارة
                  </Link>
                )}
                <Link
                  href="/account"
                  className="inline-flex items-center px-5 py-2.5 rounded-full bg-[#0a0a0a] text-white text-sm font-medium hover:bg-black transition"
                >
                  حسابي
                </Link>
              </>
            ) : (
              <>
                <Link
                  href="/sign-in"
                  className="inline-flex items-center px-5 py-2.5 rounded-full text-sm font-medium text-white border border-white/50 hover:bg-white/10 transition"
                >
                  تسجيل الدخول
                </Link>
                <Link
                  href="/role-select"
                  className="inline-flex items-center px-5 py-2.5 rounded-full bg-[#0a0a0a] text-white text-sm font-medium hover:bg-black transition"
                >
                  ابدأ رحلتك الآن
                </Link>
              </>
            )}
          </div>

          <MobileMenu loggedIn={!!user} isAdmin={user?.isAdmin === true} />
        </div>
      </div>
    </header>
  );
}
