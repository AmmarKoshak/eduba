import Image from "next/image";
import Link from "next/link";

export function Footer() {
  return (
    <footer className="bg-[#121212] text-white">
      <div className="mx-auto w-[min(94%,1200px)] px-2 py-10 sm:py-14">
        <div className="flex flex-col items-start gap-3 text-start">
          <Link href="/" className="flex items-center gap-3">
            <span className="text-xl sm:text-2xl font-bold tracking-tight">إيدوبا</span>
            <Image
              src="/brand/eduba-mark.png"
              alt="Eduba"
              width={40}
              height={40}
              className="w-9 h-9 rounded-lg"
            />
          </Link>
          <p className="text-sm text-white/55">المعلم الذكي للطالب السعودي</p>
        </div>
        <div className="my-8 sm:my-10 border-t border-white/10" />
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs sm:text-sm text-white/55">
          <p>© {new Date().getFullYear()} إيدوبا. جميع الحقوق محفوظة.</p>
          <p>
            صنع بـ <span aria-hidden="true">❤️</span> في المملكة العربية السعودية
          </p>
        </div>
      </div>
    </footer>
  );
}
