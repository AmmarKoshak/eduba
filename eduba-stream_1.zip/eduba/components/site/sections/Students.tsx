import Image from "next/image";

function StepText({ n, title, text }: { n: number; title: string; text: string }) {
  return (
    <div className="text-center lg:text-start">
      <div className="mb-5 flex justify-center lg:justify-start">
        <span
          className="inline-flex w-12 h-12 rounded-full bg-primary/10 text-primary font-bold items-center justify-center"
          style={{ fontSize: 21 }}
        >
          {n}
        </span>
      </div>
      <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold text-foreground mb-3">{title}</h3>
      <p className="text-base sm:text-lg text-muted-foreground leading-relaxed max-w-md mx-auto lg:mx-0">{text}</p>
    </div>
  );
}

function RobotAvatar() {
  return (
    <div
      className="rounded-lg bg-primary overflow-hidden flex items-center justify-center shrink-0"
      style={{ width: 34, height: 34 }}
    >
      <Image
        src="/landing/mascots/robot-curious.png"
        alt=""
        width={34}
        height={34}
        className="w-full h-full object-contain"
      />
    </div>
  );
}

export function Students() {
  return (
    <section id="students" className="py-16 sm:py-20 lg:py-24 bg-background">
      <div className="mx-auto w-[min(92%,1100px)]">
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="text-xs sm:text-sm font-bold text-primary mb-3">للطلاب</div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-foreground">
            ادرس بطريقتك. اكسب وتحدّ أصدقاءك.
          </h2>
        </div>

        <div className="space-y-20 sm:space-y-24">
          {/* 1 — Smart tutor chat */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div className="order-1 lg:order-2">
              <div className="relative max-w-md mx-auto">
                <div className="rounded-3xl bg-white border border-border shadow-[0_24px_50px_-30px_rgba(15,32,80,0.18)] p-5 sm:p-6">
                  <div className="flex items-center gap-3 pb-4 mb-4 -mx-5 sm:-mx-6 px-5 sm:px-6 border-b border-border">
                    <RobotAvatar />
                    <span className="text-xl sm:text-2xl font-bold text-foreground">إيبو: المعلم الذكي</span>
                  </div>
                  <div className="bg-secondary rounded-2xl rounded-es-none px-4 py-3 text-sm text-foreground mb-3">
                    لا أفهم كيف تشغل كثافة المادة؟
                  </div>
                  <div className="relative">
                    <div className="bg-primary text-primary-foreground rounded-2xl rounded-ee-none px-4 py-3 text-sm font-medium leading-relaxed max-w-[88%] me-auto">
                      سؤال ممتاز! إذا وضعت كيلوغرام من القطن وكيلوغرام من الحديد، أيهما أثقل؟ 🤔
                    </div>
                    <div className="absolute -bottom-1 end-0">
                      <RobotAvatar />
                    </div>
                  </div>
                  <div className="text-center text-xs text-muted-foreground mt-6">مثل أفضل معلم صادفته</div>
                </div>
              </div>
            </div>
            <div className="order-2 lg:order-1">
              <StepText n={1} title="المعلم الذكي يسألك أولاً" text="يوجّهك حتى تصل للإجابات بنفسك، مثل أفضل معلم صادفته." />
            </div>
          </div>

          {/* 2 — Adaptive tests */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div className="order-1 lg:order-1">
              <div className="relative mx-auto w-[min(100%,330px)]">
                <div
                  className="absolute -top-14 z-0 pointer-events-none start-[-20px] sm:start-[-98px]"
                  style={{ width: 131, height: 131 }}
                >
                  <Image
                    src="/landing/mascots/robot-winking.png"
                    alt=""
                    width={131}
                    height={131}
                    className="w-full h-full object-contain drop-shadow-[0_10px_15px_rgba(15,32,80,0.2)]"
                  />
                </div>
                <div
                  className="relative z-10 rounded-3xl bg-white border border-border shadow-[0_24px_50px_-30px_rgba(15,32,80,0.18)] p-6 flex flex-col"
                  style={{ height: 321 }}
                >
                  <div className="flex items-baseline gap-2 mb-3">
                    <span className="text-sm font-bold text-foreground">اختبار الرياضيات</span>
                    <span className="ms-auto text-xs text-muted-foreground">يتكيف مع مستواك</span>
                  </div>
                  <div className="flex-1 flex flex-col justify-center gap-3">
                    <div className="text-start">
                      <span className="font-black text-emerald-500 leading-none block" style={{ fontSize: 67 }}>
                        87
                      </span>
                      <span className="text-muted-foreground block mt-1" style={{ fontSize: 17 }}>
                        من 100
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-secondary overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-emerald-600 to-emerald-400" style={{ width: "87%" }} />
                    </div>
                  </div>
                  <div className="text-sm text-emerald-600 font-bold text-center">تحسن عن الأسبوع الماضي +12 نقطة</div>
                </div>
              </div>
            </div>
            <div className="order-2 lg:order-2">
              <StepText n={2} title="اختبارات تتطور معك" text="اختبارات لكل مادة تتكيّف مع مستواك، كلما تحسّنت، يرتفع مستوى التحدي." />
            </div>
          </div>

          {/* 3 — Challenges */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
            <div className="order-1 lg:order-2">
              <div className="relative max-w-md mx-auto">
                <div className="rounded-3xl bg-white border border-border shadow-[0_24px_50px_-30px_rgba(15,32,80,0.18)] p-6 sm:p-7">
                  <div className="text-center mb-5">
                    <div className="text-base sm:text-lg font-bold text-foreground">نتيجة التحدّي</div>
                    <div className="text-[11px] sm:text-xs text-muted-foreground mt-1">
                      اختبار مادة الرياضيات - الصف الأول الابتدائي
                    </div>
                  </div>
                  <div className="flex items-center justify-center gap-5 mb-5">
                    <div className="text-center">
                      <div className="w-16 h-16 rounded-full bg-secondary text-foreground flex items-center justify-center text-base font-black mb-1.5">
                        48%
                      </div>
                      <div className="text-xs text-muted-foreground">أنت</div>
                    </div>
                    <div className="text-muted-foreground/50 font-bold text-sm">VS</div>
                    <div className="text-center">
                      <div className="w-16 h-16 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-base font-black mb-1.5 shadow-lg shadow-primary/30">
                        79%
                      </div>
                      <div className="text-xs text-muted-foreground">ساره</div>
                    </div>
                  </div>
                  <div className="rounded-2xl bg-secondary px-3 py-2.5 text-xs sm:text-sm text-center text-foreground mb-3 flex items-center justify-center gap-2">
                    <span>💪</span>
                    <span>حاول مرة أخرى، يمكنك التفوق!</span>
                  </div>
                  <button type="button" className="w-full rounded-2xl border-2 border-primary text-primary font-bold py-3 text-sm">
                    العودة للإختبارات
                  </button>
                  <div className="flex items-center justify-between gap-2 mt-3 text-[11px] sm:text-xs">
                    <span className="text-muted-foreground">الخطة المجانية: 3 تحديات.</span>
                    <span className="text-muted-foreground">
                      <span className="text-primary font-bold">إيدوبا Pro</span> غير محدود.
                    </span>
                  </div>
                </div>

                <div
                  className="absolute -top-4 -start-3 sm:-start-6 rotate-[-6deg] bg-amber-50 border border-amber-200 rounded-xl px-2 py-1.5 text-[10px] shadow-md flex flex-col justify-center"
                  style={{ width: 88, height: 70 }}
                >
                  <div className="font-bold text-amber-700 flex items-center gap-1 leading-tight">
                    <span>🎯</span>بداية موفقة
                  </div>
                  <div className="text-amber-700/70 text-[9px] leading-tight mt-0.5">أكمل أول اختبار</div>
                </div>
                <div
                  className="absolute top-[35%] -end-3 sm:-end-6 rotate-[6deg] rounded-xl px-2 py-1.5 text-[10px] shadow-md flex flex-col justify-center"
                  style={{ width: 88, height: 61, backgroundColor: "#F9FAFB", border: "1px solid #E5E7EB" }}
                >
                  <div className="font-bold text-foreground flex items-center gap-1 leading-tight">
                    <span>🔥</span>ملك التحديات
                  </div>
                  <div className="text-muted-foreground text-[9px] leading-tight mt-0.5">فز في 5 تحديات</div>
                </div>
              </div>
            </div>
            <div className="order-2 lg:order-1">
              <StepText n={3} title="نافس وتحدّى، وأثبت أنك الأفضل!" text="تحدّى الطلاب وتنافس معهم، وخلّي الدراسة تصبح منافسة." />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
