import Image from "next/image";
import Link from "next/link";
import { Check } from "lucide-react";
import { PRO_PRICE_SAR } from "@/lib/products";

const ROWS = [
  { label: "التكلفة", tutor: "800-3,000 ريال / شهر لكل مادة", eduba: `${PRO_PRICE_SAR} ريال / شهر لجميع المواد` },
  { label: "الوقت", tutor: "ساعتان أسبوعياً فقط", eduba: "متاح 24/7 في أي وقت" },
  { label: "رؤية الأهل", tutor: "محدودة", eduba: "لوحة تحكم كاملة فورية" },
  { label: "التخصيص", tutor: "شرح موحد لجميع الطلاب", eduba: "يتكيّف مع أسلوب كل طالب" },
  { label: "اكتشاف الثغرات", tutor: "بعد الاختبار", eduba: "يرصدها فور حدوثها" },
];

export function Problem() {
  return (
    <section className="relative isolate -mt-[280px] sm:-mt-[340px] lg:-mt-[400px] pt-[80px] sm:pt-[100px] lg:pt-[110px] pb-16 sm:pb-20 lg:pb-24 overflow-hidden">
      <div
        aria-hidden="true"
        className="absolute inset-0 z-0 bg-[linear-gradient(to_bottom,#0661EC_0px,#0661EC_200px,#f9fafb_400px)]"
      />
      <div className="relative z-10 mx-auto w-[min(92%,820px)]">
        <div className="text-center text-xs sm:text-sm font-bold tracking-wide text-white/90 mb-3">المشكلة</div>
        <h2 className="text-center text-2xl sm:text-3xl lg:text-4xl font-bold leading-snug tracking-tight text-white mb-10 sm:mb-14">
          لماذا تدفع أكثر وتتعرف أقل؟
        </h2>

        <div className="bg-white rounded-3xl shadow-[0_30px_60px_-30px_rgba(15,32,80,0.18)] overflow-hidden mx-auto w-full max-w-[600px]">
          <div className="grid grid-cols-2">
            <div className="px-4 sm:px-6 py-5 sm:py-6 text-center bg-[#fafafa]">
              <span className="text-foreground font-bold">المدرس الخصوصي التقليدي</span>
            </div>
            <div className="px-4 sm:px-6 py-5 sm:py-6 text-center bg-[#fafafa] border-s border-border">
              <span className="inline-flex items-center gap-2">
                <Image src="/brand/eduba-mark.png" alt="" width={22} height={22} className="rounded" />
                <span className="text-foreground font-bold">إيدوبا</span>
              </span>
            </div>

            {ROWS.map((row) => (
              <RowPair key={row.label} {...row} />
            ))}
          </div>
        </div>

        <div className="flex justify-center mt-8 sm:mt-10">
          <Link
            href="/role-select"
            className="inline-flex items-center justify-center px-7 py-3.5 rounded-full bg-primary text-primary-foreground font-bold text-sm sm:text-base shadow-lg shadow-primary/25 hover:opacity-95 transition"
          >
            جرّب إيدوبا مجاناً
          </Link>
        </div>
      </div>
    </section>
  );
}

function RowPair({ label, tutor, eduba }: { label: string; tutor: string; eduba: string }) {
  return (
    <>
      <div className="px-4 sm:px-6 py-4 sm:py-5 bg-white">
        <div className="text-xs sm:text-sm font-bold text-muted-foreground/70 mb-2">{label}</div>
        <div className="text-sm sm:text-base text-muted-foreground">{tutor}</div>
      </div>
      <div className="px-4 sm:px-6 py-4 sm:py-5 bg-white border-s border-border">
        <div className="text-xs sm:text-sm font-bold text-primary/80 mb-2">{label}</div>
        <div className="flex items-start gap-2 sm:gap-3 text-sm sm:text-base">
          <span className="shrink-0 mt-0.5 inline-flex w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 items-center justify-center">
            <Check className="w-3 h-3" strokeWidth={3} />
          </span>
          <span className="text-foreground">{eduba}</span>
        </div>
      </div>
    </>
  );
}
