import Image from "next/image";
import Link from "next/link";
import { GraduationCap, School, Sparkles, User } from "lucide-react";

const BADGES = ["المنهج السعودي", "جميع المراحل", "بدون إعلانات", "آمنة بالكامل"];

export function Hero() {
  return (
    <section className="relative z-0 overflow-hidden text-white pt-28 sm:pt-32 lg:pt-32 pb-16 lg:pb-32 lg:min-h-[1320px] bg-[#0a3aa8] flex items-center">
      <div className="absolute inset-0 z-0">
        <Image src="/landing/hero/bg.png" alt="" fill priority sizes="100vw" className="object-cover" />
      </div>

      <div className="relative z-10 ms-[3%] lg:ms-[calc(3%+100px)] me-auto w-[min(94%,1240px)] grid lg:grid-cols-[1.4fr_1fr] gap-10 lg:gap-12 items-center lg:-translate-y-[150px]">
        <div className="text-center lg:text-start space-y-6 lg:space-y-7 order-2 lg:order-1 lg:me-[-150px] relative z-20 pointer-events-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 border border-white/20 backdrop-blur text-xs sm:text-sm font-semibold">
            <Sparkles className="w-4 h-4 text-amber-300" />
            مستقبل التعليم بين يديك
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold leading-[1.2] tracking-tight">
            أذكى من المدرس الخصوصي وموجود معك 24 ساعة
          </h1>
          <p className="text-base sm:text-lg text-white/85 leading-relaxed max-w-xl mx-auto lg:mx-0">
            إيدوبا تفهم مستواك وتصمم لك رحلة ممتعة تطور مستواك فيها، منصة ذكية تشرح، تختبر، وتتابع تقدمك
            في جميع مواد وزارة التربية والتعليم.
          </p>

          <div className="flex flex-col sm:flex-row gap-2.5 justify-center lg:justify-start relative z-30">
            <Link
              href="/sign-up?role=parent"
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-[#0a0a0a] text-white text-sm font-semibold whitespace-nowrap hover:bg-black transition cursor-pointer active:scale-95 shadow-md"
            >
              <User className="w-4 h-4 shrink-0" strokeWidth={2.25} />
              ولي أمر؟ سجّل مجاناً
            </Link>
            <Link
              href="/sign-up?role=student"
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-white text-[#0a3aa8] text-sm font-semibold whitespace-nowrap hover:bg-white/90 transition cursor-pointer active:scale-95 shadow-md"
            >
              <GraduationCap className="w-4 h-4 shrink-0" strokeWidth={2.25} />
              طالب؟ ابدأ الآن
            </Link>
            <Link
              href="/marketing-quiz"
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full border-2 border-white/40 bg-white/15 text-white text-sm font-bold whitespace-nowrap hover:bg-white/30 hover:border-white/70 transition cursor-pointer active:scale-95 shadow-md backdrop-blur-sm"
            >
              <Sparkles className="w-4 h-4 shrink-0 text-amber-300" strokeWidth={2.25} />
              جرب اختباراً سريعاً
            </Link>
            <Link
              href="/partner-school"
              className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-white text-[#0a3aa8] text-sm font-semibold whitespace-nowrap hover:bg-white/90 transition cursor-pointer active:scale-95 shadow-md"
            >
              <School className="w-4 h-4 shrink-0" strokeWidth={2.25} />
              طالب في مدرسة شريكة
            </Link>
          </div>

          <div className="flex flex-wrap items-center gap-2 justify-center lg:justify-start pt-2">
            {BADGES.map((b) => (
              <span
                key={b}
                className="inline-block px-3 py-1.5 rounded-full bg-white/10 border border-white/15 text-xs sm:text-sm text-white/80 backdrop-blur"
              >
                {b}
              </span>
            ))}
          </div>
        </div>

        <div className="relative order-1 lg:order-2 pointer-events-none">
          <div className="relative aspect-square max-w-lg sm:max-w-xl lg:max-w-none mx-auto lg:-translate-x-[80%] lg:-translate-y-[20%] lg:scale-[4] lg:origin-center transform-gpu pointer-events-none">
            <div
              className="relative w-full h-full"
              style={{
                transform: "rotateY(180deg)",
                maskImage: "linear-gradient(to bottom, black 50%, transparent 100%)",
                WebkitMaskImage: "linear-gradient(to bottom, black 50%, transparent 100%)",
              }}
            >
              <Image
                src="/landing/hero/mascots.png"
                alt=""
                fill
                priority
                sizes="(max-width: 1024px) 90vw, 55vw"
                className="object-contain drop-shadow-[0_30px_60px_rgba(0,0,0,0.35)]"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
