import Link from "next/link";
import { Check, X } from "lucide-react";
import { PRO_PRICE_SAR } from "@/lib/products";

const BASIC = [
  { text: "30 رسالة مع المعلّم الذكي", ok: true },
  { text: "اختبار واحد لكل مادة", ok: true },
  { text: "3 تحديات مع الأصدقاء", ok: true },
  { text: "حساب الأهل الكامل", ok: true },
  { text: "تحليلات الذكاء الاصطناعي للطالب", ok: false },
  { text: "وصول غير محدود", ok: false },
];

const PRO = [
  "رسائل غير محدودة مع المعلّم الذكي",
  "جميع الاختبارات بلا حدود",
  "تحديات غير محدودة",
  "حساب الأهل الكامل",
  "تحليلات ذكاء اصطناعي متقدمة للطالب",
];

function Tick({ ok }: { ok: boolean }) {
  return ok ? (
    <span className="shrink-0 mt-0.5 inline-flex w-5 h-5 rounded-full bg-emerald-100 text-emerald-600 items-center justify-center">
      <Check className="w-3 h-3" strokeWidth={3} />
    </span>
  ) : (
    <span className="shrink-0 mt-0.5 inline-flex w-5 h-5 rounded-full bg-gray-200 text-gray-400 items-center justify-center">
      <X className="w-3 h-3" strokeWidth={3} />
    </span>
  );
}

export function Pricing() {
  return (
    <section id="pricing" className="py-16 sm:py-20 lg:py-24 bg-background">
      <div className="mx-auto w-[min(92%,1100px)]">
        <div className="text-center max-w-3xl mx-auto mb-8 sm:mb-10">
          <div className="text-xs sm:text-sm font-bold text-primary mb-3">الأسعار</div>
          <div className="rounded-2xl bg-white border border-border px-4 sm:px-6 py-3 sm:py-4 text-xs sm:text-sm text-muted-foreground leading-relaxed">
            <span>المدرس الخصوصي التقليدي: </span>
            <span className="text-red-500 font-bold">من 800 ريال/شهر لمادة واحدة فقط.</span>
            <span className="mx-2">•</span>
            <span>إيدوبا Pro </span>
            <span className="text-emerald-500 font-bold">{PRO_PRICE_SAR} ريال/شهر لجميع المواد.</span>
          </div>
        </div>

        <div className="flex overflow-x-auto snap-x snap-mandatory gap-5 sm:gap-6 pb-2 items-stretch lg:grid lg:grid-cols-2 lg:overflow-visible lg:pb-0">
          <article className="rounded-3xl bg-white border border-border p-6 sm:p-8 order-1 lg:order-1 shrink-0 w-[85%] sm:w-[380px] lg:w-full snap-center">
            <div className="text-sm font-bold text-muted-foreground mb-3 mt-1 text-start">الخطة الأساسية</div>
            <div className="text-start mb-6">
              <div className="text-5xl sm:text-6xl font-black text-foreground leading-none">0</div>
              <div className="text-sm text-muted-foreground mt-2">ريال/شهر</div>
            </div>
            <ul className="space-y-3 mb-7">
              {BASIC.map((f) => (
                <li key={f.text} className="flex items-start gap-3 text-sm">
                  <span className={f.ok ? "text-foreground flex-1 text-start" : "text-muted-foreground/60 line-through flex-1 text-start"}>
                    {f.text}
                  </span>
                  <Tick ok={f.ok} />
                </li>
              ))}
            </ul>
            <Link
              href="/role-select?plan=free"
              className="block text-center w-full px-5 py-3 rounded-xl border-2 border-primary text-primary font-bold text-sm sm:text-base hover:bg-primary/5 transition"
            >
              ابدأ مجاناً
            </Link>
          </article>

          <article className="relative rounded-3xl bg-white border-2 border-primary shadow-[0_30px_60px_-25px_rgba(37,99,235,0.4)] p-6 sm:p-8 order-2 lg:order-2 shrink-0 w-[85%] sm:w-[380px] lg:w-full snap-center">
            <div className="absolute -top-3 start-6 inline-block px-3 py-1 rounded-full text-white text-[11px] font-bold bg-emerald-500">
              الأكثر قيمة
            </div>
            <div className="text-sm font-bold text-muted-foreground mb-3 text-start">إيدوبا Pro</div>
            <div className="text-start mb-6">
              <div className="text-5xl sm:text-6xl font-black text-foreground leading-none">{PRO_PRICE_SAR}</div>
              <div className="text-sm text-muted-foreground mt-2">ريال/شهر</div>
            </div>
            <ul className="space-y-3 mb-7">
              {PRO.map((f) => (
                <li key={f} className="flex items-start gap-3 text-sm">
                  <span className="text-foreground flex-1 text-start">{f}</span>
                  <Tick ok />
                </li>
              ))}
            </ul>
            <Link
              href="/checkout?plan=pro_monthly"
              className="block text-center w-full px-5 py-3 rounded-xl text-white font-bold text-sm sm:text-base hover:opacity-95 transition bg-gradient-to-r from-[#1174FF] to-[#0A4699]"
            >
              اشترك في Pro
            </Link>
          </article>
        </div>
      </div>
    </section>
  );
}
