import Image from "next/image";
import Link from "next/link";
import { GraduationCap, User } from "lucide-react";

export function FinalCta() {
  return (
    <section className="py-12 sm:py-16 lg:py-20 bg-[#000201]">
      <div className="mx-auto w-[min(94%,1200px)]">
        <div className="relative isolate rounded-3xl overflow-hidden text-white bg-[#0a3aa8]">
          <div className="absolute inset-0 z-0">
            <Image src="/landing/hero/bg.png" alt="" fill sizes="100vw" className="object-cover" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#0a3aa8]/40 to-transparent" />
          </div>

          <div className="relative z-10 grid grid-cols-1 md:grid-cols-[1fr_minmax(360px,640px)] items-center gap-6 sm:gap-8 px-6 sm:px-10 py-10 sm:py-12 min-h-[260px]">
            <div className="text-center md:text-start order-1">
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight mb-3">ابدأ رحلة التعلّم اليوم</h2>
              <p className="text-sm sm:text-base text-white/85 mb-6 max-w-xl mx-auto md:mx-0">
                جرّب إيدوبا مجاناً أو اشترك في Pro. المعلم الذكي متاح الآن لك ولأبنائك.
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center md:justify-start">
                <Link
                  href="/sign-up?role=parent"
                  className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full bg-[#0c1426] text-white font-bold text-sm sm:text-base hover:bg-black transition"
                >
                  <User className="w-4 h-4" />
                  ولي أمر؟ سجّل مجاناً
                </Link>
                <Link
                  href="/sign-up?role=student"
                  className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full bg-white text-[#0a3aa8] font-bold text-sm sm:text-base hover:opacity-95 transition"
                >
                  <GraduationCap className="w-4 h-4" />
                  طالب؟ ابدأ الآن
                </Link>
              </div>
            </div>

            <div className="hidden md:block order-2 relative self-stretch -my-10 sm:-my-12 -me-6 sm:-me-10">
              <div
                className="absolute inset-0"
                style={{
                  maskImage: "linear-gradient(to bottom, black 70%, transparent 100%)",
                  WebkitMaskImage: "linear-gradient(to bottom, black 70%, transparent 100%)",
                }}
              >
                <Image
                  src="/landing/mascots/robot-cta.png"
                  alt=""
                  fill
                  sizes="640px"
                  className="object-contain object-left-bottom"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
