import { BrainCircuit, Clock, Coins, GraduationCap, Users, Wallet, type LucideIcon } from "lucide-react";

const FEATURES: Array<{ icon: LucideIcon; tone: string; title: string; text: string }> = [
  {
    icon: Clock,
    tone: "bg-sky-50 text-sky-500",
    title: "متاح 24/7",
    text: "مدرستك معك دائماً، يشرح لك في أي وقت صباحاً أو مساءً.",
  },
  {
    icon: BrainCircuit,
    tone: "bg-violet-50 text-violet-500",
    title: "يتكيّف مع أسلوبك",
    text: "يفهم الذكاء الاصطناعي طريقة تفكير كل طالب ويصمم بالأسلوب الأنسب له.",
  },
  {
    icon: Wallet,
    tone: "bg-blue-50 text-blue-500",
    title: "أوفر بكثير",
    text: "تعلم جميع المواد باشتراك رمزي، بدلًا من دفع مبالغ طائلة في دروس محدودة الوقت.",
  },
  {
    icon: Coins,
    tone: "bg-rose-50 text-rose-500",
    title: "نظام الإيدوينز",
    text: "يكسب الطلاب نقوداً رقمية مع كل تفاعل، ليحفزهم على الاستمرار والتفوّق.",
  },
  {
    icon: Users,
    tone: "bg-emerald-50 text-emerald-500",
    title: "لوحة تحكم الأهل",
    text: "متابعة دقيقة لمستوى أبنائك، نقاط القوة والضعف، في لمحة واحدة.",
  },
  {
    icon: GraduationCap,
    tone: "bg-amber-50 text-amber-500",
    title: "المنهج السعودي كاملاً",
    text: "مرتبط بمناهج وزارة التعليم لجميع المراحل من الصفوف الابتدائية إلى الثانوية.",
  },
];

export function Features() {
  return (
    <section id="features" className="py-16 sm:py-20 lg:py-24 bg-background">
      <div className="mx-auto w-[min(92%,1100px)]">
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-14">
          <div className="text-xs sm:text-sm font-bold text-primary mb-3">الحل</div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-foreground">
            تعليم ذكي، متاح، وممتع، غير مكلف أو محدود
          </h2>
          <p className="mt-3 text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-foreground">
            معلم خصوصي يتعلم كيف <span className="text-primary">يفكّر</span> ابنك.
          </p>
        </div>

        <div dir="ltr" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
          {FEATURES.map(({ icon: Icon, tone, title, text }) => (
            <div
              key={title}
              dir="rtl"
              className="group bg-white rounded-2xl border border-border p-5 sm:p-6 hover:border-primary/40 hover:shadow-[0_20px_40px_-25px_rgba(15,32,80,0.2)] transition text-start"
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-4 ${tone}`}>
                <Icon className="w-5 h-5" />
              </div>
              <h3 className="text-base sm:text-lg font-bold text-foreground mb-2">{title}</h3>
              <p className="text-sm sm:text-[15px] text-muted-foreground leading-relaxed">{text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
