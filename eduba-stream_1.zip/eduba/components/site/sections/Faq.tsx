"use client";

import { useState } from "react";
import { ChevronDown } from "lucide-react";

const ITEMS = [
  { q: "هل يمكنني الإلغاء في أي وقت؟", a: "نعم، يمكنك الإلغاء من حسابك في أي وقت بدون التزامات إضافية." },
  { q: "هل بيانات أبنائي آمنة؟", a: "نعم، نلتزم بأعلى معايير حماية البيانات ولا نشارك أي معلومات مع أطراف ثالثة." },
  { q: "هل المحتوى مرتبط بالمنهج الحالي؟", a: "نعم، المحتوى محدّث ومرتبط بمناهج وزارة التعليم لجميع المراحل." },
  { q: "كم طفل يمكنني إضافته؟", a: "يمكنك إضافة عدة أبناء على نفس حساب ولي الأمر بدون رسوم إضافية." },
];

export function Faq() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="py-16 sm:py-20 lg:py-24 bg-secondary/30">
      <div className="mx-auto w-[min(92%,800px)]">
        <h2 className="text-center text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-foreground mb-10 sm:mb-12">
          الأسئلة الشائعة
        </h2>
        <div className="space-y-3">
          {ITEMS.map((item, i) => {
            const isOpen = open === i;
            return (
              <div key={item.q} className="bg-white rounded-2xl border border-border overflow-hidden">
                <button
                  type="button"
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="w-full flex items-center justify-between gap-4 px-4 sm:px-5 py-4 text-start"
                  aria-expanded={isOpen}
                >
                  <span className="text-sm sm:text-base font-bold text-foreground">{item.q}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-muted-foreground transition-transform ${isOpen ? "rotate-180" : ""}`}
                  />
                </button>
                <div
                  className={`grid transition-all duration-300 ease-out ${
                    isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                  }`}
                >
                  <div className="overflow-hidden">
                    <div className="px-4 sm:px-5 pb-5 text-sm sm:text-[15px] text-muted-foreground leading-relaxed">
                      {item.a}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
