import Image from "next/image";
import Link from "next/link";

export function Rewards() {
  return (
    <section className="py-16 sm:py-20 lg:py-24 bg-background overflow-x-clip">
      <div className="mx-auto w-[min(92%,1080px)]">
        <div className="relative">
          <div className="relative rounded-3xl bg-white border border-border shadow-[0_30px_60px_-30px_rgba(15,32,80,0.15)] overflow-visible">
            <div
              className="hidden lg:block absolute top-1/2 -translate-y-1/2 -end-[180px] pointer-events-none"
              style={{ width: 560, height: 560 }}
            >
              <Image
                src="/landing/rewards/treasure.png"
                alt=""
                fill
                sizes="560px"
                className="object-contain drop-shadow-[0_20px_30px_rgba(15,32,80,0.18)]"
              />
            </div>
            <div className="lg:hidden flex justify-center pt-6">
              <div className="relative w-[260px] aspect-square">
                <Image
                  src="/landing/rewards/treasure.png"
                  alt=""
                  fill
                  sizes="260px"
                  className="object-contain drop-shadow-[0_20px_30px_rgba(15,32,80,0.18)]"
                />
              </div>
            </div>
            <div className="text-start p-6 sm:p-8 lg:py-8 lg:px-12 lg:max-w-[60%] lg:me-auto">
              <div className="inline-flex items-center gap-2 mb-3">
                <span className="text-base font-bold text-primary">الإيدوينز</span>
                <span className="inline-block px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-xs font-bold">
                  قريبًا
                </span>
              </div>
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight text-foreground mb-3">
                تعلّم، اجمع إيدوينز واكسب مكافآت.
              </h2>
              <p className="text-sm sm:text-base text-muted-foreground leading-relaxed max-w-md">
                كل سؤال تجيب عليه وكل اختبار تجتازه يكسبك نقاطاً حقيقية.
              </p>
            </div>
          </div>

          <div className="pointer-events-none">
            <div className="absolute -top-6 sm:-top-8 start-[6%] sm:start-[8%] w-12 sm:w-16 animate-[float_6s_ease-in-out_infinite]">
              <Image src="/landing/coins/pink.png" alt="" width={64} height={64} className="w-full h-auto drop-shadow-[0_8px_15px_rgba(15,32,80,0.2)]" />
            </div>
            <div className="absolute top-[-12px] sm:-top-4 end-[28%] sm:end-[32%] w-10 sm:w-14 animate-[float_5s_ease-in-out_infinite_0.5s]">
              <Image src="/landing/coins/green.png" alt="" width={56} height={56} className="w-full h-auto drop-shadow-[0_8px_15px_rgba(15,32,80,0.2)]" />
            </div>
            <div className="absolute -bottom-6 start-1/2 -translate-x-1/2 w-10 sm:w-12 animate-[float_4.5s_ease-in-out_infinite_1s]">
              <Image src="/landing/coins/gold.png" alt="" width={48} height={48} className="w-full h-auto drop-shadow-[0_8px_15px_rgba(15,32,80,0.2)]" />
            </div>
          </div>
        </div>

        <div className="flex justify-center mt-12">
          <Link
            href="/role-select"
            className="inline-flex items-center justify-center px-7 py-3.5 rounded-full bg-gradient-to-r from-[#1174FF] to-[#0A4699] text-white font-bold text-sm sm:text-base shadow-lg shadow-primary/20 hover:opacity-95 transition"
          >
            ابدأ رحلتك الآن!
          </Link>
        </div>
      </div>
    </section>
  );
}
