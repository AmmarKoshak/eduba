import Image from "next/image";

export function Story() {
  return (
    <section className="relative text-white overflow-hidden bg-black">
      <div className="relative min-h-[640px] sm:min-h-[780px] lg:min-h-[920px]">
        <Image src="/landing/story/bg.png" alt="" fill sizes="100vw" className="object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/60" />

        <div className="relative z-10 pt-4 sm:pt-6 lg:pt-10 px-4">
          <div className="max-w-3xl mx-auto text-center">
            <div className="text-[11px] sm:text-xs font-bold tracking-wider text-amber-300/90 mb-3">
              إيدوبا كلمة سومرية تعني &quot;بيت الألواح&quot;
            </div>
            <p className="text-lg sm:text-xl lg:text-2xl font-bold leading-snug text-white drop-shadow-[0_4px_20px_rgba(0,0,0,0.6)]">
              أقدم المدارس في التاريخ في بلاد ما بين النهرين القديمة. اليوم، نعيد بناءها بالذكاء الاصطناعي، لكل طالب في
              المملكة.
            </p>
          </div>
        </div>

        <div className="absolute bottom-8 sm:bottom-12 lg:bottom-16 inset-x-0 z-10 px-4">
          <div className="max-w-5xl mx-auto text-center">
            <p className="text-4xl sm:text-[40px] lg:text-5xl font-bold leading-snug mb-5 drop-shadow-[0_4px_20px_rgba(0,0,0,0.7)]">
              إيدوبا ليست مجرد منصة، إنها البنية التحتية <span className="text-primary">المستقبلية</span> للتعليم في
              المنطقة.
            </p>
            <div className="inline-block px-4 py-2 rounded-full bg-black/60 backdrop-blur border border-white/20 text-xs sm:text-sm text-white/85">
              متوافق مع رؤية المملكة 2030 في تطوير التعليم
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
