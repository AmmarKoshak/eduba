import Link from "next/link";
import { Check, Clock } from "lucide-react";

const STEPS = [
  { n: "١", title: "أنشئ حسابك في دقيقة", text: "سجّل وأنشئ حسابك كولي أمر، مجاناً." },
  { n: "٢", title: "أضف أبناءك من لوحة التحكم", text: "أدخل بيانات أبناءك وحدد الصف الدراسي لكل منهم." },
  { n: "٣", title: "أرسل QR أو رابطاً سحرياً", text: "يمسح الطالب الرمز أو يفتح الرابط، ويبدأ فوراً بدون تسجيل منفصل." },
];

const FREE_PERKS = [
  "متابعة تقدم كل ابن لحظة بلحظة",
  "تقارير مفصّلة عن نقاط القوة والضعف",
  "توصيات ذكاء اصطناعي محددة لكل طالب",
  "تنبيهات فورية عند إنجاز المهام",
  "أداة QR لتسجيل الأبناء بضغطة واحدة",
];

const SUBJECTS = [
  { name: "الرياضيات", pct: 88, bar: "bg-emerald-500", text: "text-emerald-600", badge: { label: "قوي", cls: "bg-emerald-100 text-emerald-700" } },
  { name: "اللغة العربية", pct: 72, bar: "bg-blue-500", text: "text-blue-600" },
  { name: "العلوم", pct: 45, bar: "bg-red-500", text: "text-red-600", badge: { label: "يحتاج تركيز", cls: "bg-red-100 text-red-700" } },
];

export function Parents() {
  return (
    <section id="parents" className="py-16 sm:py-20 lg:py-24 bg-[#0b1220] text-white">
      <div className="mx-auto w-[min(92%,1200px)]">
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="text-xs sm:text-sm font-bold text-primary mb-3">للأهل</div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold tracking-tight">
            لوحة تحكم ولي الأمر. وضوح تام، وراحة بال.
          </h2>
          <p className="mt-3 text-sm sm:text-base text-white/70 leading-relaxed">
            راقب تقدم ابنك، ونتائج الاختبارات في مكان واحد وببساطة تامة.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-start">
          {/* Dashboard mock */}
          <div className="order-1 lg:order-1">
            <div className="rounded-3xl bg-white border border-gray-200 overflow-hidden shadow-[0_30px_70px_-20px_rgba(0,0,0,0.4)]">
              <div className="bg-primary px-5 py-4 flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-bold text-white">
                  <span className="inline-flex w-6 h-6 rounded-md bg-white/20 items-center justify-center text-[10px] text-white">E</span>
                  لوحة تحكم الأهل
                </div>
                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/20 text-[11px] font-bold text-white">
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  مباشر
                </div>
              </div>
              <div className="p-5">
                <div className="flex items-center gap-5 border-b border-gray-200 pb-3 mb-5">
                  <button type="button" className="flex items-center gap-2 text-sm font-bold transition relative pb-2 text-primary">
                    <span className="inline-flex w-6 h-6 rounded-full items-center justify-center text-[11px] font-bold bg-primary text-white">م</span>
                    محمد
                    <span className="absolute inset-x-0 -bottom-[1px] h-0.5 bg-primary rounded-full" />
                  </button>
                  <button type="button" className="flex items-center gap-2 text-sm font-bold transition relative pb-2 text-gray-400">
                    <span className="inline-flex w-6 h-6 rounded-full items-center justify-center text-[11px] font-bold bg-gray-200 text-gray-500">ر</span>
                    ريم
                  </button>
                  <button type="button" className="ms-auto text-xs font-bold text-primary hover:underline">
                    + إضافة طفل
                  </button>
                </div>

                <div className="grid grid-cols-3 gap-2 sm:gap-3 mb-5">
                  {[
                    { v: "14 س", l: "ساعات هذا الأسبوع" },
                    { v: "8", l: "اختبارات مكتملة" },
                    { v: "1,240", l: "إيدوينز مكتسبة" },
                  ].map((s) => (
                    <div key={s.l} className="rounded-xl bg-gray-50 border border-gray-200 p-3 text-center">
                      <div className="text-base sm:text-lg font-black text-violet-600">{s.v}</div>
                      <div className="text-[10px] text-gray-500 font-medium leading-tight mt-1">{s.l}</div>
                    </div>
                  ))}
                </div>

                <div className="mb-5">
                  <div className="text-sm font-bold text-gray-700 mb-3 text-start">أداء المواد</div>
                  <div className="space-y-3">
                    {SUBJECTS.map((s) => (
                      <div key={s.name}>
                        <div className="flex items-center justify-between mb-1.5 text-xs">
                          <div className="flex items-center gap-2">
                            {s.badge && (
                              <span className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-bold ${s.badge.cls}`}>
                                {s.badge.label}
                              </span>
                            )}
                            <span className={`font-bold ${s.text}`}>{s.pct}%</span>
                          </div>
                          <span className="text-gray-700 font-medium">{s.name}</span>
                        </div>
                        <div className="h-1.5 rounded-full bg-gray-200 overflow-hidden flex" dir="ltr">
                          <div className={`h-full ${s.bar} ms-auto`} style={{ width: `${s.pct}%` }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="rounded-xl bg-blue-50 border border-blue-100 px-3 py-3 flex items-start gap-3">
                  <div className="shrink-0 w-9 h-9 rounded-lg bg-primary flex items-center justify-center">
                    <Clock className="w-4 h-4 text-white" strokeWidth={2.5} />
                  </div>
                  <div className="flex-1 text-start">
                    <div className="text-xs font-bold text-primary mb-0.5">توصية ذكاء اصطناعي</div>
                    <div className="text-[11px] text-gray-600 leading-relaxed">
                      محمد يحتاج مراجعة في المعادلات التربيعية بسبب 3 أخطاء متكررة هذا الأسبوع.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Steps + perks */}
          <div className="order-2 lg:order-2 space-y-8">
            <div>
              <div className="text-sm font-bold text-primary mb-5 text-start">كيف تبدأ؟ 3 خطوات فقط</div>
              <ol className="space-y-0">
                {STEPS.map((s, i) => (
                  <li key={s.n} className="relative flex items-start gap-4 pb-7 last:pb-0">
                    {i < STEPS.length - 1 && (
                      <span
                        aria-hidden="true"
                        className="absolute top-9 w-px h-full border-s border-dashed border-white/25"
                        style={{ insetInlineStart: 17 }}
                      />
                    )}
                    <span className="shrink-0 w-9 h-9 rounded-full bg-primary text-white flex items-center justify-center text-sm font-bold relative z-10">
                      {s.n}
                    </span>
                    <div className="flex-1 text-start">
                      <div className="text-base sm:text-lg font-bold text-white">{s.title}</div>
                      <div className="text-xs sm:text-sm text-white/60 mt-1">{s.text}</div>
                    </div>
                  </li>
                ))}
              </ol>
            </div>

            <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
              <div className="text-sm font-bold mb-3 text-white/90 text-start">ما تحصل عليه مجاناً مع أي خطة</div>
              <ul className="space-y-2.5">
                {FREE_PERKS.map((p) => (
                  <li key={p} className="flex items-start gap-2.5 text-xs sm:text-sm text-white/80">
                    <Check className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
                    <span className="flex-1 text-start">{p}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 justify-center mt-10 sm:mt-14">
          <Link
            href="/sign-up?role=parent"
            className="inline-flex items-center justify-center px-6 py-3 rounded-full bg-white text-[#0b1220] font-bold text-sm sm:text-base hover:opacity-95 transition"
          >
            أنشئ حسابك كولي أمر
          </Link>
          <span className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full border border-emerald-500/50 text-emerald-400 font-bold text-sm sm:text-base">
            <Check className="w-4 h-4" />
            حساب الأهل مجاني مع أي خطة
          </span>
        </div>
      </div>
    </section>
  );
}
