"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, X } from "lucide-react";

const LINKS = [
  { href: "/#students", label: "للطلاب" },
  { href: "/#parents", label: "للأهل" },
  { href: "/#pricing", label: "الأسعار" },
  { href: "/marketing-quiz", label: "اختبر نفسك مجاناً" },
];

export function MobileMenu({ loggedIn, isAdmin }: { loggedIn: boolean; isAdmin: boolean }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="md:hidden">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="inline-flex items-center justify-center w-10 h-10 rounded-full text-white hover:bg-white/10"
        aria-label="menu"
        aria-expanded={open}
      >
        {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </button>

      {open && (
        <div className="absolute inset-x-4 top-[calc(100%+8px)] rounded-2xl bg-white text-foreground shadow-[0_30px_60px_-30px_rgba(15,32,80,0.35)] border border-border p-4 z-[110]">
          <nav className="flex flex-col gap-1 text-sm font-medium">
            {LINKS.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="px-3 py-2.5 rounded-xl hover:bg-secondary transition"
              >
                {l.label}
              </Link>
            ))}
          </nav>
          <div className="mt-3 pt-3 border-t border-border flex flex-col gap-2">
            {loggedIn ? (
              <>
                {isAdmin && (
                  <Link
                    href="/admin"
                    onClick={() => setOpen(false)}
                    className="inline-flex items-center justify-center px-5 py-2.5 rounded-full text-sm font-medium border border-border hover:bg-secondary transition"
                  >
                    لوحة الإدارة
                  </Link>
                )}
                <Link
                  href="/account"
                  onClick={() => setOpen(false)}
                  className="inline-flex items-center justify-center px-5 py-2.5 rounded-full bg-[#0a0a0a] text-white text-sm font-medium hover:bg-black transition"
                >
                  حسابي
                </Link>
              </>
            ) : (
              <>
                <Link
                  href="/sign-in"
                  onClick={() => setOpen(false)}
                  className="inline-flex items-center justify-center px-5 py-2.5 rounded-full text-sm font-medium border border-border hover:bg-secondary transition"
                >
                  تسجيل الدخول
                </Link>
                <Link
                  href="/role-select"
                  onClick={() => setOpen(false)}
                  className="inline-flex items-center justify-center px-5 py-2.5 rounded-full bg-[#0a0a0a] text-white text-sm font-medium hover:bg-black transition"
                >
                  ابدأ رحلتك الآن
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
