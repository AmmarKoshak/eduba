import { Header } from "./Header";
import { Footer } from "./Footer";

/** Layout for inner pages: solid blue header, light content area, footer. */
export function PageShell({
  children,
  width = "min(92%,1100px)",
}: {
  children: React.ReactNode;
  width?: string;
}) {
  return (
    <>
      <Header variant="solid" />
      <main className="bg-background py-10 sm:py-14 lg:py-16 min-h-[60vh]">
        <div className="mx-auto" style={{ width }}>
          {children}
        </div>
      </main>
      <Footer />
    </>
  );
}

export function SectionLabel({ children }: { children: React.ReactNode }) {
  return <div className="text-xs sm:text-sm font-bold text-primary mb-3">{children}</div>;
}

export function Card({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`rounded-3xl bg-white border border-border shadow-[0_24px_50px_-30px_rgba(15,32,80,0.18)] ${className}`}>
      {children}
    </div>
  );
}

export { inputClass, primaryButtonClass, secondaryButtonClass } from "@/components/ui/classes";
