"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { BookOpen, Sparkles, Users } from "lucide-react";

type Role = "student" | "parent";

const OPTIONS: Array<{ role: Role; icon: typeof BookOpen; title: string; text: string }> = [
  { role: "student", icon: BookOpen, title: "طالب", text: "أريد التعلم والدراسة" },
  { role: "parent", icon: Users, title: "ولي أمر", text: "أريد متابعة تعليم أبنائي" },
];

export function RoleSelect({ plan }: { plan?: string }) {
  const [role, setRole] = useState<Role | null>(null);
  const router = useRouter();

  const next = () => {
    if (!role) return;
    const q = new URLSearchParams({ role });
    if (plan) q.set("plan", plan);
    router.push(`/sign-up?${q.toString()}`);
  };

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {OPTIONS.map(({ role: r, icon: Icon, title, text }) => {
          const selected = role === r;
          return (
            <button
              key={r}
              type="button"
              onClick={() => setRole(r)}
              aria-pressed={selected}
              className={`p-8 rounded-3xl border-2 transition-all duration-300 text-start ${
                selected
                  ? "border-primary bg-blue-50 shadow-lg"
                  : "border-gray-200 bg-white hover:border-gray-300 hover:shadow-lg"
              }`}
            >
              <div
                className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 transition-colors ${
                  selected ? "bg-primary" : "bg-gray-100"
                }`}
              >
                <Icon className={`w-8 h-8 ${selected ? "text-white" : "text-gray-400"}`} />
              </div>
              <h3 className="text-2xl font-bold mb-2 text-gray-800">{title}</h3>
              <p className="text-gray-500">{text}</p>
            </button>
          );
        })}
      </div>
      <button
        type="button"
        onClick={next}
        disabled={!role}
        className={`w-full py-4 rounded-2xl text-lg font-semibold transition-all flex items-center justify-center gap-3 ${
          role
            ? "bg-gradient-to-r from-[#1174FF] to-[#0A4699] text-white hover:opacity-95"
            : "bg-gray-200 text-gray-400 cursor-not-allowed"
        }`}
      >
        <Sparkles className="w-5 h-5" />
        متابعة
      </button>
      <p className="text-center text-gray-400 text-sm mt-4">يمكنك تغيير هذا لاحقاً من الإعدادات</p>
    </div>
  );
}
