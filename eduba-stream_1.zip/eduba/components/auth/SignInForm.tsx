"use client";

import { useActionState } from "react";
import Link from "next/link";
import { Loader2 } from "lucide-react";
import { signInAction, type AuthFormState } from "@/app/(auth)/actions";
import { inputClass, primaryButtonClass } from "@/components/ui/classes";

export function SignInForm({ callbackUrl }: { callbackUrl?: string }) {
  const [state, action, pending] = useActionState<AuthFormState | null, FormData>(signInAction, null);

  return (
    <form action={action} className="bg-white rounded-3xl border border-gray-200 p-6 sm:p-8 shadow-lg space-y-4">
      <input type="hidden" name="callbackUrl" value={callbackUrl ?? ""} />
      <div>
        <label htmlFor="identifier" className="block text-sm font-bold text-gray-800 mb-1.5">
          اسم المستخدم أو البريد الإلكتروني
        </label>
        <input id="identifier" name="identifier" required autoComplete="username" className={inputClass} dir="ltr" />
      </div>
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <label htmlFor="password" className="block text-sm font-bold text-gray-800">
            كلمة المرور
          </label>
          <span className="text-xs text-gray-400">نسيت كلمة المرور؟</span>
        </div>
        <input id="password" name="password" type="password" required autoComplete="current-password" className={inputClass} dir="ltr" />
      </div>
      {state?.error && <div className="text-sm text-red-700 bg-red-50 border border-red-100 rounded-xl px-4 py-3">{state.error}</div>}
      <button type="submit" disabled={pending} className={`${primaryButtonClass} w-full py-3.5`}>
        {pending && <Loader2 className="w-4 h-4 animate-spin" />}
        تسجيل الدخول
      </button>
      <p className="text-center text-sm text-gray-500">
        ليس لديك حساب؟{" "}
        <Link href="/sign-up" className="font-bold text-primary hover:underline">
          أنشئ حساباً
        </Link>
      </p>
    </form>
  );
}
