"use client";

import { useActionState } from "react";
import Link from "next/link";
import { Loader2 } from "lucide-react";
import { signUpAction, type AuthFormState } from "@/app/(auth)/actions";
import { inputClass, primaryButtonClass } from "@/components/ui/classes";

function Field({
  id,
  label,
  error,
  children,
}: {
  id: string;
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label htmlFor={id} className="block text-sm font-bold text-gray-800 mb-1.5">
        {label}
      </label>
      {children}
      {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </div>
  );
}

export function SignUpForm({ role, plan }: { role: "student" | "parent"; plan?: string }) {
  const [state, action, pending] = useActionState<AuthFormState | null, FormData>(signUpAction, null);
  const fe = state?.fieldErrors ?? {};

  return (
    <form action={action} className="bg-white rounded-3xl border border-gray-200 p-6 sm:p-8 shadow-lg space-y-4" noValidate>
      <input type="hidden" name="role" value={role} />
      <input type="hidden" name="plan" value={plan ?? ""} />

      <Field id="name" label="الاسم الكامل" error={fe.name}>
        <input id="name" name="name" required autoComplete="name" className={inputClass} />
      </Field>
      <Field id="email" label="البريد الإلكتروني" error={fe.email}>
        <input id="email" name="email" type="email" required autoComplete="email" className={inputClass} dir="ltr" />
      </Field>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Field id="username" label="اسم المستخدم (اختياري)" error={fe.username}>
          <input id="username" name="username" autoComplete="username" className={inputClass} dir="ltr" placeholder="ahmad_1" />
        </Field>
        <Field id="phone" label={role === "parent" ? "رقم الجوال" : "رقم الجوال (اختياري)"} error={fe.phone}>
          <input id="phone" name="phone" type="tel" autoComplete="tel" className={inputClass} dir="ltr" placeholder="05xxxxxxxx" />
        </Field>
      </div>
      <Field id="password" label="كلمة المرور" error={fe.password}>
        <input id="password" name="password" type="password" required autoComplete="new-password" className={inputClass} dir="ltr" />
      </Field>

      {state?.error && <div className="text-sm text-red-700 bg-red-50 border border-red-100 rounded-xl px-4 py-3">{state.error}</div>}

      <button type="submit" disabled={pending} className={`${primaryButtonClass} w-full py-3.5`}>
        {pending && <Loader2 className="w-4 h-4 animate-spin" />}
        إنشاء الحساب
      </button>
      <p className="text-center text-sm text-gray-500">
        لديك حساب؟{" "}
        <Link href="/sign-in" className="font-bold text-primary hover:underline">
          تسجيل الدخول
        </Link>
      </p>
    </form>
  );
}
