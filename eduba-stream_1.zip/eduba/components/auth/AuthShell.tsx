import Image from "next/image";
import Link from "next/link";

/** Centered card layout used by sign-in / sign-up / role-select (mirrors the original pages). */
export function AuthShell({
  title,
  subtitle,
  children,
  maxWidth = "max-w-md",
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
  maxWidth?: string;
}) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4" dir="rtl">
      <div className={`w-full ${maxWidth}`}>
        <div className="text-center mb-8">
          <Link href="/" className="inline-block">
            <Image src="/brand/eduba-mark.png" alt="Eduba" width={80} height={80} className="rounded-3xl mx-auto mb-6" />
          </Link>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{title}</h1>
          {subtitle && <p className="text-gray-500 text-lg">{subtitle}</p>}
        </div>
        {children}
        <p className="text-center text-gray-400 text-xs mt-8">© {new Date().getFullYear()} إيدوبا</p>
      </div>
    </div>
  );
}
