/**
 * DB-backed tests for the wallet ledger and referral rewards (skipped when no
 * database is reachable).
 */
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { eq } from "drizzle-orm";

let ok = false;
let db: Awaited<ReturnType<typeof import("@/lib/db")["getDb"]>>;
let schema: typeof import("@/lib/db/schema");
let svc: typeof import("@/lib/referrals/service");

const emails = ["ref-influencer@example.com", "ref-payer@example.com", "ref-buyer@example.com"];
let influencerId = "";
let payerId = "";
let buyerId = "";
let customerId = "";

async function cleanup() {
  const users = await db.select({ id: schema.users.id }).from(schema.users);
  for (const e of emails) {
    const [u] = await db.select({ id: schema.users.id }).from(schema.users).where(eq(schema.users.email, e));
    if (u) {
      await db.delete(schema.referrals).where(eq(schema.referrals.referrerUserId, u.id));
      await db.delete(schema.orders).where(eq(schema.orders.userId, u.id));
      await db.delete(schema.users).where(eq(schema.users.id, u.id));
    }
  }
  void users;
  await db.delete(schema.customers).where(eq(schema.customers.email, "ref-buyer@example.com"));
}

beforeAll(async () => {
  if (!process.env.DATABASE_URL) return;
  try {
    db = (await import("@/lib/db")).getDb();
    schema = await import("@/lib/db/schema");
    svc = await import("@/lib/referrals/service");
    await db.execute("select 1");
    ok = true;
  } catch {
    return;
  }
  await cleanup();
  const mk = async (email: string, extra: Partial<typeof schema.users.$inferInsert> = {}) => {
    const [u] = await db.insert(schema.users).values({ email, name: email.split("@")[0], passwordHash: "x", role: "parent", ...extra }).returning();
    return u.id;
  };
  influencerId = await mk(emails[0], { isInfluencer: true, commissionRatePercent: "25.00" });
  payerId = await mk(emails[1]);
  buyerId = await mk(emails[2]);
  const [c] = await db.insert(schema.customers).values({ name: "Buyer", email: "ref-buyer@example.com", phone: "+966500000099", streamConsumerId: `test-consumer-${Date.now()}`, userId: buyerId }).returning();
  customerId = c.id;
});

afterAll(async () => {
  if (ok) await cleanup();
});

async function makeOrder(referrerId: string, code: string, amount = "115.00") {
  const [o] = await db
    .insert(schema.orders)
    .values({
      customerId,
      userId: buyerId,
      productKey: "pro_monthly",
      streamProductId: "p",
      productType: "RECURRING",
      amount,
      currency: "SAR",
      status: "paid",
      paymentLinkId: `link-${crypto.randomUUID()}`,
      paymentLinkUrl: "https://example.test",
      referralCode: code,
      referrerUserId: referrerId,
      paidAt: new Date(),
    })
    .returning();
  const [referrer] = await db.select().from(schema.users).where(eq(schema.users.id, referrerId));
  await svc.attachReferralToOrder({ orderId: o.id, referrer, code, referredUserId: buyerId, referredCustomerId: customerId });
  return o;
}

describe("referral wallets", () => {
  it("allocates a unique referral code per user and resolves it, ignoring self-referrals", async () => {
    if (!ok) return;
    const code = await svc.ensureReferralCode(influencerId);
    expect(code).toMatch(/^[A-Z0-9]{8}$/);
    expect(await svc.ensureReferralCode(influencerId)).toBe(code);
    const r = await svc.resolveReferrer({ cookieCode: code.toLowerCase(), payerUserId: buyerId, payerEmail: "ref-buyer@example.com" });
    expect(r?.referrer.id).toBe(influencerId);
    expect(await svc.resolveReferrer({ cookieCode: code, payerUserId: influencerId, payerEmail: emails[0] })).toBeNull();
    expect(await svc.resolveReferrer({ cookieCode: "NOPE1234", payerEmail: "x@y.z" })).toBeNull();
  });

  it("credits the influencer 25% once, and is idempotent on retries", async () => {
    if (!ok) return;
    const code = await svc.ensureReferralCode(influencerId);
    const order = await makeOrder(influencerId, code);
    expect(await svc.rewardReferralForOrder(order)).toMatch(/^rewarded 28.75 SAR/);
    expect(await svc.rewardReferralForOrder(order)).toBe("already rewarded");
    const [w] = await db.select().from(schema.wallets).where(eq(schema.wallets.userId, influencerId));
    expect(Number(w.balance)).toBe(28.75);
    expect(Number(w.lifetimeEarned)).toBe(28.75);
    const tx = await db.select().from(schema.walletTransactions).where(eq(schema.walletTransactions.walletId, w.id));
    expect(tx).toHaveLength(1);
  });

  it("voids a second referral for the same customer (first payment only)", async () => {
    if (!ok) return;
    const code = await svc.ensureReferralCode(payerId);
    const order = await makeOrder(payerId, code);
    expect(await svc.rewardReferralForOrder(order)).toMatch(/^void/);
    const wallets = await db.select().from(schema.wallets).where(eq(schema.wallets.userId, payerId));
    expect(wallets.length === 0 || Number(wallets[0].balance) === 0).toBe(true);
  });

  it("runs a monthly settlement, marks it paid, and never lets the balance go negative", async () => {
    if (!ok) return;
    // Top the influencer up to pass the 100 SAR minimum.
    await svc.bookWalletTransaction({ userId: influencerId, type: "adjustment", amount: 100, idempotencyKey: `adj:${Date.now()}`, description: "test" });
    const { created } = await svc.createMonthlySettlements({ period: "2099-01", createdByEmail: "admin@example.com" });
    expect(created).toBeGreaterThanOrEqual(1);
    const [w] = await db.select().from(schema.wallets).where(eq(schema.wallets.userId, influencerId));
    expect(Number(w.balance)).toBe(0);
    const [s] = await db.select().from(schema.settlements).where(eq(schema.settlements.walletId, w.id));
    expect(s.status).toBe("pending");
    expect(Number(s.amount)).toBe(128.75);

    // A second run for the same period does nothing.
    const again = await svc.createMonthlySettlements({ period: "2099-01", createdByEmail: "admin@example.com" });
    expect(again.created).toBe(0);

    await expect(svc.createSettlement({ walletId: w.id, period: "2099-02", amount: 1, createdByEmail: "a" })).rejects.toThrow();

    const paid = await svc.markSettlementPaid({ settlementId: s.id, reference: "BANK-123" });
    expect(paid?.status).toBe("paid");
    expect(await svc.markSettlementPaid({ settlementId: s.id, reference: "BANK-123" })).toBeNull();
  });

  it("cancelling a pending settlement returns the money", async () => {
    if (!ok) return;
    await svc.bookWalletTransaction({ userId: influencerId, type: "adjustment", amount: 50, idempotencyKey: `adj2:${Date.now()}`, description: "test" });
    const [w] = await db.select().from(schema.wallets).where(eq(schema.wallets.userId, influencerId));
    const s = await svc.createSettlement({ walletId: w.id, period: "2099-03", createdByEmail: "a" });
    const [afterCreate] = await db.select().from(schema.wallets).where(eq(schema.wallets.id, w.id));
    expect(Number(afterCreate.balance)).toBe(0);
    await svc.cancelSettlement({ settlementId: s!.id });
    const [afterCancel] = await db.select().from(schema.wallets).where(eq(schema.wallets.id, w.id));
    expect(Number(afterCancel.balance)).toBe(50);
  });
});
