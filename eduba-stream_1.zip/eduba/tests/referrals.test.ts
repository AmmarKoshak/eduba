import { describe, expect, it } from "vitest";
import { computeCommission, generateReferralCode, normalizeReferralCode } from "@/lib/referrals/config";

const cfg = { payerRewardSar: 20, influencerRatePercent: 20 };

describe("referral codes", () => {
  it("generates 8-char codes from an unambiguous alphabet", () => {
    for (let i = 0; i < 50; i++) {
      const c = generateReferralCode();
      expect(c).toMatch(/^[ABCDEFGHJKLMNPQRSTUVWXYZ23456789]{8}$/);
    }
  });
  it("normalises user input", () => {
    expect(normalizeReferralCode(" 7k3pq2xa ")).toBe("7K3PQ2XA");
    expect(normalizeReferralCode("7K3-PQ2-XA")).toBe("7K3PQ2XA");
    expect(normalizeReferralCode("ab")).toBeNull();
    expect(normalizeReferralCode(null)).toBeNull();
    expect(normalizeReferralCode("<script>")).toBeNull();
  });
});

describe("computeCommission", () => {
  it("pays regular payers a flat reward, capped at the order amount", () => {
    expect(computeCommission({ orderAmount: 115, referrerIsInfluencer: false, config: cfg })).toBe(20);
    expect(computeCommission({ orderAmount: 10, referrerIsInfluencer: false, config: cfg })).toBe(10);
  });
  it("pays influencers a percentage, with per-influencer override", () => {
    expect(computeCommission({ orderAmount: 115, referrerIsInfluencer: true, config: cfg })).toBe(23);
    expect(computeCommission({ orderAmount: 115, referrerIsInfluencer: true, influencerRatePercent: 30, config: cfg })).toBe(34.5);
    expect(computeCommission({ orderAmount: 115, referrerIsInfluencer: true, influencerRatePercent: 0, config: cfg })).toBe(0);
  });
  it("rounds to halalas", () => {
    expect(computeCommission({ orderAmount: 99.99, referrerIsInfluencer: true, influencerRatePercent: 15, config: cfg })).toBe(15);
  });
});
