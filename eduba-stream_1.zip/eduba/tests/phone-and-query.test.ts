import { describe, expect, it } from "vitest";
import { normalizePhone } from "@/lib/phone";
import { buildQuery } from "@/lib/stream/client";
import { currentMonthRange } from "@/lib/format";

describe("normalizePhone", () => {
  it("normalises Saudi mobile formats to E.164", () => {
    expect(normalizePhone("0501234567")).toBe("+966501234567");
    expect(normalizePhone("050 123 4567")).toBe("+966501234567");
    expect(normalizePhone("501234567")).toBe("+966501234567");
    expect(normalizePhone("+966 50 123 4567")).toBe("+966501234567");
    expect(normalizePhone("00966501234567")).toBe("+966501234567");
    expect(normalizePhone("966501234567")).toBe("+966501234567");
    expect(normalizePhone("٠٥٠١٢٣٤٥٦٧")).toBe("+966501234567");
  });
  it("rejects garbage", () => {
    expect(normalizePhone("")).toBeNull();
    expect(normalizePhone("12345")).toBeNull();
    expect(normalizePhone("abc")).toBeNull();
  });
  it("keeps explicit international numbers", () => {
    expect(normalizePhone("+971501234567")).toBe("+971501234567");
  });
});

describe("buildQuery", () => {
  it("repeats keys for array filters and drops empty values", () => {
    expect(buildQuery({ statuses: ["A", "B"], page: 1, q: "", x: undefined, y: null })).toBe("?statuses=A&statuses=B&page=1");
    expect(buildQuery()).toBe("");
  });
});

describe("currentMonthRange", () => {
  it("returns Riyadh month boundaries", () => {
    const r = currentMonthRange(new Date("2026-11-09T12:00:00Z"));
    expect(r.from).toBe("2026-10-31T21:00:00.000Z"); // 2026-11-01 00:00 +03:00
    expect(r.to).toBe("2026-11-30T20:59:59.999Z"); // 2026-11-30 23:59:59.999 +03:00
  });
});
