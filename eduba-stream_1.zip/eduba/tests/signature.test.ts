import { createHmac } from "node:crypto";
import { describe, expect, it } from "vitest";
import { computeSignature, parseSignatureHeader, verifyStreamSignature } from "@/lib/stream/signature";

const secret = "whsec_test_secret";
const body = JSON.stringify({ event_type: "PAYMENT_SUCCEEDED", entity_id: "abc" });

describe("Stream webhook signature", () => {
  it("parses t and v1 from the header", () => {
    expect(parseSignatureHeader("t=1700000000,v1=deadbeef")).toEqual({ timestamp: "1700000000", signatures: ["deadbeef"] });
    expect(parseSignatureHeader("v1=deadbeef")).toBeNull();
    expect(parseSignatureHeader("")).toBeNull();
    // values containing "=" must survive (ISO timestamps / base64 would break a naive split)
    expect(parseSignatureHeader("t=2026-01-01T00:00:00Z,v1=aa==")).toEqual({ timestamp: "2026-01-01T00:00:00Z", signatures: ["aa=="] });
  });

  it("accepts a valid signature within the tolerance window", () => {
    const now = 1_800_000_000_000;
    const t = String(Math.floor(now / 1000) - 30);
    const sig = computeSignature(secret, t, body);
    const result = verifyStreamSignature({ secret, rawBody: body, signatureHeader: `t=${t},v1=${sig}`, now });
    expect(result.ok).toBe(true);
  });

  it("accepts an ISO-8601 timestamp", () => {
    const now = Date.parse("2026-11-09T12:00:00Z");
    const t = "2026-11-09T11:59:30Z";
    const sig = computeSignature(secret, t, body);
    expect(verifyStreamSignature({ secret, rawBody: body, signatureHeader: `t=${t},v1=${sig}`, now }).ok).toBe(true);
  });

  it("rejects a tampered body", () => {
    const now = 1_800_000_000_000;
    const t = String(Math.floor(now / 1000));
    const sig = computeSignature(secret, t, body);
    const tampered = body.replace("abc", "xyz");
    const result = verifyStreamSignature({ secret, rawBody: tampered, signatureHeader: `t=${t},v1=${sig}`, now });
    expect(result).toEqual({ ok: false, reason: "bad_signature" });
  });

  it("rejects a wrong secret", () => {
    const now = 1_800_000_000_000;
    const t = String(Math.floor(now / 1000));
    const sig = computeSignature("other", t, body);
    expect(verifyStreamSignature({ secret, rawBody: body, signatureHeader: `t=${t},v1=${sig}`, now }).reason).toBe("bad_signature");
  });

  it("rejects stale timestamps (replay protection)", () => {
    const now = 1_800_000_000_000;
    const t = String(Math.floor(now / 1000) - 3600);
    const sig = computeSignature(secret, t, body);
    const result = verifyStreamSignature({ secret, rawBody: body, signatureHeader: `t=${t},v1=${sig}`, now, toleranceSeconds: 300 });
    expect(result).toEqual({ ok: false, reason: "stale_timestamp" });
  });

  it("rejects missing / malformed headers", () => {
    expect(verifyStreamSignature({ secret, rawBody: body, signatureHeader: null }).reason).toBe("missing_header");
    expect(verifyStreamSignature({ secret, rawBody: body, signatureHeader: "nonsense" }).reason).toBe("malformed_header");
  });

  it("signs exactly `${timestamp}.${rawBody}` with HMAC-SHA256 hex", () => {
    // Independent reference computed with node:crypto in the test itself.
    const t = "1700000000";
    const expected = createHmac("sha256", secret).update(`${t}.${body}`).digest("hex");
    expect(computeSignature(secret, t, body)).toBe(expected);
  });
});
