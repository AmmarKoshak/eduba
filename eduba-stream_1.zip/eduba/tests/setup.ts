import "dotenv/config";

process.env.NEXT_PUBLIC_APP_URL ||= "https://eduba.test";
process.env.STREAM_API_KEY ||= "test-key";
process.env.STREAM_API_SECRET ||= "test-secret";
process.env.STREAM_WEBHOOK_SECRET ||= "whsec_test";
process.env.STREAM_PRODUCT_PRO_MONTHLY_ID ||= "11111111-1111-4111-8111-111111111111";
process.env.ADMIN_EMAILS ||= "admin@example.com";
process.env.AUTH_SECRET ||= "test-auth-secret-0123456789";
