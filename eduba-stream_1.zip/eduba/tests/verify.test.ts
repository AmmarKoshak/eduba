import { describe, expect, it } from "vitest";
import { evaluateInvoice, type OrderExpectation } from "@/lib/checkout/verify";
import type { Invoice } from "@/lib/stream/types";

const expected: OrderExpectation = {
  paymentLinkId: "link-1",
  streamConsumerId: "consumer-1",
  amount: 115,
  currency: "SAR",
};

const base: Invoice = {
  id: "inv-1",
  payment_link_id: "link-1",
  organization_consumer_id: "consumer-1",
  currency: "SAR",
  total_amount: "115.00",
  paid_amount: "115.00",
  status: "COMPLETED",
  subscription_id: "sub-1",
  payments: [{ id: "pay-1", current_status: "SUCCEEDED", payed_at: "2026-11-09T10:00:00Z", amount: "115.00" }],
};

describe("evaluateInvoice", () => {
  it("accepts a completed invoice that matches the order", () => {
    const v = evaluateInvoice(base, expected);
    expect(v).toEqual({ state: "paid", subscriptionId: "sub-1", paymentId: "pay-1", paidAt: "2026-11-09T10:00:00Z" });
  });

  it("rejects an invoice from another payment link (redirect tampering)", () => {
    expect(evaluateInvoice({ ...base, payment_link_id: "link-2" }, expected).state).toBe("mismatch");
    expect(evaluateInvoice({ ...base, payment_link_id: null }, expected).state).toBe("mismatch");
  });

  it("rejects a different customer, currency or amount", () => {
    expect(evaluateInvoice({ ...base, organization_consumer_id: "someone-else" }, expected).state).toBe("mismatch");
    expect(evaluateInvoice({ ...base, currency: "USD" }, expected).state).toBe("mismatch");
    expect(evaluateInvoice({ ...base, total_amount: "15.00", paid_amount: "15.00" }, expected).state).toBe("mismatch");
  });

  it("treats an unpaid invoice as pending, not paid", () => {
    const v = evaluateInvoice({ ...base, status: "ACCEPTED", paid_amount: "0.00", payments: [{ id: "p", current_status: "PENDING" }] }, expected);
    expect(v.state).toBe("pending");
  });

  it("treats canceled / expired / rejected invoices as failed", () => {
    for (const status of ["CANCELED", "EXPIRED", "REJECTED"] as const) {
      expect(evaluateInvoice({ ...base, status, paid_amount: "0" }, expected).state).toBe("failed");
    }
  });

  it("accepts a fully paid invoice even if the status has not flipped to COMPLETED yet", () => {
    const v = evaluateInvoice({ ...base, status: "ACCEPTED" }, expected);
    expect(v.state).toBe("paid");
  });

  it("accepts an installment plan once the first instalment succeeded, but not before", () => {
    const inst: Invoice = {
      ...base,
      type: "INSTALLMENTS",
      status: "ACCEPTED",
      total_amount: "300.00",
      paid_amount: "100.00",
      payments: [
        { id: "i1", current_status: "SUCCEEDED", payed_at: "2026-11-09T10:00:00Z", amount: "100.00", type: "INSTALLMENT" },
        { id: "i2", current_status: "PENDING", amount: "100.00", type: "INSTALLMENT" },
        { id: "i3", current_status: "PENDING", amount: "100.00", type: "INSTALLMENT" },
      ],
    };
    expect(evaluateInvoice(inst, { ...expected, amount: 300 })).toMatchObject({ state: "paid", paymentId: "i1" });
    const unpaid = { ...inst, paid_amount: "0.00", payments: inst.payments!.map((p) => ({ ...p, current_status: "PENDING" as const, payed_at: null })) };
    expect(evaluateInvoice(unpaid, { ...expected, amount: 300 }).state).toBe("pending");
  });

  it("does not treat a partially paid ONE_OFF invoice as paid", () => {
    expect(evaluateInvoice({ ...base, type: "ONE_OFF", status: "ACCEPTED", paid_amount: "50.00" }, expected).state).toBe("pending");
  });

  it("tolerates decimal string formatting", () => {
    expect(evaluateInvoice({ ...base, total_amount: "115", paid_amount: "115" }, expected).state).toBe("paid");
  });
});
