/**
 * Integration test for the webhook endpoint against a real Postgres
 * (DATABASE_URL from .env). Stream's API is mocked; the database is not.
 * Skipped automatically when no database is reachable.
 */
import { afterAll, beforeAll, describe, expect, it, vi } from "vitest";
import { eq } from "drizzle-orm";
import { computeSignature } from "@/lib/stream/signature";

const invoiceId = "aaaaaaaa-0000-4000-8000-000000000001";
const subscriptionId = "bbbbbbbb-0000-4000-8000-000000000001";
const paymentId = "cccccccc-0000-4000-8000-000000000001";
const consumerId = "dddddddd-0000-4000-8000-000000000001";
const paymentLinkId = "eeeeeeee-0000-4000-8000-000000000001";

const fakeStream = {
  getInvoice: vi.fn(async (id: string) => ({
    id,
    payment_link_id: paymentLinkId,
    organization_consumer_id: consumerId,
    currency: "SAR",
    total_amount: "115.00",
    paid_amount: "115.00",
    status: "COMPLETED",
    subscription_id: subscriptionId,
    payments: [{ id: paymentId, current_status: "SUCCEEDED", payed_at: "2026-11-09T10:00:00Z", amount: "115.00" }],
  })),
  getSubscription: vi.fn(async (id: string) => ({
    id,
    status: "ACTIVE",
    amount: "115.00",
    currency: "SAR",
    organization_consumer_id: consumerId,
    current_period_start: "2026-11-09T10:00:00Z",
    current_period_end: "2026-12-09T10:00:00Z",
    cancel_at_period_end: false,
  })),
  listInvoices: vi.fn(async () => ({ data: [], pagination: {} })),
};

vi.mock("@/lib/stream/client", async (importOriginal) => {
  const mod = await importOriginal<typeof import("@/lib/stream/client")>();
  return { ...mod, stream: () => fakeStream };
});

let dbAvailable = false;
let orderId = "";
let db: Awaited<ReturnType<typeof import("@/lib/db")["getDb"]>>;
let schema: typeof import("@/lib/db/schema");

beforeAll(async () => {
  if (!process.env.DATABASE_URL) return;
  try {
    const dbMod = await import("@/lib/db");
    schema = await import("@/lib/db/schema");
    db = dbMod.getDb();
    await db.execute("select 1");
    dbAvailable = true;
  } catch {
    dbAvailable = false;
    return;
  }
  // Seed a customer + pending order the webhook can match.
  await db.delete(schema.webhookEvents);
  await db.delete(schema.subscriptions).where(eq(schema.subscriptions.streamSubscriptionId, subscriptionId));
  await db.delete(schema.orders).where(eq(schema.orders.paymentLinkId, paymentLinkId));
  await db.delete(schema.customers).where(eq(schema.customers.streamConsumerId, consumerId));
  const [customer] = await db
    .insert(schema.customers)
    .values({ name: "Test", email: "test@example.com", phone: "+966500000001", streamConsumerId: consumerId })
    .returning();
  const [order] = await db
    .insert(schema.orders)
    .values({
      customerId: customer.id,
      productKey: "pro_monthly",
      streamProductId: "prod-1",
      productType: "RECURRING",
      amount: "115.00",
      currency: "SAR",
      paymentLinkId,
      paymentLinkUrl: "https://streampay.sa/ds/test",
    })
    .returning();
  orderId = order.id;
});

afterAll(async () => {
  if (!dbAvailable) return;
  await db.delete(schema.webhookEvents);
  await db.delete(schema.subscriptions).where(eq(schema.subscriptions.streamSubscriptionId, subscriptionId));
  await db.delete(schema.orders).where(eq(schema.orders.paymentLinkId, paymentLinkId));
  await db.delete(schema.customers).where(eq(schema.customers.streamConsumerId, consumerId));
});

function signedRequest(body: string, opts: { secret?: string; timestamp?: string } = {}) {
  const t = opts.timestamp ?? String(Math.floor(Date.now() / 1000));
  const sig = computeSignature(opts.secret ?? process.env.STREAM_WEBHOOK_SECRET!, t, body);
  return new Request("https://eduba.test/api/webhooks/stream", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-webhook-event": "PAYMENT_SUCCEEDED",
      "x-webhook-entity-type": "PAYMENT",
      "x-webhook-entity-id": paymentId,
      "x-webhook-timestamp": t,
      "x-webhook-signature": `t=${t},v1=${sig}`,
    },
    body,
  });
}

describe("POST /api/webhooks/stream", () => {
  it("rejects an invalid signature with 401 and stores nothing", async () => {
    if (!dbAvailable) return;
    const { POST } = await import("@/app/api/webhooks/stream/route");
    const body = JSON.stringify({ event_type: "PAYMENT_SUCCEEDED", entity_type: "PAYMENT", entity_id: paymentId, timestamp: "2026-11-09T10:00:00Z" });
    const res = await POST(signedRequest(body, { secret: "wrong" }));
    expect(res.status).toBe(401);
    const events = await db.select().from(schema.webhookEvents);
    expect(events).toHaveLength(0);
  });

  it("activates the order on a verified PAYMENT_SUCCEEDED and is idempotent on retry", async () => {
    if (!dbAvailable) return;
    const { POST } = await import("@/app/api/webhooks/stream/route");
    const payload = {
      event_type: "PAYMENT_SUCCEEDED",
      entity_type: "PAYMENT",
      entity_id: paymentId,
      status: "SUCCEEDED",
      timestamp: "2026-11-09T10:00:00Z",
      data: {
        invoice: { id: invoiceId },
        payment: { id: paymentId },
        metadata: { order_id: orderId },
      },
    };
    const body = JSON.stringify(payload);

    const first = await POST(signedRequest(body));
    expect(first.status).toBe(200);
    expect(await first.json()).toMatchObject({ received: true, result: `order ${orderId}: paid` });

    const [order] = await db.select().from(schema.orders).where(eq(schema.orders.id, orderId));
    expect(order.status).toBe("paid");
    expect(order.invoiceId).toBe(invoiceId);
    expect(order.subscriptionId).toBe(subscriptionId);

    const [sub] = await db.select().from(schema.subscriptions).where(eq(schema.subscriptions.streamSubscriptionId, subscriptionId));
    expect(sub.status).toBe("ACTIVE");
    expect(sub.currentPeriodEnd?.toISOString()).toBe("2026-12-09T10:00:00.000Z");

    // Stream retries the same delivery → must be a no-op.
    const invoiceCalls = fakeStream.getInvoice.mock.calls.length;
    const second = await POST(signedRequest(body));
    expect(second.status).toBe(200);
    expect(await second.json()).toMatchObject({ received: true, duplicate: true });
    expect(fakeStream.getInvoice.mock.calls.length).toBe(invoiceCalls);

    const events = await db.select().from(schema.webhookEvents);
    expect(events).toHaveLength(1);
    expect(events[0].attempts).toBe(2);
    expect(events[0].processedAt).not.toBeNull();
  });

  it("returns 500 (so Stream retries) when the handler fails, and processes it on the retry", async () => {
    if (!dbAvailable) return;
    const { POST } = await import("@/app/api/webhooks/stream/route");
    fakeStream.getSubscription.mockRejectedValueOnce(new Error("Stream down"));
    const payload = {
      event_type: "SUBSCRIPTION_CANCELED",
      entity_type: "SUBSCRIPTION",
      entity_id: subscriptionId,
      status: "CANCELED",
      timestamp: "2026-11-09T11:00:00Z",
      data: { subscription: { id: subscriptionId } },
    };
    const body = JSON.stringify(payload);
    const failed = await POST(signedRequest(body));
    expect(failed.status).toBe(500);

    fakeStream.getSubscription.mockResolvedValueOnce({
      id: subscriptionId,
      status: "CANCELED",
      amount: "115.00",
      currency: "SAR",
      organization_consumer_id: consumerId,
      current_period_start: "2026-11-09T10:00:00Z",
      current_period_end: "2026-12-09T10:00:00Z",
      cancel_at_period_end: false,
    });
    const retried = await POST(signedRequest(body));
    expect(retried.status).toBe(200);
    const [sub] = await db.select().from(schema.subscriptions).where(eq(schema.subscriptions.streamSubscriptionId, subscriptionId));
    expect(sub.status).toBe("CANCELED");
  });
});
