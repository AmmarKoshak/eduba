import { describe, expect, it } from "vitest";
import { buildPaymentLinkPayload, withCheckoutLanguage } from "@/lib/checkout/payment-link";
import { PRODUCTS } from "@/lib/products";

const common = {
  consumerId: "consumer-1",
  orderId: "0f8fad5b-d9cb-469f-a165-70867728950e",
  appUrl: "https://eduba.tech/",
  now: new Date("2026-11-09T10:00:00Z"),
};

describe("buildPaymentLinkPayload", () => {
  it("creates a consumer-bound single-use link for the recurring Pro plan without touching payment methods", () => {
    const p = buildPaymentLinkPayload({ ...common, product: PRODUCTS.pro_monthly, streamProductId: "prod-pro" });
    expect(p.items).toEqual([{ product_id: "prod-pro", quantity: 1 }]);
    expect(p.max_number_of_payments).toBe(1);
    expect(p.organization_consumer_id).toBe("consumer-1");
    expect(p.currency).toBe("SAR");
    expect(p.payment_methods).toBeUndefined(); // org defaults; Stream disables installments on subscriptions
    expect(p.success_redirect_url).toBe("https://eduba.tech/checkout/success?order=0f8fad5b-d9cb-469f-a165-70867728950e");
    expect(p.failure_redirect_url).toBe("https://eduba.tech/checkout/failed?order=0f8fad5b-d9cb-469f-a165-70867728950e");
    expect(p.custom_metadata).toMatchObject({ order_id: common.orderId, product_key: "pro_monthly", source: "website" });
    expect(p.valid_until).toBe("2026-11-10T10:00:00.000Z");
  });

  it("enables installments (and keeps cards on) for one-time products only", () => {
    const p = buildPaymentLinkPayload({ ...common, product: PRODUCTS.test_one_time, streamProductId: "prod-once" });
    expect(p.payment_methods).toMatchObject({ installment: true, visa: true, mastercard: true, bank_transfer: false });
  });

  it("never mixes products: exactly one item per link", () => {
    for (const product of Object.values(PRODUCTS)) {
      const p = buildPaymentLinkPayload({ ...common, product, streamProductId: "x" });
      expect(p.items).toHaveLength(1);
    }
  });
});

describe("withCheckoutLanguage", () => {
  it("adds language=ar to the hosted checkout URL", () => {
    expect(withCheckoutLanguage("https://streampay.sa/ds/abc")).toBe("https://streampay.sa/ds/abc?language=ar");
    expect(withCheckoutLanguage("https://streampay.sa/ds/abc?x=1", "en")).toBe("https://streampay.sa/ds/abc?x=1&language=en");
  });
});
