import { describe, expect, it, vi } from "vitest";
import { StreamClient } from "@/lib/stream/client";
import { findOrCreateConsumer } from "@/lib/stream/consumers";

type Handler = (url: URL, init: RequestInit) => { status: number; body: unknown };

function fakeClient(handler: Handler) {
  const calls: Array<{ method: string; url: string; body?: unknown }> = [];
  const fetchFn = vi.fn(async (input: string | URL | Request, init?: RequestInit) => {
    const url = new URL(typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url);
    const method = init?.method ?? "GET";
    calls.push({ method, url: url.toString(), body: init?.body ? JSON.parse(String(init.body)) : undefined });
    const { status, body } = handler(url, init ?? {});
    return new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
  });
  const client = new StreamClient({ baseUrl: "https://stream.test/api/v2", authHeader: "dGVzdA==", fetchFn: fetchFn as unknown as typeof fetch });
  return { client, calls, fetchFn };
}

const input = { name: "أحمد", email: "ahmad@example.com", phone: "+966501234567" };

describe("findOrCreateConsumer", () => {
  it("reuses an existing consumer matched by exact email (no POST)", async () => {
    const { client, calls } = fakeClient((url) => {
      if (url.pathname.endsWith("/consumers") && url.searchParams.get("search_term") === "ahmad@example.com") {
        return { status: 200, body: { data: [{ id: "c-1", email: "AHMAD@example.com", phone_number: "+966500000000" }], pagination: {} } };
      }
      return { status: 200, body: { data: [], pagination: {} } };
    });
    const res = await findOrCreateConsumer(client, input);
    expect(res).toMatchObject({ created: false, consumer: { id: "c-1" } });
    expect(calls.some((c) => c.method === "POST")).toBe(false);
  });

  it("ignores partial matches returned by search_term and falls back to phone", async () => {
    const { client } = fakeClient((url) => {
      const term = url.searchParams.get("search_term");
      if (term === "ahmad@example.com") {
        // search is a partial match on Stream's side: a different person could come back
        return { status: 200, body: { data: [{ id: "other", email: "ahmad@example.com.au" }], pagination: {} } };
      }
      if (term === "+966501234567") {
        return { status: 200, body: { data: [{ id: "c-2", email: null, phone_number: "966501234567" }], pagination: {} } };
      }
      return { status: 200, body: { data: [], pagination: {} } };
    });
    const res = await findOrCreateConsumer(client, input);
    expect(res.consumer.id).toBe("c-2");
    expect(res.created).toBe(false);
  });

  it("creates the consumer when nothing matches, sending E.164 phone and lower-case email", async () => {
    const { client, calls } = fakeClient((url, init) => {
      if (init.method === "POST") return { status: 200, body: { id: "new-1", ...JSON.parse(String(init.body)) } };
      return { status: 200, body: { data: [], pagination: {} } };
    });
    const res = await findOrCreateConsumer(client, input);
    expect(res).toMatchObject({ created: true, consumer: { id: "new-1" } });
    const post = calls.find((c) => c.method === "POST");
    expect(post?.body).toMatchObject({ name: "أحمد", email: "ahmad@example.com", phone_number: "+966501234567", preferred_language: "AR" });
  });

  it("recovers from DUPLICATE_CONSUMER by re-searching", async () => {
    let created = false;
    const { client } = fakeClient((url, init) => {
      if (init.method === "POST") {
        created = true;
        return { status: 422, body: { error: { code: "DUPLICATE_CONSUMER", message: "Consumer already exists." } } };
      }
      if (created && url.searchParams.get("search_term") === "+966501234567") {
        return { status: 200, body: { data: [{ id: "race-1", phone_number: "+966501234567" }], pagination: {} } };
      }
      return { status: 200, body: { data: [], pagination: {} } };
    });
    const res = await findOrCreateConsumer(client, input);
    expect(res).toMatchObject({ created: false, consumer: { id: "race-1" } });
  });

  it("sends the x-api-key header on every call", async () => {
    const { client, fetchFn } = fakeClient(() => ({ status: 200, body: { data: [], pagination: {} } }));
    await client.listConsumers({ search_term: "x" });
    const init = fetchFn.mock.calls[0][1] as RequestInit;
    expect((init.headers as Record<string, string>)["x-api-key"]).toBe("dGVzdA==");
  });
});
