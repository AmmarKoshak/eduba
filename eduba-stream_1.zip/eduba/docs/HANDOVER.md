# Handover — Eduba × Stream

Date: 2026-11-09. Everything below was built from a clean `create-next-app` (no original source was available);
the public pages were recreated from the live eduba.tech markup so classes, copy and layout match.

## 1. Files

**Public site (rebuilt)**
- `app/layout.tsx`, `app/globals.css` — RTL root layout, theme tokens (primary `#2563eb`, hero `#0a3aa8`, …), Cairo/Tajawal fonts
- `app/page.tsx` + `components/site/sections/*` — Hero, Problem, Features, Students (`#students`), Rewards, Parents (`#parents`), Pricing (`#pricing`), Faq, Story, FinalCta
- `components/site/Header.tsx`, `MobileMenu.tsx`, `Footer.tsx`, `PageShell.tsx`, `components/ui/classes.ts`
- `app/sign-in`, `app/sign-up`, `app/role-select`, `components/auth/*` — login/sign-up (Auth.js credentials), role picker
- `app/account/*` — plan status, last orders, "إدارة الاشتراك" (Stream Customer Portal)
- `app/marketing-quiz`, `app/partner-school` — placeholders (the original pages belong to the AI product, out of scope)

**Task 1 — Stream checkout**
- `lib/env.ts` — server-only env access, `x-api-key = base64(KEY:SECRET)`
- `lib/stream/client.ts` (REST wrapper), `types.ts`, `consumers.ts` (find-or-create, no duplicates), `signature.ts` (webhook HMAC)
- `lib/products.ts` — catalogue (Pro monthly 115 SAR recurring; hidden 300 SAR one-time test product)
- `lib/checkout/payment-link.ts` (payload rules), `verify.ts` (invoice verification rules), `service.ts` (checkout, verification, subscription sync)
- `app/checkout/page.tsx`, `actions.ts`, `components/checkout/CheckoutForm.tsx`, `StreamEmbed.tsx`, `PaymentStatusPoller.tsx`
- `app/checkout/success/page.tsx`, `app/checkout/failed/page.tsx`, `app/api/checkout/status/route.ts`
- `app/api/webhooks/stream/route.ts`, `lib/stream/webhook-handlers.ts`
- `scripts/stream-setup.ts` — creates product(s) + webhook, prints env values (refuses live keys unless `--allow-production`)

**Task 2 — Admin**
- `app/admin/layout.tsx` (allow-list guard + 403 page), `page.tsx` (summary cards), `invoices/`, `payments/`, `subscriptions/`, `customers/`
- `lib/stream/admin.ts` (filters → Stream query params, summary aggregation, dashboard links)
- `components/admin/Filters.tsx`, `AdminNav.tsx`, `ui.tsx`
- `middleware.ts`, `auth.ts`, `auth.config.ts`, `types/next-auth.d.ts`, `lib/auth/users.ts`

**Referral wallets (payers + influencers)**
- `lib/referrals/config.ts` (settings, code generation, commission maths), `lib/referrals/service.ts` (codes, attribution, idempotent ledger, rewards, settlements)
- `app/r/[code]/route.ts` (referral landing → cookie), `middleware.ts` (`?ref=` cookie + route protection)
- `app/account/wallet/page.tsx`, `components/wallet/CopyLink.tsx`
- `app/admin/wallets/*` (page + server actions), `app/admin/settlements/page.tsx`, `app/admin/referrals/page.tsx`, `components/admin/ConfirmActionDialog.tsx`, `AdminToaster.tsx`
- `drizzle/0001_referral_wallets.sql`

**Task 3A — Wallets (payment)**
- `public/.well-known/apple-developer-merchantid-domain-association` (+ `README.md` next to it)

**Data**
- `lib/db/schema.ts`, `lib/db/index.ts`, `drizzle.config.ts`, `drizzle/0000_init.sql` — tables `users`, `customers`, `orders`, `subscriptions`, `webhook_events`

**Tooling / tests**
- `tests/*.test.ts` (34 unit tests + DB-backed webhook test), `tests/e2e/mock-flow.mjs` (14-step Playwright flow), `vitest.config.mts`
- `scripts/mock-stream.mjs` (local Stream stand-in), `scripts/create-user.ts`, `scripts/download-assets.mjs`
- `.env.example`, `README.md`, this file

## 2. Environment variables

| Variable | Required | Notes |
| --- | --- | --- |
| `NEXT_PUBLIC_APP_URL` | yes | `https://eduba.tech` in production; used for Stream redirect URLs + webhook registration |
| `DATABASE_URL` | yes | Postgres (Vercel Storage → Postgres/Neon sets it automatically) |
| `AUTH_SECRET` | yes | `openssl rand -base64 32` |
| `ADMIN_EMAILS` | yes | `ammarkoshak@streampay.sa` (comma-separate to add more) |
| `STREAM_API_KEY` / `STREAM_API_SECRET` | yes | sandbox pair for testing, production pair for go-live |
| `STREAM_WEBHOOK_SECRET` | yes | printed by `npm run stream:setup` or typed when creating the webhook in the dashboard |
| `STREAM_PRODUCT_PRO_MONTHLY_ID` | yes | printed by `npm run stream:setup` |
| `STREAM_PRODUCT_TEST_ONE_TIME_ID` | no | only for installment tests (`--with-test-product`) |
| `STREAM_API_BASE_URL` | no | default real API; `http://127.0.0.1:4567/api/v2` for the mock |
| `STREAM_DASHBOARD_URL` | no | default `https://app.streampay.sa` |
| `STREAM_ENABLE_AMEX` | no | `true` only if AMEX is enabled on the Stream account |
| `STREAM_WEBHOOK_TOLERANCE_SECONDS` | no | default 300 |
| `NEXT_PUBLIC_STREAM_EMBED_SCRIPT_URL` | no | default Stream CDN |
| `REFERRAL_PAYER_REWARD_SAR` | no | default 20 |
| `REFERRAL_INFLUENCER_RATE_PERCENT` | no | default 20 |
| `SETTLEMENT_MIN_SAR` | no | default 100 |
| `REFERRAL_COOKIE_DAYS` | no | default 30 |

## 3. Test checklist (Stream sandbox)

Prerequisites: sandbox key pair in `.env`, a public HTTPS URL for the site (Vercel preview or a tunnel),
`npm run stream:setup -- --with-test-product`, env values copied, an admin user created (`npm run user:create`).

1. **Successful subscription** — open `/#pricing` → `اشترك في Pro` → fill name / `05xxxxxxxx` / email → `متابعة إلى الدفع الآمن`.
   The embedded checkout appears (fallback link works too). Pay with Visa `4111 1111 1111 1111`, any future expiry, any CVC,
   two-word name. Expect redirect to `/checkout/success?order=…&invoice_id=…` showing **تم الدفع بنجاح** only after
   verification; `/account` shows the subscription as نشط with the next billing date; Stream dashboard shows consumer,
   invoice (COMPLETED) and subscription (ACTIVE).
2. **No duplicate customers** — repeat step 1 with the same email/phone but a different name; Stream must still show
   one consumer (name updated locally), and the second payment link is bound to the same consumer id.
3. **Declined card** — same flow with Visa `4123 1200 0109 0109` (DECLINED 05) or Mada `4201 3200 0031 1101`
   (INSUFFICIENT FUNDS). Expect `/checkout/failed` with the Arabic message, order stays غير مكتمل, nothing activated.
4. **Tampered redirect** — take a success URL, change `invoice_id` to another invoice id (or a random UUID) and reload:
   a pending order must not show as paid; a paid order stays paid (DB is the source of truth).
5. **Installments** — `/checkout?plan=test_one_time` (300 SAR one-time): the hosted/embedded checkout offers 2 or 3
   instalments (min 100 SAR each). Pay the first instalment; expect success + invoice type `INSTALLMENTS` in
   `/admin/invoices` with the remaining payments PENDING.
6. **Webhook** — in Stream → Settings → Webhooks, check deliveries for `PAYMENT_SUCCEEDED`, `SUBSCRIPTION_ACTIVATED`
   return 200. `select event_type, status, attempts, processed_at from webhook_events;` shows one row per delivery.
   Send a delivery twice (Stream "resend") → the second returns `{"duplicate":true}`. Curl the endpoint without a
   signature → 401. Edit the body of a captured delivery and resend with the old signature → 401.
7. **Cancellation via portal** — `/account` → `إدارة الاشتراك` opens Stream's portal; cancel the subscription; the
   `SUBSCRIPTION_CANCELED` webhook flips `/account` and `/admin/subscriptions` to ملغي.
8. **Admin** — `/admin` as `ammarkoshak@streampay.sa`: cards show revenue = sum of SUCCEEDED/SETTLED payments this month,
   active subscriptions, failed payments; filters (date, status, customer search) and pagination change the Stream query;
   each row's `فتح في Stream` opens the dashboard record. Log in as a normal student → `/admin` shows غير مصرّح;
   logged out → redirected to `/sign-in`.
9. **Referrals & wallets** — as user A open `/account/wallet`, copy the link; in a private window open it (cookie set),
   sign up as B and pay for Pro. A's wallet shows +20 ريال (or 20 % if A is an influencer) exactly once, B's referral row
   says تمت المكافأة; paying again as B adds nothing. In `/admin/wallets` promote A to influencer (dialog), run
   "إنشاء تسويات الشهر" (balances ≥ 100) or "تسوية" on a row, then in `/admin/settlements` mark it paid with a bank
   reference — A sees the settlement as مدفوعة and the balance drops accordingly.
10. **Apple Pay (after Stream enables it)** — on an iPhone/Safari with a card in Wallet, the embedded checkout shows the
   Apple Pay button; in sandbox the outcome depends on the amount (200–300 SAR = approved — use the 300 SAR test product).

Local equivalents without a Stream account: `npm run stream:mock`, `npm run build && npm run start`, then
`node tests/e2e/mock-flow.mjs` (16 steps, all passing at handover) and `npm test` (44 tests).

## 4. What to request from Stream support (wallets)

Send to Stream support with your organisation name/id:

1. **Apple Pay**: enable Apple Pay for the organisation and register the domains `eduba.tech`, `www.eduba.tech`
   (and any staging/preview domain you will test on, e.g. `*.vercel.app` preview URL). Confirm the domain-association
   file is live at `https://eduba.tech/.well-known/apple-developer-merchantid-domain-association` (it is served from
   `public/`, no redirect, HTTP 200).
2. **Samsung Pay**: enable it for the organisation (Stream's API lists `SAMSUNG_PAY` as a payment method, so it is
   gateway-side; no code change needed on our side).
3. **Google Pay**: ask whether it is supported at all — Stream's API/payment-method enum has Apple Pay and Samsung Pay
   but **no Google Pay**. If it is not available, the "Google Pay" requirement cannot be met through Stream.
4. Confirm wallets are allowed **inside the embedded (iframe) checkout** on our domain, not only on the hosted page.
5. Sandbox: confirm Apple Pay sandbox testing works with the amount-based outcomes from the docs (200–300 SAR approved).
6. (Optional) installment split periods / minimums if you want anything other than 2–4 monthly instalments, min 100 SAR each.

## 5. Assumptions and things I could not verify

- **Admin write actions.** The brief asked for a read-only admin; the referral feature needs three writes
  (promote/demote influencer, create settlement, mark paid / cancel). Each sits behind a confirmation dialog and
  re-checks the admin allow-list server-side. Stream data (refunds, cancellations) is still read-only.
- Commission is paid on the referred customer's **first** successful payment only (renewals arrive as Stream
  invoices without a website order, so they never trigger a reward). Change `rewardReferralForOrder` if renewals
  should pay too.
- Payers' balances are paid out through the same monthly settlement flow as influencers. Redeeming a balance as a
  discount on the next payment (via a Stream coupon on the payment link) is possible but not built.

- **No sandbox run yet.** The key pair shared in chat was a *live* organisation (`/me` → `sandbox: false`), so all
  Stream-API behaviour was verified against the public OpenAPI spec, the official TypeScript SDK types and a local
  mock that mirrors them — not against the sandbox. First real run: `npm run stream:setup` then checklist §3.
- Stream dashboard deep links use `https://app.streampay.sa/{invoices|payments|subscriptions|consumers}/{id}` —
  the path pattern is a guess; adjust `dashboardUrl` in `lib/stream/admin.ts` or `STREAM_DASHBOARD_URL` if it differs.
- `from_date` / `to_date` filters exist on Stream's payment, invoice and subscription lists (per the OpenAPI spec);
  whether they compare `created_at` or `payed_at` for payments is not documented, so the revenue card additionally
  filters by `payed_at` client-side.
- Stream's `/payments` list has no customer fields; the admin "Payments" tab therefore has no customer column
  (the "Invoices & payments" tab does).
- The `payment_methods` object is all-or-nothing: for one-time products the code sends `visa`, `mastercard`,
  `installment: true`, `bank_transfer: false`, `amex` from `STREAM_ENABLE_AMEX`. Mada/Apple Pay are not in that
  object and follow the organisation settings.
- Installment plans count as paid once the first instalment succeeds (Stream collects the rest). Change
  `evaluateInvoice` in `lib/checkout/verify.ts` if you prefer to wait for the full amount.
- Webhook timestamps: the docs show both `t=<unix>` and ISO formats; both are accepted. Tolerance 5 min.
- Prices are treated as VAT-inclusive (`is_price_inclusive_of_vat: true`) when the setup script creates products,
  matching "115 ريال/شهر" on the page.
- The original site's `/marketing-quiz`, `/partner-school`, the AI tutor, tests and parent dashboard are product
  features, not part of this scope — they are placeholders. The original used Clerk; this rebuild uses Auth.js.
- Brand images are placeholders until `npm run assets:download` is run on a machine that can reach eduba.tech.
- Playwright is not in `package.json` (it was pre-installed where the e2e ran); `npm i -D playwright` before running
  `tests/e2e/mock-flow.mjs` elsewhere.
